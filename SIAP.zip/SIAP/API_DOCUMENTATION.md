# SIAP API Documentation

Dokumentasi lengkap API endpoints untuk SIAP (Sistem Induk Administrasi Pesantren).

---

## 📋 Daftar Isi

- [Authentication](#authentication)
- [Academic Module](#academic-module)
- [Finance Module](#finance-module)
- [Reports Module](#reports-module)
- [Alumni Module](#alumni-module)
- [Staff Module](#staff-module)
- [Utilities Module](#utilities-module)

---

## 🔐 Authentication

### Login

```http
POST /api/v1/auth/login
Content-Type: application/json

{
  "email": "admin@example.com",
  "password": "password"
}
```

**Response:**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "token": {
      "access_token": "eyJhbGciOiJIUzI1NiIs...",
      "refresh_token": "eyJhbGciOiJIUzI1NiIs...",
      "token_type": "bearer",
      "expires_in": 3600
    },
    "user": {
      "id": "uuid",
      "email": "admin@example.com",
      "role": "admin_pesantren",
      "pesantren_id": "uuid",
      "permissions": ["admin:dashboard", "admin:manage_santri", ...]
    }
  }
}
```

### Refresh Token

```http
POST /api/v1/auth/refresh
Content-Type: application/json

{
  "refresh_token": "eyJhbGciOiJIUzI1NiIs..."
}
```

### Get Current User

```http
GET /api/v1/auth/me
Authorization: Bearer {token}
```

### Change Password

```http
POST /api/v1/auth/change-password
Authorization: Bearer {token}
Content-Type: application/json

{
  "current_password": "oldpassword",
  "new_password": "newpassword",
  "confirm_password": "newpassword"
}
```

### Logout

```http
POST /api/v1/auth/logout
Authorization: Bearer {token}
```

---

## 📚 Academic Module

### Classes

#### List Classes

```http
GET /api/v1/academic/classes
Authorization: Bearer {token}
Query Parameters:
  - academic_year_id: UUID (optional)
  - is_active: boolean (optional)
  - skip: integer (default: 0)
  - limit: integer (default: 20)
```

**Response:**
```json
{
  "success": true,
  "message": "Classes retrieved successfully",
  "data": [
    {
      "id": "uuid",
      "name": "1A",
      "level": "SMP",
      "academic_year": "2024/2025",
      "class_teacher": "Ustadz Ahmad",
      "capacity": 30,
      "student_count": 25,
      "is_active": true,
      "created_at": "2024-01-15T10:00:00Z"
    }
  ],
  "meta": {
    "page": 1,
    "per_page": 20,
    "total": 5,
    "total_pages": 1,
    "has_next": false,
    "has_prev": false
  }
}
```

#### Get Class Detail

```http
GET /api/v1/academic/classes/{class_id}
Authorization: Bearer {token}
```

### Subjects

#### List Subjects

```http
GET /api/v1/academic/subjects
Authorization: Bearer {token}
Query Parameters:
  - category: string (quran, hadith, fiqh, arabic, general, tahfidz)
  - is_active: boolean (optional)
  - skip: integer (default: 0)
  - limit: integer (default: 20)
```

### Attendance

#### List Attendance

```http
GET /api/v1/academic/attendance
Authorization: Bearer {token}
Query Parameters:
  - class_id: UUID (optional)
  - subject_id: UUID (optional)
  - date_from: date (optional)
  - date_to: date (optional)
  - status: string (present, absent, sick, permission, late)
  - skip: integer (default: 0)
  - limit: integer (default: 20)
```

### Grades

#### List Grades

```http
GET /api/v1/academic/grades
Authorization: Bearer {token}
Query Parameters:
  - santri_id: UUID (optional)
  - class_id: UUID (optional)
  - subject_id: UUID (optional)
  - grade_type: string (daily, midterm, final, practice)
  - skip: integer (default: 0)
  - limit: integer (default: 20)
```

### Teaching Assignments

#### List Teaching Assignments

```http
GET /api/v1/academic/teaching-assignments
Authorization: Bearer {token}
Query Parameters:
  - ustadz_id: UUID (optional)
  - class_id: UUID (optional)
  - subject_id: UUID (optional)
  - is_active: boolean (optional)
  - skip: integer (default: 0)
  - limit: integer (default: 20)
```

---

## 💰 Finance Module

### Payment Types

#### List Payment Types

```http
GET /api/v1/finance/payment-types
Authorization: Bearer {token}
Query Parameters:
  - type: string (spp, dormitory, development, other)
  - is_active: boolean (optional)
  - skip: integer (default: 0)
  - limit: integer (default: 20)
```

**Response:**
```json
{
  "success": true,
  "message": "Payment types retrieved successfully",
  "data": [
    {
      "id": "uuid",
      "name": "SPP Bulanan",
      "type": "spp",
      "amount": 500000,
      "frequency": "monthly",
      "description": "SPP bulanan santri",
      "is_active": true,
      "created_at": "2024-01-15T10:00:00Z"
    }
  ],
  "meta": {
    "page": 1,
    "per_page": 20,
    "total": 4,
    "total_pages": 1,
    "has_next": false,
    "has_prev": false
  }
}
```

#### Get Payment Type Detail

```http
GET /api/v1/finance/payment-types/{payment_type_id}
Authorization: Bearer {token}
```

### Payments

#### List Payments

```http
GET /api/v1/finance/payments
Authorization: Bearer {token}
Query Parameters:
  - santri_id: UUID (optional)
  - payment_type_id: UUID (optional)
  - status: string (pending, paid, overdue, cancelled, partial)
  - date_from: date (optional)
  - date_to: date (optional)
  - period_year: integer (optional)
  - period_month: integer (optional)
  - skip: integer (default: 0)
  - limit: integer (default: 20)
```

#### Get Payment Detail

```http
GET /api/v1/finance/payments/{payment_id}
Authorization: Bearer {token}
```

### Financial Reports

#### Get Financial Summary

```http
GET /api/v1/finance/reports/summary
Authorization: Bearer {token}
Query Parameters:
  - date_from: date (optional)
  - date_to: date (optional)
```

**Response:**
```json
{
  "success": true,
  "message": "Financial summary retrieved successfully",
  "data": {
    "period": {
      "from": "2024-01-01",
      "to": "2024-01-31"
    },
    "summary": {
      "total_payments": 150,
      "total_amount": 75000000,
      "outstanding_amount": 5000000
    },
    "by_status": {
      "counts": {
        "paid": 120,
        "pending": 20,
        "overdue": 10
      },
      "amounts": {
        "paid": 60000000,
        "pending": 10000000,
        "overdue": 5000000
      }
    },
    "by_type": {
      "spp": 50000000,
      "dormitory": 15000000,
      "development": 10000000
    }
  }
}
```

#### Get Arrears Report

```http
GET /api/v1/finance/reports/arrears
Authorization: Bearer {token}
```

---

## 📊 Reports Module

### Santri Reports

#### Get Santri Summary

```http
GET /api/v1/reports/santri/{santri_id}/summary
Authorization: Bearer {token}
Query Parameters:
  - academic_year_id: UUID (optional)
```

**Response:**
```json
{
  "success": true,
  "message": "Santri summary retrieved successfully",
  "data": {
    "santri": {
      "id": "uuid",
      "nis": "12345",
      "full_name": "Ahmad Fulan",
      "class": "1A",
      "status": "active",
      "enrollment_date": "2024-01-15"
    },
    "academic": {
      "grades_by_subject": {
        "Al-Quran": [
          {
            "type": "daily",
            "score": "85",
            "percentage": 85,
            "date": "2024-01-20"
          }
        ]
      },
      "subject_averages": {
        "Al-Quran": 85,
        "Hadith": 80
      },
      "overall_average": 82.5,
      "total_subjects": 5
    },
    "attendance": {
      "total_sessions": 20,
      "present": 18,
      "absent": 1,
      "sick": 1,
      "attendance_percentage": 90
    },
    "finance": {
      "total_payments": 12,
      "total_paid": 6000000,
      "total_pending": 500000,
      "total_overdue": 0
    }
  }
}
```

#### Generate Rapor (Report Card)

```http
GET /api/v1/reports/santri/{santri_id}/rapor
Authorization: Bearer {token}
Query Parameters:
  - academic_year_id: UUID (optional)
  - semester: string (odd/even, optional)
```

---

## 🎓 Alumni Module

### List Alumni

```http
GET /api/v1/alumni
Authorization: Bearer {token}
Query Parameters:
  - graduation_year: integer (optional)
  - current_status: string (studying, working, entrepreneur, other, unemployed)
  - search: string (optional)
  - skip: integer (default: 0)
  - limit: integer (default: 20)
```

### Get Alumni Detail

```http
GET /api/v1/alumni/{alumni_id}
Authorization: Bearer {token}
```

### Get Alumni Statistics

```http
GET /api/v1/alumni/stats/summary
Authorization: Bearer {token}
```

**Response:**
```json
{
  "success": true,
  "message": "Alumni statistics retrieved successfully",
  "data": {
    "total_alumni": 250,
    "by_graduation_year": {
      "2024": 50,
      "2023": 45,
      "2022": 40
    },
    "by_current_status": {
      "studying": 100,
      "working": 120,
      "entrepreneur": 20,
      "other": 10
    },
    "recent_alumni_count": 50,
    "top_graduation_years": [
      ["2024", 50],
      ["2023", 45],
      ["2022", 40]
    ]
  }
}
```

---

## 👥 Staff Module

### List Staff

```http
GET /api/v1/staff
Authorization: Bearer {token}
Query Parameters:
  - department: string (optional)
  - employment_status: string (permanent, contract, internship, freelance)
  - is_active: boolean (optional)
  - search: string (optional)
  - skip: integer (default: 0)
  - limit: integer (default: 20)
```

### Get Staff Detail

```http
GET /api/v1/staff/{staff_id}
Authorization: Bearer {token}
```

### List Departments

```http
GET /api/v1/staff/departments/list
Authorization: Bearer {token}
```

---

## 🛠️ Utilities Module

### Academic Years

#### List Academic Years

```http
GET /api/v1/utils/academic-years
Authorization: Bearer {token}
```

#### Get Current Academic Year

```http
GET /api/v1/utils/academic-years/current
Authorization: Bearer {token}
```

### Class Promotion

```http
POST /api/v1/utils/class-promotion
Authorization: Bearer {token}
Content-Type: application/json

{
  "from_class_id": "uuid",
  "to_class_id": "uuid"
}
```

### Audit Logs

#### List Audit Logs

```http
GET /api/v1/utils/audit-logs
Authorization: Bearer {token}
Query Parameters:
  - action: string (optional)
  - resource_type: string (optional)
  - user_id: UUID (optional)
  - date_from: date (optional)
  - date_to: date (optional)
  - skip: integer (default: 0)
  - limit: integer (default: 20)
```

### Dashboard Statistics

```http
GET /api/v1/utils/dashboard/stats
Authorization: Bearer {token}
```

**Response:**
```json
{
  "success": true,
  "message": "Dashboard statistics retrieved successfully",
  "data": {
    "total_santri": 500,
    "active_santri": 450,
    "active_ustadz": 25,
    "active_classes": 15,
    "monthly_revenue": 25000000,
    "outstanding_amount": 5000000
  }
}
```

### System Information

```http
GET /api/v1/utils/system/info
```

---

## 📦 Response Format

### Success Response

```json
{
  "success": true,
  "message": "Success message",
  "data": {},
  "meta": {
    "page": 1,
    "per_page": 20,
    "total": 100,
    "total_pages": 5,
    "has_next": true,
    "has_prev": false
  }
}
```

### Error Response

```json
{
  "success": false,
  "message": "Error message",
  "errors": {
    "field_name": ["Error message"]
  },
  "error_code": "ERROR_CODE"
}
```

---

## 🚦 HTTP Status Codes

| Code | Description |
|------|-------------|
| 200 | Success |
| 201 | Created |
| 400 | Bad Request |
| 401 | Unauthorized |
| 403 | Forbidden |
| 404 | Not Found |
| 422 | Unprocessable Entity |
| 500 | Internal Server Error |

---

## 🔐 Authentication

Semua endpoints (kecuali auth login) memerlukan Bearer token:

```http
Authorization: Bearer {your_jwt_token}
```

### Token Types

- **Access Token**: Berlaku 1 jam, digunakan untuk API requests
- **Refresh Token**: Berlaku 7 hari, digunakan untuk mendapatkan access token baru

---

## 📚 Error Codes

| Code | Description |
|------|-------------|
| AUTH_FAILED | Authentication failed |
| INVALID_TOKEN | Invalid or expired token |
| INSUFFICIENT_PERMISSIONS | User lacks required permissions |
| VALIDATION_ERROR | Request validation failed |
| RESOURCE_NOT_FOUND | Requested resource not found |
| DUPLICATE_ENTRY | Resource already exists |
| DATABASE_ERROR | Database operation failed |
| INTERNAL_SERVER_ERROR | Internal server error |

---

## 🚀 Rate Limiting

API menggunakan rate limiting untuk mencegah abuse:

- **Default**: 100 requests per minute per IP
- **Authentication**: 10 login attempts per minute per IP

---

## 📖 Pagination

List endpoints mendukung pagination dengan parameter:

- `skip`: Number of records to skip
- `limit`: Number of records to return (max: 100)

Response mencakup metadata pagination:

```json
{
  "meta": {
    "page": 1,
    "per_page": 20,
    "total": 100,
    "total_pages": 5,
    "has_next": true,
    "has_prev": false
  }
}
```

---

## 🧪 Testing

Untuk testing API, Anda dapat menggunakan:

1. **Swagger UI**: http://localhost:8000/docs
2. **Postman**: Import OpenAPI schema dari http://localhost:8000/openapi.json
3. **cURL**: Command-line tool
4. **httpie**: Modern HTTP client

---

**API Version**: v1  
**Last Updated**: January 2024
