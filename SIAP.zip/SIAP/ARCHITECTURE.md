# SIAP - Sistem Induk Administrasi Pesantren
## Arsitektur Teknis & Dokumentasi Proyek

---

## 📋 Ringkasan Proyek

SIAP adalah platform SaaS modern untuk manajemen Pondok Pesantren yang dirancang dengan arsitektur microservices-ready, security-first, dan scalable untuk mendukung institusi pendidikan Islam dari skala kecil hingga enterprise.

---

## 🏗️ Arsitektur Sistem

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        Frontend Layer                           │
├─────────────────────────────────────────────────────────────────┤
│  React 18 + TypeScript + Tailwind CSS + shadcn/ui              │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐            │
│  │  SuperAdmin │  │AdminPesantren│  │  Ustadz/Santri│           │
│  │  Dashboard  │  │  Dashboard  │  │   Dashboard   │           │
│  └─────────────┘  └─────────────┘  └─────────────┘            │
└─────────────────────────────────────────────────────────────────┘
                                │
                    ┌───────────┴───────────┐
                    │    API Gateway        │
                    │   (Nginx / Kong)      │
                    └───────────┬───────────┘
                                │
┌─────────────────────────────────────────────────────────────────┐
│                      Backend Layer                              │
├─────────────────────────────────────────────────────────────────┤
│  FastAPI + Python 3.12 + Async Architecture                     │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐            │
│  │   Auth      │  │  Academic   │  │   Finance   │           │
│  │  Service    │  │  Service    │  │  Service    │           │
│  └─────────────┘  └─────────────┘  └─────────────┘            │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐            │
│  │   Report    │  │   Alumni    │  │    Staff    │           │
│  │  Service    │  │  Service    │  │  Service    │           │
│  └─────────────┘  └─────────────┘  └─────────────┘            │
└─────────────────────────────────────────────────────────────────┘
                                │
┌─────────────────────────────────────────────────────────────────┐
│                      Data Layer                                 │
├─────────────────────────────────────────────────────────────────┤
│  PostgreSQL 15 + Redis (Cache + Sessions)                       │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐            │
│  │  Primary DB │  │   Read      │  │    Cache    │           │
│  │   (Write)   │  │  Replica    │  │   (Redis)   │           │
│  └─────────────┘  └─────────────┘  └─────────────┘            │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔧 Stack Teknologi

### Backend
- **Framework**: FastAPI 0.104+ (Async-first, OpenAPI auto-generation)
- **Language**: Python 3.12
- **Authentication**: JWT + OAuth2 with refresh tokens
- **Authorization**: Role-Based Access Control (RBAC) + Fine-grained permissions
- **ORM**: SQLAlchemy 2.0 with AsyncSession
- **Database**: PostgreSQL 15 (with row-level security)
- **Cache**: Redis 7 (sessions, caching, rate limiting)
- **Task Queue**: Celery + Redis (background jobs)
- **File Storage**: MinIO (S3-compatible) / Local (development)
- **Testing**: Pytest + Factory Boy + Coverage
- **Documentation**: OpenAPI 3.0 + Swagger UI + ReDoc

### Frontend
- **Framework**: React 18.2 + TypeScript 5.x
- **Styling**: Tailwind CSS 3.4 + shadcn/ui
- **State Management**: Zustand + React Query (TanStack Query)
- **Routing**: React Router v6
- **Forms**: React Hook Form + Zod validation
- **Charts**: Recharts + Tremor
- **Tables**: TanStack Table
- **PDF Generation**: jsPDF + html2canvas
- **Excel**: SheetJS

### Infrastructure
- **Container**: Docker + Docker Compose
- **Reverse Proxy**: Nginx
- **Monitoring**: Prometheus + Grafana (optional)
- **Logging**: Structured JSON logging with rotation

---

## 👥 Sistem Autentikasi & Otorisasi

### Role Hierarchy

```
┌─────────────────────────────────────────────────────────────┐
│                    SUPER_ADMIN                              │
│  • Full system access                                       │
│  • Manage pesantren instances                               │
│  • System configuration                                     │
│  • User management across all pesantren                     │
└──────────────────────┬────────────────────────────────────┘
                       │
┌──────────────────────┴────────────────────────────────────┐
│                 ADMIN_PESANTREN                           │
│  • Manage single pesantren                                │
│  • Academic management                                    │
│  • Financial management                                   │
│  • Staff & alumni management                              │
│  • Report generation                                      │
└──────────────────────┬────────────────────────────────────┘
                       │
┌──────────────────────┴────────────────────────────────────┐
│                      USTADZ                               │
│  • Teaching management                                    │
│  • Attendance marking                                     │
│  • Student grading                                        │
│  • View student progress                                  │
└──────────────────────┬────────────────────────────────────┘
                       │
┌──────────────────────┴────────────────────────────────────┐
│                      SANTRI                               │
│  • View own academic records                              │
│  • View attendance history                                │
│  • View grades & reports                                  │
│  • Profile management                                     │
└─────────────────────────────────────────────────────────────┘
```

### Permission Matrix

| Module | Super Admin | Admin Pesantren | Ustadz | Santri |
|--------|-------------|-----------------|--------|--------|
| **Academic** | Full | Full | Limited | Read-only |
| **Finance** | Full | Full | No Access | Read-only |
| **Reports** | Full | Full | Limited | Read-only |
| **Alumni** | Full | Full | Read | No Access |
| **Staff** | Full | Full | Read | No Access |
| **Settings** | Full | Limited | No Access | No Access |

---

## 📊 Database Architecture

### Database Design Principles

1. **Multi-tenancy Ready**: Setiap pesantren terisolasi dengan `pesantren_id`
2. **Soft Delete**: Semua data penting menggunakan soft delete dengan `deleted_at`
3. **Audit Trail**: Logging semua perubahan data kritis
4. **Indexing Strategy**: Index pada kolom yang sering di-query
5. **Data Integrity**: Foreign keys dan constraints yang ketat

### Entity Relationship Diagram

```mermaid
erDiagram
    PESANTREN ||--o{ USER : has
    PESANTREN ||--o{ CLASS : has
    PESANTREN ||--o{ STAFF : has
    PESANTREN ||--o{ PAYMENT_TYPE : has
    PESANTREN ||--o{ ACADEMIC_YEAR : has
    
    USER ||--o{ SANTRI : "can be"
    USER ||--o{ USTADZ : "can be"
    USER ||--o{ ADMIN : "can be"
    
    SANTRI ||--o{ SANTRI_CLASS : enrolls
    CLASS ||--o{ SANTRI_CLASS : has
    
    SANTRI_CLASS ||--o{ ATTENDANCE : has
    SANTRI_CLASS ||--o{ GRADE : has
    
    SUBJECT ||--o{ GRADE : has
    USTADZ ||--o{ TEACHING_ASSIGNMENT : teaches
    CLASS ||--o{ TEACHING_ASSIGNMENT : has
    SUBJECT ||--o{ TEACHING_ASSIGNMENT : has
    
    SANTRI ||--o{ PAYMENT : makes
    PAYMENT_TYPE ||--o{ PAYMENT : "defines"
    
    SANTRI ||--o{ ALUMNI : becomes
    
    USER {
        uuid id PK
        string email UK
        string password_hash
        enum role
        uuid pesantren_id FK
        boolean is_active
        datetime created_at
        datetime updated_at
    }
    
    SANTRI {
        uuid id PK
        uuid user_id FK
        string nis UK
        string full_name
        date birth_date
        string birth_place
        string address
        string phone
        date enrollment_date
        enum status
        uuid current_class_id FK
    }
    
    CLASS {
        uuid id PK
        uuid pesantren_id FK
        string name
        string level
        uuid academic_year_id FK
        uuid teacher_id FK
        enum status
    }
    
    PAYMENT {
        uuid id PK
        uuid santri_id FK
        uuid payment_type_id FK
        decimal amount
        date payment_date
        string status
        string proof_number
    }
```

### Database Schema Details

#### Core Tables

**pesantren**
- `id` (UUID, PK)
- `name` (VARCHAR 255)
- `address` (TEXT)
- `phone` (VARCHAR 20)
- `email` (VARCHAR 100)
- `logo_url` (TEXT, nullable)
- `is_active` (BOOLEAN, default: true)
- `created_at`, `updated_at`, `deleted_at`

**users**
- `id` (UUID, PK)
- `pesantren_id` (UUID, FK)
- `email` (VARCHAR 100, unique)
- `password_hash` (VARCHAR 255)
- `role` (ENUM: super_admin, admin_pesantren, ustadz, santri)
- `is_active` (BOOLEAN)
- `last_login` (TIMESTAMP)
- `created_at`, `updated_at`

**santri**
- `id` (UUID, PK)
- `user_id` (UUID, FK, nullable)
- `pesantren_id` (UUID, FK)
- `nis` (VARCHAR 50, unique)
- `full_name` (VARCHAR 255)
- `birth_date` (DATE)
- `birth_place` (VARCHAR 100)
- `gender` (ENUM: L, P)
- `address` (TEXT)
- `phone` (VARCHAR 20)
- `guardian_name` (VARCHAR 255)
- `guardian_phone` (VARCHAR 20)
- `enrollment_date` (DATE)
- `graduation_date` (DATE, nullable)
- `status` (ENUM: active, graduated, dropped)
- `current_class_id` (UUID, FK, nullable)

**ustadz**
- `id` (UUID, PK)
- `user_id` (UUID, FK)
- `pesantren_id` (UUID, FK)
- `nip` (VARCHAR 50, unique, nullable)
- `full_name` (VARCHAR 255)
- `specialization` (VARCHAR 255)
- `education` (TEXT)
- `experience` (TEXT)
- `phone` (VARCHAR 20)
- `address` (TEXT)
- `is_active` (BOOLEAN)

**class**
- `id` (UUID, PK)
- `pesantren_id` (UUID, FK)
- `academic_year_id` (UUID, FK)
- `name` (VARCHAR 100) - e.g., "1A", "2B"
- `level` (VARCHAR 50) - e.g., "SMP", "SMA", "Tahfidz"
- `class_teacher_id` (UUID, FK to ustadz, nullable)
- `capacity` (INTEGER)
- `description` (TEXT, nullable)
- `is_active` (BOOLEAN)

**santri_class** (Many-to-Many)
- `id` (UUID, PK)
- `santri_id` (UUID, FK)
- `class_id` (UUID, FK)
- `academic_year_id` (UUID, FK)
- `enrollment_date` (DATE)
- `is_active` (BOOLEAN)

**subject**
- `id` (UUID, PK)
- `pesantren_id` (UUID, FK)
- `name` (VARCHAR 255)
- `code` (VARCHAR 50)
- `category` (ENUM: quran, hadith, fiqh, arabic, general)
- `credit_hours` (INTEGER)
- `description` (TEXT, nullable)

**teaching_assignment**
- `id` (UUID, PK)
- `ustadz_id` (UUID, FK)
- `class_id` (UUID, FK)
- `subject_id` (UUID, FK)
- `academic_year_id` (UUID, FK)
- `schedule_day` (ENUM: Senin-Sabtu)
- `schedule_time_start` (TIME)
- `schedule_time_end` (TIME)
- `is_active` (BOOLEAN)

**attendance**
- `id` (UUID, PK)
- `teaching_assignment_id` (UUID, FK)
- `santri_id` (UUID, FK)
- `date` (DATE)
- `status` (ENUM: present, absent, sick, permission, late)
- `notes` (TEXT, nullable)
- `recorded_by` (UUID, FK to users)
- `created_at`

**grade**
- `id` (UUID, PK)
- `santri_id` (UUID, FK)
- `teaching_assignment_id` (UUID, FK)
- `grade_type` (ENUM: daily, midterm, final)
- `score` (DECIMAL 5,2)
- `max_score` (DECIMAL 5,2, default: 100)
- `date` (DATE)
- `notes` (TEXT, nullable)
- `recorded_by` (UUID, FK to users)

**payment_type**
- `id` (UUID, PK)
- `pesantren_id` (UUID, FK)
- `name` (VARCHAR 255)
- `type` (ENUM: spp, dormitory, development, other)
- `amount` (DECIMAL 12,2)
- `frequency` (ENUM: monthly, yearly, one_time)
- `is_active` (BOOLEAN)
- `description` (TEXT, nullable)

**payment**
- `id` (UUID, PK)
- `santri_id` (UUID, FK)
- `payment_type_id` (UUID, FK)
- `amount` (DECIMAL 12,2)
- `payment_date` (DATE)
- `due_date` (DATE)
- `status` (ENUM: pending, paid, overdue, cancelled)
- `payment_method` (VARCHAR 50)
- `reference_number` (VARCHAR 100, nullable)
- `notes` (TEXT, nullable)
- `created_by` (UUID, FK to users)

**alumni**
- `id` (UUID, PK)
- `santri_id` (UUID, FK, unique)
- `graduation_year` (INTEGER)
- `last_class` (VARCHAR 100)
- `current_status` (ENUM: studying, working, entrepreneur, other)
- `institution_name` (VARCHAR 255, nullable)
- `job_title` (VARCHAR 255, nullable)
- `company_name` (VARCHAR 255, nullable)
- `contact_info` (TEXT, nullable)

**staff**
- `id` (UUID, PK)
- `pesantren_id` (UUID, FK)
- `full_name` (VARCHAR 255)
- `position` (VARCHAR 255)
- `department` (VARCHAR 100)
- `employment_status` (ENUM: permanent, contract, internship)
- `phone` (VARCHAR 20)
- `email` (VARCHAR 100, nullable)
- `bio` (TEXT, nullable)
- `photo_url` (TEXT, nullable)
- `is_active` (BOOLEAN)

**academic_year**
- `id` (UUID, PK)
- `pesantren_id` (UUID, FK)
- `name` (VARCHAR 100) - e.g., "2024/2025"
- `start_date` (DATE)
- `end_date` (DATE)
- `is_active` (BOOLEAN)
- `is_current` (BOOLEAN)

**audit_log**
- `id` (UUID, PK)
- `user_id` (UUID, FK)
- `action` (VARCHAR 100)
- `resource_type` (VARCHAR 50)
- `resource_id` (UUID)
- `old_values` (JSON, nullable)
- `new_values` (JSON, nullable)
- `ip_address` (INET)
- `user_agent` (TEXT, nullable)
- `created_at`

---

## 🔐 Security Architecture

### Authentication Flow

```
1. Client → POST /api/v1/auth/login {email, password}
2. Server → Validate credentials
3. Server → Generate JWT (Access Token + Refresh Token)
4. Server → Store Refresh Token in Redis
5. Server → Return {access_token, refresh_token, user}
6. Client → Store tokens securely (httpOnly cookie recommended)
7. Client → Include access_token in Authorization header
```

### Token Strategy

- **Access Token**: JWT, 15 menit expiry, contains: user_id, role, pesantren_id
- **Refresh Token**: JWT, 7 hari expiry, stored in Redis with user session
- **Token Validation**: Middleware memverifikasi signature, expiry, dan blacklist

### Authorization Middleware

```python
# Pseudocode
async def require_role(required_roles: List[str]):
    token = extract_token_from_header()
    payload = decode_jwt(token)
    
    if payload.role not in required_roles:
        raise ForbiddenError()
    
    # Inject user context ke request
    request.current_user = payload
    
    return await handler(request)
```

### Security Best Practices

1. **Password Security**: bcrypt dengan salt rounds 12
2. **SQL Injection**: Gunakan SQLAlchemy ORM dengan parameter binding
3. **XSS Protection**: Sanitize semua input user
4. **CSRF Protection**: Token-based CSRF protection untuk state-changing operations
5. **Rate Limiting**: Redis-based rate limiting per user/IP
6. **CORS**: Strict origin whitelist
7. **Input Validation**: Pydantic models untuk semua request/response
8. **File Upload**: Validasi mime type, size limit, scan for malware
9. **Audit Logging**: Semua action kritis tercatat di audit_log

---

## 🚀 API Design

### RESTful API Versioning

- Base URL: `/api/v1/`
- Versioning via URL path untuk backward compatibility
- Content-Type: `application/json`
- Pagination: Cursor-based untuk performance

### Response Format Standard

```json
{
  "success": true,
  "message": "Success message",
  "data": {},
  "meta": {
    "page": 1,
    "per_page": 20,
    "total": 100,
    "total_pages": 5
  }
}
```

### Error Response Format

```json
{
  "success": false,
  "message": "Validation error",
  "errors": {
    "field_name": ["error message"]
  }
}
```

### API Endpoints Overview

#### Authentication Module
- `POST /api/v1/auth/login` - Login
- `POST /api/v1/auth/logout` - Logout
- `POST /api/v1/auth/refresh` - Refresh token
- `GET /api/v1/auth/me` - Get current user
- `POST /api/v1/auth/change-password` - Change password

#### Academic Module
- `GET /api/v1/academic/classes` - List classes
- `POST /api/v1/academic/classes` - Create class
- `PUT /api/v1/academic/classes/{id}` - Update class
- `DELETE /api/v1/academic/classes/{id}` - Delete class
- `GET /api/v1/academic/santri` - List santri
- `POST /api/v1/academic/santri` - Create santri
- `GET /api/v1/academic/santri/{id}` - Get santri detail
- `PUT /api/v1/academic/santri/{id}` - Update santri
- `GET /api/v1/academic/subjects` - List subjects
- `POST /api/v1/academic/subjects` - Create subject
- `GET /api/v1/academic/teaching-assignments` - List teaching assignments
- `POST /api/v1/academic/attendance` - Record attendance
- `GET /api/v1/academic/attendance` - Get attendance records
- `POST /api/v1/academic/grades` - Input grades
- `GET /api/v1/academic/grades` - Get grades

#### Finance Module
- `GET /api/v1/finance/payment-types` - List payment types
- `POST /api/v1/finance/payment-types` - Create payment type
- `PUT /api/v1/finance/payment-types/{id}` - Update payment type
- `GET /api/v1/finance/payments` - List payments
- `POST /api/v1/finance/payments` - Create payment
- `PUT /api/v1/finance/payments/{id}` - Update payment
- `GET /api/v1/finance/reports/summary` - Financial summary
- `GET /api/v1/finance/reports/arrears` - Arrears report

#### Report Module
- `GET /api/v1/reports/santri/{id}` - Get santri report
- `POST /api/v1/reports/santri/{id}/generate` - Generate PDF report
- `GET /api/v1/reports/attendance/export` - Export attendance
- `GET /api/v1/reports/grades/export` - Export grades

#### Alumni Module
- `GET /api/v1/alumni` - List alumni
- `POST /api/v1/alumni` - Create alumni
- `PUT /api/v1/alumni/{id}` - Update alumni
- `GET /api/v1/alumni/stats` - Alumni statistics

#### Staff Module
- `GET /api/v1/staff` - List staff
- `POST /api/v1/staff` - Create staff
- `PUT /api/v1/staff/{id}` - Update staff
- `DELETE /api/v1/staff/{id}` - Delete staff

#### Utility Module
- `GET /api/v1/utils/academic-years` - List academic years
- `POST /api/v1/utils/academic-years` - Create academic year
- `POST /api/v1/utils/class-promotion` - Promote students
- `GET /api/v1/utils/audit-logs` - View audit logs

---

## 📁 Struktur Proyek

### Backend Structure (FastAPI)

```
backend/
├── app/
│   ├── __init__.py
│   ├── main.py                 # Application entry point
│   ├── config.py               # Configuration settings
│   ├── dependencies.py         # FastAPI dependencies
│   │
│   ├── api/                    # API modules
│   │   ├── __init__.py
│   │   ├── v1/
│   │   │   ├── __init__.py
│   │   │   ├── auth.py         # Authentication endpoints
│   │   │   ├── academic.py     # Academic endpoints
│   │   │   ├── finance.py      # Finance endpoints
│   │   │   ├── reports.py      # Report endpoints
│   │   │   ├── alumni.py       # Alumni endpoints
│   │   │   ├── staff.py        # Staff endpoints
│   │   │   └── utils.py        # Utility endpoints
│   │   │
│   ├── core/                   # Core business logic
│   │   ├── __init__.py
│   │   ├── security.py         # JWT, password hashing
│   │   ├── permissions.py      # Role-based permissions
│   │   ├── exceptions.py       # Custom exceptions
│   │   └── validators.py       # Business validators
│   │
│   ├── models/                 # SQLAlchemy models
│   │   ├── __init__.py
│   │   ├── user.py
│   │   ├── santri.py
│   │   ├── ustadz.py
│   │   ├── academic.py
│   │   ├── finance.py
│   │   └── base.py             # Base model with soft delete
│   │
│   ├── schemas/                # Pydantic schemas
│   │   ├── __init__.py
│   │   ├── auth.py
│   │   ├── user.py
│   │   ├── santri.py
│   │   ├── academic.py
│   │   ├── finance.py
│   │   └── response.py         # Standard response format
│   │
│   ├── services/               # Business services
│   │   ├── __init__.py
│   │   ├── auth_service.py
│   │   ├── santri_service.py
│   │   ├── academic_service.py
│   │   ├── finance_service.py
│   │   └── report_service.py
│   │
│   ├── utils/                  # Utility functions
│   │   ├── __init__.py
│   │   ├── database.py         # Database connection
│   │   ├── cache.py            # Redis utilities
│   │   ├── pdf_generator.py    # PDF generation
│   │   └── excel_exporter.py   # Excel export
│   │
│   └── middleware/             # Custom middleware
│       ├── __init__.py
│       ├── auth_middleware.py
│       ├── error_handler.py
│       └── audit_middleware.py
│
├── migrations/                 # Database migrations
│   ├── alembic.ini
│   ├── env.py
│   └── versions/
│
├── tests/                      # Test files
│   ├── __init__.py
│   ├── conftest.py
│   ├── test_auth.py
│   ├── test_academic.py
│   └── test_finance.py
│
├── requirements/               # Requirements files
│   ├── base.txt
│   ├── dev.txt
│   └── prod.txt
│
├── docker/                     # Docker configurations
│   ├── Dockerfile
│   └── entrypoint.sh
│
├── .env.example
├── .gitignore
├── pyproject.toml
└── README.md
```

### Frontend Structure (React)

```
frontend/
├── src/
│   ├── main.tsx                # Application entry
│   ├── App.tsx                 # Root component
│   ├── index.css               # Global styles
│   │
│   ├── components/             # Reusable components
│   │   ├── ui/                 # shadcn/ui components
│   │   ├── layout/
│   │   │   ├── Sidebar.tsx
│   │   │   ├── Header.tsx
│   │   │   └── Layout.tsx
│   │   ├── auth/
│   │   │   ├── LoginForm.tsx
│   │   │   └── ProtectedRoute.tsx
│   │   ├── dashboard/
│   │   │   ├── StatsCard.tsx
│   │   │   └── Chart.tsx
│   │   ├── tables/
│   │   │   ├── DataTable.tsx
│   │   │   └── Pagination.tsx
│   │   └── forms/
│   │       ├── SantriForm.tsx
│   │       └── PaymentForm.tsx
│   │
│   ├── pages/                  # Page components
│   │   ├── auth/
│   │   │   └── LoginPage.tsx
│   │   ├── dashboard/
│   │   │   ├── SuperAdminDashboard.tsx
│   │   │   ├── AdminPesantrenDashboard.tsx
│   │   │   ├── UstadzDashboard.tsx
│   │   │   └── SantriDashboard.tsx
│   │   ├── academic/
│   │   │   ├── ClassesPage.tsx
│   │   │   ├── SantriPage.tsx
│   │   │   ├── AttendancePage.tsx
│   │   │   └── GradesPage.tsx
│   │   ├── finance/
│   │   │   ├── PaymentTypesPage.tsx
│   │   │   ├── PaymentsPage.tsx
│   │   │   └── FinancialReportPage.tsx
│   │   ├── reports/
│   │   │   ├── SantriReportPage.tsx
│   │   │   └── RaporPage.tsx
│   │   ├── alumni/
│   │   │   └── AlumniPage.tsx
│   │   └── staff/
│   │       └── StaffPage.tsx
│   │
│   ├── hooks/                  # Custom hooks
│   │   ├── useAuth.ts
│   │   ├── useApi.ts
│   │   └── usePagination.ts
│   │
│   ├── services/               # API services
│   │   ├── api.ts              # Axios instance
│   │   ├── auth.service.ts
│   │   ├── academic.service.ts
│   │   └── finance.service.ts
│   │
│   ├── store/                  # State management (Zustand)
│   │   ├── auth.store.ts
│   │   ├── ui.store.ts
│   │   └── dashboard.store.ts
│   │
│   ├── types/                  # TypeScript types
│   │   ├── auth.types.ts
│   │   ├── user.types.ts
│   │   ├── academic.types.ts
│   │   └── api.types.ts
│   │
│   ├── utils/                  # Utility functions
│   │   ├── constants.ts
│   │   ├── helpers.ts
│   │   └── formatters.ts
│   │
│   └── lib/                    # Library configurations
│       ├── utils.ts
│       └── auth.ts
│
├── public/                     # Static assets
│   └── logo.png
│
├── .env.example
├── .gitignore
├── tailwind.config.js
├── vite.config.ts
└── tsconfig.json
```

---

## 🚀 Deployment Architecture

### Docker Compose (Development)

```yaml
# docker-compose.yml
version: '3.8'

services:
  # Backend API
  backend:
    build: ./backend
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=postgresql+asyncpg://user:pass@db:5432/siap
      - REDIS_URL=redis://redis:6379
    depends_on:
      - db
      - redis
    volumes:
      - ./backend:/app
    
  # Frontend
  frontend:
    build: ./frontend
    ports:
      - "3000:3000"
    environment:
      - VITE_API_URL=http://localhost:8000/api/v1
    volumes:
      - ./frontend:/app
    
  # Database
  db:
    image: postgres:15
    environment:
      - POSTGRES_DB=siap
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=password
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    
  # Redis Cache
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    
  # Nginx Reverse Proxy (Production)
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - backend
      - frontend

volumes:
  postgres_data:
  redis_data:
```

### Production Considerations

1. **SSL/TLS**: HTTPS dengan Let's Encrypt
2. **Database**: PostgreSQL dengan replication
3. **Caching**: Redis cluster
4. **File Storage**: S3-compatible storage
5. **Monitoring**: Prometheus + Grafana
6. **Logging**: ELK Stack atau Loki
7. **Backup**: Automated daily backup
8. **CI/CD**: GitHub Actions atau GitLab CI

---

## 📊 Skalabilitas Strategy

### Horizontal Scaling

1. **Stateless Backend**: FastAPI aplikasi stateless dapat di-scale horizontal
2. **Load Balancer**: Nginx atau cloud load balancer
3. **Database Scaling**: Read replicas untuk query heavy
4. **Caching**: Redis cluster untuk distributed caching

### Modular Architecture

1. **Service Separation**: Setiap module dapat di-extract menjadi service sendiri
2. **Message Queue**: RabbitMQ atau Kafka untuk async communication
3. **Microservices Ready**: Struktur kode siap untuk di-split

### Performance Optimization

1. **Database Indexing**: Index pada kolom yang sering di-query
2. **Query Optimization**: Eager loading, select related
3. **Caching Strategy**: Cache frequently accessed data
4. **CDN**: Untuk static assets dan file uploads

---

## 🔄 Development Workflow

### Git Branch Strategy

```
main (production)
├── develop (staging)
│   ├── feature/auth-module
│   ├── feature/academic-module
│   └── feature/finance-module
└── hotfix/critical-bug
```

### Code Quality

1. **Type Hints**: Python 3.12 type hints untuk semua function
2. **Linting**: Ruff atau Flake8
3. **Formatting**: Black (Python), Prettier (TypeScript)
4. **Testing**: Pytest untuk backend, Jest untuk frontend
5. **Code Review**: PR review process

### Environment Setup

```bash
# Backend
python -m venv venv
source venv/bin/activate
pip install -r requirements/dev.txt
alembic upgrade head
uvicorn app.main:app --reload

# Frontend
npm install
npm run dev
```

---

## 📈 Monitoring & Observability

### Metrics to Monitor

1. **Application Metrics**: Request rate, response time, error rate
2. **Business Metrics**: User registrations, payment transactions
3. **Infrastructure Metrics**: CPU, memory, disk usage
4. **Database Metrics**: Query performance, connection pool

### Logging Strategy

```python
# Structured JSON logging
{
  "timestamp": "2024-01-15T10:30:00Z",
  "level": "INFO",
  "service": "siap-api",
  "request_id": "uuid",
  "user_id": "uuid",
  "method": "POST",
  "path": "/api/v1/payments",
  "status_code": 201,
  "duration_ms": 150
}
```

### Health Checks

- `/health` - Application health
- `/health/db` - Database connectivity
- `/health/redis` - Redis connectivity

---

## 🎯 Next Steps Implementation

### Phase 1: Foundation (Week 1-2)
1. Setup project structure
2. Implement authentication system
3. Create base models and database setup
4. Setup development environment

### Phase 2: Core Modules (Week 3-4)
1. Implement Academic module
2. Implement Finance module
3. Create basic CRUD operations
4. Setup role-based access control

### Phase 3: Frontend Development (Week 5-6)
1. Setup React project
2. Create dashboard layouts
3. Implement authentication flow
4. Create main feature pages

### Phase 4: Integration & Testing (Week 7)
1. Integrate frontend with backend
2. Write comprehensive tests
3. Performance optimization
4. Security testing

### Phase 5: Deployment & Documentation (Week 8)
1. Setup Docker containers
2. Create deployment scripts
3. Write user documentation
4. Prepare production environment

---

## 📚 Referensi

### Backend
- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [SQLAlchemy Documentation](https://docs.sqlalchemy.org/)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)

### Frontend
- [React Documentation](https://react.dev/)
- [Tailwind CSS Documentation](https://tailwindcss.com/)
- [shadcn/ui Documentation](https://ui.shadcn.com/)

### Architecture
- [Clean Architecture](https://blog.cleancoder.com/uncle-bob/2012/08/13/the-clean-architecture.html)
- [Domain-Driven Design](https://domainlanguage.com/ddd/)
- [Microservices Patterns](https://microservices.io/patterns/)

---

*Dokumen ini merupakan panduan arsitektur untuk pengembangan SIAP. Dokumen akan diperbarui seiring dengan perkembangan proyek.*

**Last Updated**: January 2024
**Version**: 1.0
