# SIAP Deployment Guide

Panduan lengkap untuk deployment SIAP di berbagai environment.

---

## 📋 Daftar Isi

- [Deployment Overview](#deployment-overview)
- [Environment Setup](#environment-setup)
- [Docker Deployment](#docker-deployment)
- [Manual Deployment](#manual-deployment)
- [Production Configuration](#production-configuration)
- [SSL/TLS Setup](#ssltls-setup)
- [Monitoring & Maintenance](#monitoring--maintenance)
- [Troubleshooting](#troubleshooting)

---

## 🎯 Deployment Overview

### Deployment Options

1. **Docker Compose** (Recommended untuk development & small production)
2. **Kubernetes** (Untuk large-scale production)
3. **Manual Deployment** (Untuk custom setup)
4. **Cloud Deployment** (AWS, GCP, Azure, DigitalOcean)

### Prerequisites Checklist

- [ ] Server dengan minimal 2GB RAM, 2 CPU cores
- [ ] OS: Ubuntu 22.04 LTS (recommended)
- [ ] Docker & Docker Compose terinstall
- [ ] Domain name (untuk production)
- [ ] SSL Certificate (Let's Encrypt recommended)
- [ ] Email service (untuk password reset)

---

## 🔧 Environment Setup

### 1. Server Preparation

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install Docker Compose
sudo apt install docker-compose-plugin -y

# Add user to docker group
sudo usermod -aG docker $USER
newgrp docker
```

### 2. Directory Structure

```bash
# Create SIAP directory
mkdir -p /opt/siap
cd /opt/siap

# Create necessary directories
mkdir -p {uploads,nginx/ssl,logs,backups}
```

### 3. Environment Configuration

```bash
# Copy environment file
cp .env.example .env

# Generate secure secret key
SECRET_KEY=$(openssl rand -hex 32)
sed -i "s/SECRET_KEY=.*/SECRET_KEY=$SECRET_KEY/" .env

# Configure database password
DB_PASSWORD=$(openssl rand -hex 16)
sed -i "s/siap_password/$DB_PASSWORD/" .env

# Set production environment
sed -i "s/ENVIRONMENT=development/ENVIRONMENT=production/" .env
sed -i "s/DEBUG=True/DEBUG=False/" .env
```

---

## 🐳 Docker Deployment

### Development Deployment

```bash
# Start all services
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

### Production Deployment

```bash
# Production profile includes nginx
docker-compose --profile production up -d

# Scale backend if needed
docker-compose up -d --scale backend=3
```

### Docker Compose Override

Create `docker-compose.override.yml` untuk custom configuration:

```yaml
version: '3.8'

services:
  backend:
    environment:
      - WORKERS=4
    deploy:
      resources:
        limits:
          memory: 512M
        reservations:
          memory: 256M

  frontend:
    build:
      args:
        - BUILD_ENV=production
```

---

## 🔧 Manual Deployment

### Backend Deployment

#### 1. System Dependencies

```bash
# Install Python 3.12
sudo apt install python3.12 python3.12-venv python3.12-dev -y

# Install PostgreSQL
sudo apt install postgresql postgresql-contrib -y

# Install Redis
sudo apt install redis-server -y

# Install Nginx
sudo apt install nginx -y
```

#### 2. Database Setup

```bash
# Create database and user
sudo -u postgres psql

# In PostgreSQL prompt:
CREATE DATABASE siap;
CREATE USER siap_user WITH PASSWORD 'your-secure-password';
GRANT ALL PRIVILEGES ON DATABASE siap TO siap_user;
\q

# Import schema
sudo -u postgres psql siap < database/schema.sql
```

#### 3. Redis Setup

```bash
# Configure Redis
sudo nano /etc/redis/redis.conf

# Add these lines:
bind 127.0.0.1 ::1
requirepass your-redis-password

# Restart Redis
sudo systemctl restart redis
```

#### 4. Backend Application Setup

```bash
# Create SIAP user
sudo useradd -m -s /bin/bash siap
sudo usermod -aG sudo siap
su - siap

# Clone repository
cd /opt
sudo git clone <repository-url> siap
sudo chown -R siap:siap siap
cd siap/backend

# Create virtual environment
python3.12 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements/prod.txt

# Copy and configure environment
cp .env.example .env
# Edit .env with production values
nano .env
```

#### 5. Systemd Service

Create `/etc/systemd/system/siap-backend.service`:

```ini
[Unit]
Description=SIAP Backend
After=network.target postgresql.service redis.service

[Service]
Type=exec
User=siap
Group=siap
WorkingDirectory=/opt/siap/backend
Environment="PATH=/opt/siap/backend/venv/bin"
EnvironmentFile=/opt/siap/backend/.env
ExecStart=/opt/siap/backend/venv/bin/uvicorn app.main:app --host 0.0.0.0 --port 8000
ExecReload=/bin/kill -HUP $MAINPID
KillMode=mixed
Restart=on-failure
RestartSec=5s

[Install]
WantedBy=multi-user.target
```

Enable and start service:
```bash
sudo systemctl daemon-reload
sudo systemctl enable siap-backend
sudo systemctl start siap-backend
sudo systemctl status siap-backend
```

### Frontend Deployment

#### 1. Build Frontend

```bash
cd /opt/siap/frontend

# Install dependencies
npm ci --production

# Build for production
npm run build

# Copy build to nginx directory
sudo cp -r dist/* /var/www/siap/
```

#### 2. Nginx Configuration

Create `/etc/nginx/sites-available/siap`:

```nginx
server {
    listen 80;
    server_name your-domain.com;

    # Security headers
    add_header X-Frame-Options DENY;
    add_header X-Content-Type-Options nosniff;
    add_header X-XSS-Protection "1; mode=block";

    # Frontend
    location / {
        root /var/www/siap;
        index index.html;
        try_files $uri $uri/ /index.html;
    }

    # Backend API
    location /api {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        
        # Timeout settings
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;
    }

    # Uploads
    location /uploads {
        alias /opt/siap/uploads;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }

    # Health check
    location /health {
        access_log off;
        return 200 "healthy\n";
        add_header Content-Type text/plain;
    }
}
```

Enable site:
```bash
sudo ln -s /etc/nginx/sites-available/siap /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

---

## 🔒 SSL/TLS Setup

### Using Let's Encrypt (Certbot)

```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx -y

# Obtain certificate
sudo certbot --nginx -d your-domain.com -d www.your-domain.com

# Auto-renewal
sudo crontab -e
# Add: 0 12 * * * /usr/bin/certbot renew --quiet
```

### Manual SSL Configuration

```bash
# Generate private key
sudo openssl genrsa -out /etc/ssl/private/siap.key 4096

# Generate CSR
sudo openssl req -new -key /etc/ssl/private/siap.key -out /etc/ssl/certs/siap.csr

# Generate self-signed certificate (for testing)
sudo openssl x509 -req -days 365 -in /etc/ssl/certs/siap.csr -signkey /etc/ssl/private/siap.key -out /etc/ssl/certs/siap.crt
```

Update Nginx configuration untuk HTTPS:

```nginx
server {
    listen 443 ssl http2;
    server_name your-domain.com;

    ssl_certificate /etc/ssl/certs/siap.crt;
    ssl_certificate_key /etc/ssl/private/siap.key;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;

    # ... rest of configuration
}

server {
    listen 80;
    server_name your-domain.com;
    return 301 https://$server_name$request_uri;
}
```

---

## 📊 Monitoring & Maintenance

### Health Monitoring

```bash
# Check backend health
curl http://localhost:8000/health

# Check database connectivity
curl http://localhost:8000/health/db

# Check Redis connectivity
curl http://localhost:8000/health/redis
```

### Log Management

```bash
# Backend logs
sudo journalctl -u siap-backend -f

# Nginx logs
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log

# Database logs
sudo tail -f /var/log/postgresql/postgresql-*.log
```

### Database Backup

```bash
#!/bin/bash
# backup.sh

BACKUP_DIR="/opt/siap/backups"
DATE=$(date +%Y%m%d_%H%M%S)
DB_NAME="siap"
DB_USER="siap_user"

# Create backup
docker exec siap-db pg_dump -U $DB_USER $DB_NAME > "$BACKUP_DIR/siap_backup_$DATE.sql"

# Keep only last 7 days of backups
find $BACKUP_DIR -name "*.sql" -type f -mtime +7 -delete

# Make script executable
chmod +x /opt/siap/backup.sh

# Add to crontab (daily at 2 AM)
0 2 * * * /opt/siap/backup.sh
```

### Performance Tuning

#### PostgreSQL Tuning

Edit `/etc/postgresql/15/main/postgresql.conf`:

```conf
# Memory settings
shared_buffers = 256MB
effective_cache_size = 1GB
work_mem = 4MB

# Connection settings
max_connections = 100
listen_addresses = 'localhost'

# Logging
log_statement = 'all'
log_min_duration_statement = 1000
```

#### Redis Tuning

Edit `/etc/redis/redis.conf`:

```conf
# Memory
maxmemory 256mb
maxmemory-policy allkeys-lru

# Persistence
save 900 1
save 300 10
save 60 10000

# Performance
hash-max-ziplist-entries 512
hash-max-ziplist-value 64
```

---

## 🐛 Troubleshooting

### Common Issues

#### 1. Database Connection Failed

```bash
# Check PostgreSQL status
sudo systemctl status postgresql

# Check connection
docker exec siap-backend python -c "from app.utils.database import engine; print('Connected' if engine else 'Failed')"

# Check logs
docker-compose logs db
```

#### 2. Redis Connection Failed

```bash
# Check Redis status
sudo systemctl status redis

# Test connection
redis-cli ping
```

#### 3. Frontend Build Failed

```bash
# Clear node modules and reinstall
cd frontend
rm -rf node_modules package-lock.json
npm install
npm run build
```

#### 4. Permission Denied

```bash
# Fix ownership
sudo chown -R siap:siap /opt/siap
sudo chmod -R 755 /opt/siap
```

#### 5. SSL Certificate Issues

```bash
# Renew certificate
sudo certbot renew --dry-run

# Force renewal
sudo certbot renew --force-renewal
```

### Debug Mode

Untuk mengaktifkan debug mode:

```bash
# Backend
export DEBUG=True
export LOG_LEVEL=DEBUG

# Frontend
export VITE_DEBUG=True
```

---

## 🔄 Update & Migration

### Application Update

```bash
# Pull latest changes
git pull origin main

# Update backend
docker-compose build backend
docker-compose up -d backend

# Update frontend
docker-compose build frontend
docker-compose up -d frontend
```

### Database Migration

```bash
# Run migrations
docker-compose exec backend alembic upgrade head

# Or manually
alembic upgrade head
```

---

## 📞 Dukungan Deployment

Untuk bantuan deployment:

1. **Dokumentasi**: Lihat `/docs` directory
2. **Issues**: Buat issue di repository GitHub
3. **Email**: support@siap.com
4. **WhatsApp**: +62xxx-xxxx-xxxx

---

## 🎉 Selamat!

SIAP Anda sekarang sudah berjalan di production environment. Pastikan untuk:

1. ✅ Monitor logs secara berkala
2. ✅ Setup backup otomatis
3. ✅ Update security patches
4. ✅ Monitor performance metrics
5. ✅ Test disaster recovery procedures

---

**Happy deploying! 🚀**
