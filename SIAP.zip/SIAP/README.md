# SIAP - Sistem Induk Administrasi Pesantren

[![Python 3.12](https://img.shields.io/badge/Python-3.12-blue.svg)](https://www.python.org/downloads/release/python-3120/)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.109.0-green.svg)](https://fastapi.tiangolo.com/)
[![React](https://img.shields.io/badge/React-18.2.0-blue.svg)](https://react.dev/)
[![PostgreSQL](https://img.shields.io/badge/PostgreSQL-15-blue.svg)](https://www.postgresql.org/)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

---

## 📋 Tentang SIAP

**SIAP** (Sistem Induk Administrasi Pesantren) adalah platform manajemen Pondok Pesantren modern yang dirancang untuk memodernisasi administrasi akademik, keuangan, dan institusional. Sistem ini dibangun dengan arsitektur yang scalable, aman, dan user-friendly.

### ✨ Fitur Utama

- **Manajemen Akademik**: Kelas, mata pelajaran, jadwal, absensi, dan penilaian
- **Manajemen Keuangan**: Pembayaran SPP, asrama, dan biaya lainnya
- **Sistem Rapor**: Pembuatan rapor otomatis dengan format profesional
- **Manajemen Alumni**: Tracking alumni pasca kelulusan
- **Direktori Staf**: Manajemen staf non-pengajar
- **Autentikasi & Otorisasi**: Role-based access control (Super Admin, Admin, Ustadz, Santri)
- **Audit Trail**: Pencatatan semua aktivitas sistem
- **Export Reports**: Export ke PDF dan Excel

---

## 🏗️ Arsitektur Teknologi

### Backend
- **Framework**: FastAPI (Python 3.12) dengan async support
- **Database**: PostgreSQL 15 dengan SQLAlchemy 2.0 ORM
- **Authentication**: JWT + OAuth2 dengan refresh tokens
- **Caching**: Redis untuk session dan caching
- **File Storage**: Local/MinIO untuk upload file
- **Background Jobs**: Celery + Redis

### Frontend
- **Framework**: React 18 + TypeScript
- **Styling**: Tailwind CSS + shadcn/ui
- **State Management**: Zustand + React Query
- **Routing**: React Router v6
- **Forms**: React Hook Form + Zod validation
- **Charts**: Recharts untuk visualisasi data

### Infrastructure
- **Containerization**: Docker + Docker Compose
- **Reverse Proxy**: Nginx
- **Monitoring**: Prometheus + Grafana (optional)

---

## 🚀 Cepat Mulai

### Prasyarat

- Docker & Docker Compose
- Python 3.12 (untuk development tanpa Docker)
- Node.js 20+ (untuk frontend development)
- PostgreSQL 15+ (jika tidak menggunakan Docker)
- Redis 7+ (jika tidak menggunakan Docker)

### Instalasi dengan Docker (Recommended)

1. **Clone repository**
   ```bash
   git clone <repository-url>
   cd siap
   ```

2. **Copy environment file**
   ```bash
   cp .env.example .env
   ```

3. **Edit environment file**
   ```bash
   # Edit .env file dengan konfigurasi yang sesuai
   nano .env
   ```

4. **Jalankan dengan Docker Compose**
   ```bash
   docker-compose up -d
   ```

5. **Akses aplikasi**
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:8000
   - API Documentation: http://localhost:8000/docs

### Instalasi Manual (Development)

#### Backend Setup

1. **Install dependencies**
   ```bash
   cd backend
   python -m venv venv
   source venv/bin/activate  # Windows: venv\Scripts\activate
   pip install -r requirements/dev.txt
   ```

2. **Setup database**
   ```bash
   # Create database
   createdb siap
   
   # Run migrations
   alembic upgrade head
   ```

3. **Jalankan backend**
   ```bash
   uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
   ```

#### Frontend Setup

1. **Install dependencies**
   ```bash
   cd frontend
   npm install
   ```

2. **Jalankan frontend**
   ```bash
   npm run dev
   ```

---

## 📚 Dokumentasi API

Dokumentasi API otomatis tersedia melalui:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc
- **OpenAPI Schema**: http://localhost:8000/openapi.json

### Authentication

API menggunakan JWT Bearer token untuk autentikasi:

```bash
# Login
curl -X POST "http://localhost:8000/api/v1/auth/login" \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@example.com",
    "password": "password"
  }'

# Use token in subsequent requests
curl -X GET "http://localhost:8000/api/v1/auth/me" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

## 👥 Role & Permissions

### Super Admin
- Kontrol penuh sistem
- Manajemen multi-pesantren
- Konfigurasi sistem

### Admin Pesantren
- Manajemen akademik
- Manajemen keuangan
- Manajemen staf & alumni
- Generate laporan

### Ustadz/Guru
- Input absensi
- Input nilai
- Lihat jadwal mengajar
- Lihat progress santri

### Santri
- Lihat profil
- Lihat nilai
- Lihat absensi
- Lihat history pembayaran

---

## 📁 Struktur Proyek

```
siap/
├── backend/                 # FastAPI backend
│   ├── app/
│   │   ├── api/v1/         # API endpoints
│   │   ├── core/           # Core business logic
│   │   ├── models/         # Database models
│   │   ├── schemas/        # Pydantic schemas
│   │   ├── services/       # Business services
│   │   ├── utils/          # Utilities
│   │   └── middleware/     # Custom middleware
│   ├── migrations/         # Database migrations
│   ├── tests/              # Test files
│   ├── requirements/       # Python dependencies
│   ├── Dockerfile
│   └── .env.example
│
├── frontend/               # React frontend
│   ├── src/
│   │   ├── components/     # Reusable components
│   │   ├── pages/          # Page components
│   │   ├── hooks/          # Custom hooks
│   │   ├── services/       # API services
│   │   ├── store/          # State management
│   │   ├── types/          # TypeScript types
│   │   └── utils/          # Utilities
│   ├── public/             # Static assets
│   ├── Dockerfile
│   └── package.json
│
├── database/               # Database files
│   └── schema.sql          # Database schema
│
├── nginx/                  # Nginx configuration
│   └── nginx.conf
│
├── docker-compose.yml      # Docker compose configuration
├── .env.example            # Environment variables example
└── README.md               # This file
```

---

## 🔐 Keamanan

### Authentication
- JWT dengan access & refresh tokens
- Password hashing dengan bcrypt
- Token expiry dan rotation

### Authorization
- Role-Based Access Control (RBAC)
- Fine-grained permissions
- Resource-level security

### Data Protection
- SQL injection prevention via ORM
- XSS protection
- CSRF protection
- Input validation dengan Pydantic

### Audit & Monitoring
- Audit trail untuk semua action kritis
- Structured logging
- Health checks

---

## 🧪 Testing

### Backend Testing
```bash
cd backend
pytest tests/ -v --cov=app
```

### Frontend Testing
```bash
cd frontend
npm test
```

---

## 🚀 Deployment

### Production Deployment

1. **Environment Setup**
   ```bash
   # Copy and configure environment
   cp .env.example .env.production
   
   # Generate strong secret key
   openssl rand -hex 32
   ```

2. **Build & Deploy**
   ```bash
   # Production deployment with Docker
   docker-compose --profile production up -d
   ```

3. **SSL/TLS Setup**
   - Use Let's Encrypt untuk SSL certificates
   - Configure Nginx untuk HTTPS

### Monitoring

- **Health Check**: `/health`
- **Database Health**: `/health/db`
- **Redis Health**: `/health/redis`
- **Metrics**: `/metrics` (jika menggunakan Prometheus)

---

## 🔧 Konfigurasi

### Environment Variables

```env
# Application
APP_NAME="SIAP - Sistem Induk Administrasi Pesantren"
APP_VERSION=1.0.0
ENVIRONMENT=production
DEBUG=False

# Database
DATABASE_URL=postgresql+asyncpg://user:password@localhost:5432/siap

# Redis
REDIS_URL=redis://localhost:6379/0

# Security
SECRET_KEY=your-super-secret-key-here
ACCESS_TOKEN_EXPIRE_MINUTES=60
REFRESH_TOKEN_EXPIRE_DAYS=7

# File Upload
UPLOAD_DIR=./uploads
MAX_UPLOAD_SIZE=10485760

# Email (optional)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
FROM_EMAIL=noreply@siap.com
```

---

## 📊 Database

### Schema
Database schema tersedia di `database/schema.sql`

### Migrations
```bash
# Create migration
alembic revision --autogenerate -m "Description"

# Apply migrations
alembic upgrade head

# Downgrade migration
alembic downgrade -1
```

---

## 🤝 Kontribusi

1. Fork repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit perubahan (`git commit -m 'Add some AmazingFeature'`)
4. Push ke branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

### Code Standards

- Python: Mengikuti PEP 8 dengan Black formatter
- TypeScript: Mengikuti konvensi React/TypeScript
- Commit messages: Mengikuti conventional commits

---

## 📄 License

Proyek ini dilisensikan di bawah MIT License - lihat file [LICENSE](LICENSE) untuk detail.

---

## 👨‍💻 Tim Pengembang

**SIAP Development Team**

- Lead Developer: [Your Name]
- Frontend Developer: [Name]
- Backend Developer: [Name]
- UI/UX Designer: [Name]

---

## 📞 Dukungan

Untuk pertanyaan atau bantuan:

- Email: support@siap.com
- WhatsApp: +62xxx-xxxx-xxxx
- Dokumentasi: [docs.siap.com](https://docs.siap.com)

---

## 🙏 Acknowledgments

- FastAPI team untuk framework yang luar biasa
- shadcn/ui untuk komponen UI yang elegan
- PostgreSQL untuk database yang powerful
- Semua kontributor open source yang terlibat

---

**Selamat menggunakan SIAP! 🎉**

*Sistem ini dibuat dengan ❤️ untuk memajukan pendidikan Islam di Indonesia.*
