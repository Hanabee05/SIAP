"""
Academic endpoints.
"""

from datetime import date
from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_, func
from sqlalchemy.orm import joinedload

from app.utils.database import get_db
from app.core.security import get_current_active_user, has_permission
from app.core.security import Permissions
from app.models.user import User
from app.models.academic import Class, Subject, TeachingAssignment, Attendance, Grade
from app.models.santri import Santri
from app.schemas.response import BaseResponse, PaginatedResponse


router = APIRouter()


# Dependency to check academic permissions
async def require_academic_permission(
    current_user: User = Depends(get_current_active_user),
    permission: str = Permissions.ADMIN_MANAGE_CLASSES,
):
    """Check if user has academic permission."""
    if not has_permission(current_user.role, permission):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions",
        )
    return current_user


# === CLASS ENDPOINTS ===

@router.get("/classes")
async def list_classes(
    academic_year_id: Optional[UUID] = Query(None, description="Filter by academic year"),
    is_active: Optional[bool] = Query(None, description="Filter by active status"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=100, description="Number of records to return"),
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """List classes with pagination and filters."""
    query = select(Class).where(Class.deleted_at.is_(None))
    
    # Filter by pesantren
    query = query.where(Class.pesantren_id == current_user.pesantren_id)
    
    # Apply filters
    if academic_year_id:
        query = query.where(Class.academic_year_id == academic_year_id)
    if is_active is not None:
        query = query.where(Class.is_active == is_active)
    
    # Count total
    count_query = select(func.count()).select_from(query.subquery())
    total_result = await session.execute(count_query)
    total = total_result.scalar()
    
    # Apply pagination
    query = query.offset(skip).limit(limit).options(
        joinedload(Class.class_teacher),
        joinedload(Class.academic_year),
    )
    
    result = await session.execute(query)
    classes = result.unique().scalars().all()
    
    # Convert to response format
    data = []
    for cls in classes:
        data.append({
            "id": str(cls.id),
            "name": cls.name,
            "level": cls.level,
            "academic_year": cls.academic_year.name if cls.academic_year else None,
            "class_teacher": cls.class_teacher.full_name if cls.class_teacher else None,
            "capacity": cls.capacity,
            "student_count": cls.student_count,
            "is_active": cls.is_active,
            "created_at": cls.created_at.isoformat(),
        })
    
    return PaginatedResponse(
        success=True,
        message="Classes retrieved successfully",
        data=data,
        meta={
            "page": skip // limit + 1,
            "per_page": limit,
            "total": total,
            "total_pages": (total + limit - 1) // limit,
            "has_next": skip + limit < total,
            "has_prev": skip > 0,
        },
    )


@router.get("/classes/{class_id}")
async def get_class(
    class_id: UUID,
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """Get class by ID."""
    result = await session.execute(
        select(Class)
        .where(
            Class.id == class_id,
            Class.deleted_at.is_(None),
            Class.pesantren_id == current_user.pesantren_id,
        )
        .options(
            joinedload(Class.class_teacher),
            joinedload(Class.academic_year),
        )
    )
    
    cls = result.unique().scalar_one_or_none()
    if not cls:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Class not found",
        )
    
    return BaseResponse(
        success=True,
        message="Class retrieved successfully",
        data={
            "id": str(cls.id),
            "name": cls.name,
            "level": cls.level,
            "academic_year": {
                "id": str(cls.academic_year.id),
                "name": cls.academic_year.name,
            } if cls.academic_year else None,
            "class_teacher": {
                "id": str(cls.class_teacher.id),
                "full_name": cls.class_teacher.full_name,
                "nip": cls.class_teacher.nip,
            } if cls.class_teacher else None,
            "capacity": cls.capacity,
            "student_count": cls.student_count,
            "description": cls.description,
            "room_number": cls.room_number,
            "is_active": cls.is_active,
            "created_at": cls.created_at.isoformat(),
        },
    )


# === SUBJECT ENDPOINTS ===

@router.get("/subjects")
async def list_subjects(
    category: Optional[str] = Query(None, description="Filter by category"),
    is_active: Optional[bool] = Query(None, description="Filter by active status"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=100, description="Number of records to return"),
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """List subjects with pagination and filters."""
    query = select(Subject).where(Subject.deleted_at.is_(None))
    
    # Filter by pesantren
    query = query.where(Subject.pesantren_id == current_user.pesantren_id)
    
    # Apply filters
    if category:
        query = query.where(Subject.category == category)
    if is_active is not None:
        query = query.where(Subject.is_active == is_active)
    
    # Count total
    count_query = select(func.count()).select_from(query.subquery())
    total_result = await session.execute(count_query)
    total = total_result.scalar()
    
    # Apply pagination
    query = query.offset(skip).limit(limit)
    
    result = await session.execute(query)
    subjects = result.scalars().all()
    
    # Convert to response format
    data = []
    for subject in subjects:
        data.append({
            "id": str(subject.id),
            "code": subject.code,
            "name": subject.name,
            "category": subject.category,
            "credit_hours": subject.credit_hours,
            "description": subject.description,
            "is_active": subject.is_active,
            "created_at": subject.created_at.isoformat(),
        })
    
    return PaginatedResponse(
        success=True,
        message="Subjects retrieved successfully",
        data=data,
        meta={
            "page": skip // limit + 1,
            "per_page": limit,
            "total": total,
            "total_pages": (total + limit - 1) // limit,
            "has_next": skip + limit < total,
            "has_prev": skip > 0,
        },
    )


# === ATTENDANCE ENDPOINTS ===

@router.get("/attendance")
async def list_attendance(
    class_id: Optional[UUID] = Query(None, description="Filter by class"),
    subject_id: Optional[UUID] = Query(None, description="Filter by subject"),
    date_from: Optional[date] = Query(None, description="Filter from date"),
    date_to: Optional[date] = Query(None, description="Filter to date"),
    status: Optional[str] = Query(None, description="Filter by status"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=100, description="Number of records to return"),
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """List attendance records with pagination and filters."""
    query = select(Attendance).where(Attendance.deleted_at.is_(None))
    
    # Apply filters
    if class_id:
        query = query.join(TeachingAssignment).where(TeachingAssignment.class_id == class_id)
    if subject_id:
        query = query.join(TeachingAssignment).where(TeachingAssignment.subject_id == subject_id)
    if date_from:
        query = query.where(Attendance.date >= date_from)
    if date_to:
        query = query.where(Attendance.date <= date_to)
    if status:
        query = query.where(Attendance.status == status)
    
    # Filter by pesantren through santri
    query = query.join(Santri).where(Santri.pesantren_id == current_user.pesantren_id)
    
    # Count total
    count_query = select(func.count()).select_from(query.subquery())
    total_result = await session.execute(count_query)
    total = total_result.scalar()
    
    # Apply pagination with joins
    query = query.options(
        joinedload(Attendance.santri),
        joinedload(Attendance.teaching_assignment).joinedload(TeachingAssignment.subject),
        joinedload(Attendance.teaching_assignment).joinedload(TeachingAssignment.class_),
    ).offset(skip).limit(limit)
    
    result = await session.execute(query)
    attendance = result.unique().scalars().all()
    
    # Convert to response format
    data = []
    for att in attendance:
        data.append({
            "id": str(att.id),
            "santri": {
                "id": str(att.santri.id),
                "nis": att.santri.nis,
                "full_name": att.santri.full_name,
            },
            "subject": att.teaching_assignment.subject.name if att.teaching_assignment.subject else None,
            "class": att.teaching_assignment.class_.name if att.teaching_assignment.class_ else None,
            "date": att.date.isoformat(),
            "status": att.status,
            "notes": att.notes,
            "created_at": att.created_at.isoformat(),
        })
    
    return PaginatedResponse(
        success=True,
        message="Attendance retrieved successfully",
        data=data,
        meta={
            "page": skip // limit + 1,
            "per_page": limit,
            "total": total,
            "total_pages": (total + limit - 1) // limit,
            "has_next": skip + limit < total,
            "has_prev": skip > 0,
        },
    )


# === GRADE ENDPOINTS ===

@router.get("/grades")
async def list_grades(
    santri_id: Optional[UUID] = Query(None, description="Filter by santri"),
    class_id: Optional[UUID] = Query(None, description="Filter by class"),
    subject_id: Optional[UUID] = Query(None, description="Filter by subject"),
    grade_type: Optional[str] = Query(None, description="Filter by grade type"),
    date_from: Optional[date] = Query(None, description="Filter from date"),
    date_to: Optional[date] = Query(None, description="Filter to date"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=100, description="Number of records to return"),
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """List grades with pagination and filters."""
    query = select(Grade).where(Grade.deleted_at.is_(None))
    
    # Apply filters
    if santri_id:
        query = query.where(Grade.santri_id == santri_id)
    if class_id:
        query = query.join(TeachingAssignment).where(TeachingAssignment.class_id == class_id)
    if subject_id:
        query = query.join(TeachingAssignment).where(TeachingAssignment.subject_id == subject_id)
    if grade_type:
        query = query.where(Grade.grade_type == grade_type)
    if date_from:
        query = query.where(Grade.date >= date_from)
    if date_to:
        query = query.where(Grade.date <= date_to)
    
    # Filter by pesantren through santri
    query = query.join(Santri).where(Santri.pesantren_id == current_user.pesantren_id)
    
    # Count total
    count_query = select(func.count()).select_from(query.subquery())
    total_result = await session.execute(count_query)
    total = total_result.scalar()
    
    # Apply pagination with joins
    query = query.options(
        joinedload(Grade.santri),
        joinedload(Grade.teaching_assignment).joinedload(TeachingAssignment.subject),
        joinedload(Grade.teaching_assignment).joinedload(TeachingAssignment.class_),
    ).offset(skip).limit(limit)
    
    result = await session.execute(query)
    grades = result.unique().scalars().all()
    
    # Convert to response format
    data = []
    for grade in grades:
        data.append({
            "id": str(grade.id),
            "santri": {
                "id": str(grade.santri.id),
                "nis": grade.santri.nis,
                "full_name": grade.santri.full_name,
            },
            "subject": grade.teaching_assignment.subject.name if grade.teaching_assignment.subject else None,
            "class": grade.teaching_assignment.class_.name if grade.teaching_assignment.class_ else None,
            "grade_type": grade.grade_type,
            "score": grade.score,
            "max_score": grade.max_score,
            "percentage": grade.percentage,
            "date": grade.date.isoformat(),
            "description": grade.description,
            "notes": grade.notes,
            "created_at": grade.created_at.isoformat(),
        })
    
    return PaginatedResponse(
        success=True,
        message="Grades retrieved successfully",
        data=data,
        meta={
            "page": skip // limit + 1,
            "per_page": limit,
            "total": total,
            "total_pages": (total + limit - 1) // limit,
            "has_next": skip + limit < total,
            "has_prev": skip > 0,
        },
    )


# === TEACHING ASSIGNMENT ENDPOINTS ===

@router.get("/teaching-assignments")
async def list_teaching_assignments(
    ustadz_id: Optional[UUID] = Query(None, description="Filter by ustadz"),
    class_id: Optional[UUID] = Query(None, description="Filter by class"),
    subject_id: Optional[UUID] = Query(None, description="Filter by subject"),
    academic_year_id: Optional[UUID] = Query(None, description="Filter by academic year"),
    is_active: Optional[bool] = Query(None, description="Filter by active status"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=100, description="Number of records to return"),
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """List teaching assignments with pagination and filters."""
    query = select(TeachingAssignment).where(TeachingAssignment.deleted_at.is_(None))
    
    # Filter by pesantren through class
    query = query.join(Class).where(Class.pesantren_id == current_user.pesantren_id)
    
    # Apply filters
    if ustadz_id:
        query = query.where(TeachingAssignment.ustadz_id == ustadz_id)
    if class_id:
        query = query.where(TeachingAssignment.class_id == class_id)
    if subject_id:
        query = query.where(TeachingAssignment.subject_id == subject_id)
    if academic_year_id:
        query = query.where(TeachingAssignment.academic_year_id == academic_year_id)
    if is_active is not None:
        query = query.where(TeachingAssignment.is_active == is_active)
    
    # Count total
    count_query = select(func.count()).select_from(query.subquery())
    total_result = await session.execute(count_query)
    total = total_result.scalar()
    
    # Apply pagination with joins
    query = query.options(
        joinedload(TeachingAssignment.ustadz),
        joinedload(TeachingAssignment.class_),
        joinedload(TeachingAssignment.subject),
        joinedload(TeachingAssignment.academic_year),
    ).offset(skip).limit(limit)
    
    result = await session.execute(query)
    assignments = result.unique().scalars().all()
    
    # Convert to response format
    data = []
    for ta in assignments:
        data.append({
            "id": str(ta.id),
            "ustadz": {
                "id": str(ta.ustadz.id),
                "full_name": ta.ustadz.full_name,
                "nip": ta.ustadz.nip,
            } if ta.ustadz else None,
            "class": {
                "id": str(ta.class_.id),
                "name": ta.class_.name,
                "level": ta.class_.level,
            } if ta.class_ else None,
            "subject": {
                "id": str(ta.subject.id),
                "name": ta.subject.name,
                "category": ta.subject.category,
            } if ta.subject else None,
            "academic_year": {
                "id": str(ta.academic_year.id),
                "name": ta.academic_year.name,
            } if ta.academic_year else None,
            "schedule": {
                "day": ta.schedule_day,
                "time_start": ta.schedule_time_start.strftime("%H:%M") if ta.schedule_time_start else None,
                "time_end": ta.schedule_time_end.strftime("%H:%M") if ta.schedule_time_end else None,
                "room": ta.room,
            },
            "is_active": ta.is_active,
            "created_at": ta.created_at.isoformat(),
        })
    
    return PaginatedResponse(
        success=True,
        message="Teaching assignments retrieved successfully",
        data=data,
        meta={
            "page": skip // limit + 1,
            "per_page": limit,
            "total": total,
            "total_pages": (total + limit - 1) // limit,
            "has_next": skip + limit < total,
            "has_prev": skip > 0,
        },
    )
