"""
Alumni endpoints.
"""

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from sqlalchemy.orm import joinedload

from app.utils.database import get_db
from app.core.security import get_current_active_user, has_permission
from app.core.security import Permissions
from app.models.user import User
from app.models.alumni import Alumni
from app.models.santri import Santri
from app.schemas.response import BaseResponse, PaginatedResponse


router = APIRouter()


@router.get("/")
async def list_alumni(
    graduation_year: Optional[int] = Query(None, description="Filter by graduation year"),
    current_status: Optional[str] = Query(None, description="Filter by current status"),
    search: Optional[str] = Query(None, description="Search by name or NIS"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=100, description="Number of records to return"),
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """List alumni with pagination and filters."""
    query = select(Alumni).where(Alumni.deleted_at.is_(None))
    
    # Filter by pesantren through santri
    query = query.join(Santri).where(Santri.pesantren_id == current_user.pesantren_id)
    
    # Apply filters
    if graduation_year:
        query = query.where(Alumni.graduation_year == graduation_year)
    if current_status:
        query = query.where(Alumni.current_status == current_status)
    if search:
        query = query.join(Santri).where(
            or_(
                Santri.full_name.ilike(f"%{search}%"),
                Santri.nis.ilike(f"%{search}%"),
            )
        )
    
    # Count total
    count_query = select(func.count()).select_from(query.subquery())
    total_result = await session.execute(count_query)
    total = total_result.scalar()
    
    # Apply pagination with joins
    query = query.options(
        joinedload(Alumni.santri),
    ).order_by(Alumni.graduation_year.desc()).offset(skip).limit(limit)
    
    result = await session.execute(query)
    alumni_list = result.unique().scalars().all()
    
    # Convert to response format
    data = []
    for alumnus in alumni_list:
        data.append({
            "id": str(alumnus.id),
            "santri": {
                "id": str(alumnus.santri.id),
                "nis": alumnus.santri.nis,
                "full_name": alumnus.santri.full_name,
                "last_class": alumnus.last_class,
            },
            "graduation_year": alumnus.graduation_year,
            "current_status": alumnus.current_status,
            "institution_name": alumnus.institution_name,
            "major": alumnus.major,
            "degree": alumnus.degree,
            "job_title": alumnus.job_title,
            "company_name": alumnus.company_name,
            "business_name": alumnus.business_name,
            "business_type": alumnus.business_type,
            "contact": {
                "phone": alumnus.phone,
                "email": alumnus.email,
                "address": alumnus.address,
            },
            "achievements": alumnus.achievements,
            "created_at": alumnus.created_at.isoformat(),
        })
    
    return PaginatedResponse(
        success=True,
        message="Alumni retrieved successfully",
        data=data,
        meta={
            "page": skip // limit + 1,
            "per_page": limit,
            "total": total,
            "total_pages": (total + limit - 1) // limit,
            "has_next": skip + limit < total,
            "has_prev": skip > 0,
        },
    )


@router.get("/{alumni_id}")
async def get_alumni(
    alumni_id: UUID,
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """Get alumni by ID."""
    result = await session.execute(
        select(Alumni)
        .where(Alumni.id == alumni_id, Alumni.deleted_at.is_(None))
        .options(
            joinedload(Alumni.santri),
        )
    )
    
    alumnus = result.unique().scalar_one_or_none()
    if not alumnus:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Alumni not found",
        )
    
    # Verify pesantren access
    if alumnus.santri.pesantren_id != current_user.pesantren_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied",
        )
    
    return BaseResponse(
        success=True,
        message="Alumni retrieved successfully",
        data={
            "id": str(alumnus.id),
            "santri": {
                "id": str(alumnus.santri.id),
                "nis": alumnus.santri.nis,
                "full_name": alumnus.santri.full_name,
                "birth_date": alumnus.santri.birth_date.isoformat() if alumnus.santri.birth_date else None,
                "birth_place": alumnus.santri.birth_place,
                "last_class": alumnus.last_class,
            },
            "graduation_year": alumnus.graduation_year,
            "current_status": alumnus.current_status,
            "institution_name": alumnus.institution_name,
            "major": alumnus.major,
            "degree": alumnus.degree,
            "job_title": alumnus.job_title,
            "company_name": alumnus.company_name,
            "company_address": alumnus.company_address,
            "business_name": alumnus.business_name,
            "business_type": alumnus.business_type,
            "contact": {
                "phone": alumnus.phone,
                "email": alumnus.email,
                "address": alumnus.address,
            },
            "achievements": alumnus.achievements,
            "created_at": alumnus.created_at.isoformat(),
            "updated_at": alumnus.updated_at.isoformat(),
        },
    )


@router.get("/stats/summary")
async def get_alumni_stats(
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """Get alumni statistics."""
    query = select(Alumni).where(Alumni.deleted_at.is_(None))
    
    # Filter by pesantren through santri
    query = query.join(Santri).where(Santri.pesantren_id == current_user.pesantren_id)
    
    result = await session.execute(query)
    alumni_list = result.scalars().all()
    
    # Calculate statistics
    total_alumni = len(alumni_list)
    
    # By graduation year
    by_year = {}
    for alumnus in alumni_list:
        year = alumnus.graduation_year
        by_year[year] = by_year.get(year, 0) + 1
    
    # By current status
    by_status = {}
    for alumnus in alumni_list:
        status = alumnus.current_status
        by_status[status] = by_status.get(status, 0) + 1
    
    # Recent alumni (last 5 years)
    from datetime import datetime
    current_year = datetime.now().year
    recent_alumni = [a for a in alumni_list if a.graduation_year >= current_year - 5]
    
    return BaseResponse(
        success=True,
        message="Alumni statistics retrieved successfully",
        data={
            "total_alumni": total_alumni,
            "by_graduation_year": by_year,
            "by_current_status": by_status,
            "recent_alumni_count": len(recent_alumni),
            "top_graduation_years": sorted(by_year.items(), key=lambda x: x[1], reverse=True)[:5],
        },
    )
