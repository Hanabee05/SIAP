"""
Authentication endpoints.
"""

from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.config import settings
from app.utils.database import get_db
from app.core.security import (
    authenticate_user,
    create_access_token,
    create_refresh_token,
    verify_refresh_token,
    get_user_by_id,
    hash_password,
    verify_password,
)
from app.models.user import User
from app.schemas.auth import (
    LoginRequest,
    LoginResponse,
    TokenResponse,
    RefreshTokenRequest,
    ChangePasswordRequest,
)
from app.schemas.response import BaseResponse, ErrorResponse


router = APIRouter()

# OAuth2 scheme for token authentication
oauth2_scheme = OAuth2PasswordBearer(tokenUrl=f"{settings.API_V1_STR}/auth/login")


async def get_current_user(
    token: str = Depends(oauth2_scheme),
    session: AsyncSession = Depends(get_db),
) -> User:
    """
    Get current authenticated user from JWT token.
    
    Args:
        token: JWT token from authorization header
        session: Database session
    
    Returns:
        User object
    
    Raises:
        HTTPException: If token is invalid or user not found
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    
    from app.core.security import verify_token
    
    payload = verify_token(token)
    if payload is None:
        raise credentials_exception
    
    user_id: str = payload.get("sub")
    if user_id is None:
        raise credentials_exception
    
    user = await get_user_by_id(session, user_id)
    if user is None:
        raise credentials_exception
    
    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User account is inactive",
        )
    
    return user


async def get_current_active_user(
    current_user: User = Depends(get_current_user),
) -> User:
    """Get current active user."""
    if not current_user.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Inactive user",
        )
    return current_user


@router.post("/login", response_model=LoginResponse)
async def login(
    login_data: LoginRequest,
    session: AsyncSession = Depends(get_db),
):
    """
    Login endpoint.
    
    Args:
        login_data: Login credentials
        session: Database session
    
    Returns:
        Login response with tokens and user info
    """
    # Authenticate user
    user = await authenticate_user(
        session,
        login_data.email,
        login_data.password,
    )
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Update last login
    user.last_login = datetime.utcnow()
    await session.commit()
    
    # Create tokens
    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    refresh_token_expires = timedelta(days=settings.REFRESH_TOKEN_EXPIRE_DAYS)
    
    access_token = create_access_token(
        subject=user.id,
        expires_delta=access_token_expires,
        additional_claims={
            "role": user.role,
            "pesantren_id": str(user.pesantren_id),
        },
    )
    
    refresh_token = create_refresh_token(
        subject=user.id,
        expires_delta=refresh_token_expires,
    )
    
    # Prepare user data
    user_data = {
        "id": str(user.id),
        "email": user.email,
        "role": user.role,
        "pesantren_id": str(user.pesantren_id),
        "is_active": user.is_active,
        "is_verified": user.is_verified,
        "display_name": user.display_name,
        "permissions": user.permissions,
    }
    
    # Add profile info based on role
    if user.santri:
        user_data["profile"] = {
            "id": str(user.santri.id),
            "nis": user.santri.nis,
            "full_name": user.santri.full_name,
            "class_id": str(user.santri.current_class_id) if user.santri.current_class_id else None,
        }
    elif user.ustadz:
        user_data["profile"] = {
            "id": str(user.ustadz.id),
            "nip": user.ustadz.nip,
            "full_name": user.ustadz.full_name,
            "specialization": user.ustadz.specialization,
        }
    
    return LoginResponse(
        token=TokenResponse(
            access_token=access_token,
            refresh_token=refresh_token,
            token_type="bearer",
            expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        ),
        user=user_data,
    )


@router.post("/refresh", response_model=TokenResponse)
async def refresh_token(
    refresh_data: RefreshTokenRequest,
    session: AsyncSession = Depends(get_db),
):
    """
    Refresh access token using refresh token.
    
    Args:
        refresh_data: Refresh token data
        session: Database session
    
    Returns:
        New access token
    """
    user_id = verify_refresh_token(refresh_data.refresh_token)
    
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or expired refresh token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    user = await get_user_by_id(session, user_id)
    
    if not user or not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or inactive",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Create new access token
    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    
    access_token = create_access_token(
        subject=user.id,
        expires_delta=access_token_expires,
        additional_claims={
            "role": user.role,
            "pesantren_id": str(user.pesantren_id),
        },
    )
    
    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_data.refresh_token,  # Return same refresh token
        token_type="bearer",
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )


@router.post("/logout")
async def logout(
    current_user: User = Depends(get_current_active_user),
):
    """
    Logout endpoint.
    
    Args:
        current_user: Current authenticated user
    
    Returns:
        Success message
    """
    # In a production app, you might want to invalidate the token
    # by adding it to a blacklist in Redis
    
    return BaseResponse(
        success=True,
        message="Logged out successfully",
    )


@router.get("/me", response_model=BaseResponse)
async def get_current_user_info(
    current_user: User = Depends(get_current_active_user),
):
    """
    Get current user information.
    
    Args:
        current_user: Current authenticated user
    
    Returns:
        User information
    """
    user_data = {
        "id": str(current_user.id),
        "email": current_user.email,
        "role": current_user.role,
        "pesantren_id": str(current_user.pesantren_id),
        "is_active": current_user.is_active,
        "is_verified": current_user.is_verified,
        "display_name": current_user.display_name,
        "permissions": current_user.permissions,
        "last_login": current_user.last_login.isoformat() if current_user.last_login else None,
        "created_at": current_user.created_at.isoformat(),
    }
    
    # Add profile info based on role
    if current_user.santri:
        user_data["profile"] = {
            "id": str(current_user.santri.id),
            "nis": current_user.santri.nis,
            "full_name": current_user.santri.full_name,
            "class_id": str(current_user.santri.current_class_id) if current_user.santri.current_class_id else None,
            "status": current_user.santri.status,
        }
    elif current_user.ustadz:
        user_data["profile"] = {
            "id": str(current_user.ustadz.id),
            "nip": current_user.ustadz.nip,
            "full_name": current_user.ustadz.full_name,
            "specialization": current_user.ustadz.specialization,
            "is_active": current_user.ustadz.is_active,
        }
    
    return BaseResponse(
        success=True,
        message="User information retrieved",
        data=user_data,
    )


@router.post("/change-password")
async def change_password(
    password_data: ChangePasswordRequest,
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """
    Change user password.
    
    Args:
        password_data: Password change data
        current_user: Current authenticated user
        session: Database session
    
    Returns:
        Success message
    """
    # Validate password confirmation
    if not password_data.validate_passwords_match():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="New password and confirmation do not match",
        )
    
    # Verify current password
    if not verify_password(password_data.current_password, current_user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Current password is incorrect",
        )
    
    # Update password
    current_user.password_hash = hash_password(password_data.new_password)
    await session.commit()
    
    return BaseResponse(
        success=True,
        message="Password changed successfully",
    )
