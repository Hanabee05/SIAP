"""
Finance endpoints.
"""

from datetime import date
from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_, UUID
from sqlalchemy.orm import joinedload

from app.utils.database import get_db
from app.core.security import get_current_active_user, has_permission
from app.core.security import Permissions
from app.models.user import User
from app.models.finance import PaymentType, Payment
from app.models.santri import Santri
from app.schemas.response import BaseResponse, PaginatedResponse


router = APIRouter()


# === PAYMENT TYPE ENDPOINTS ===

@router.get("/payment-types")
async def list_payment_types(
    type: Optional[str] = Query(None, description="Filter by type (spp, dormitory, development, other)"),
    is_active: Optional[bool] = Query(None, description="Filter by active status"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=100, description="Number of records to return"),
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """List payment types with pagination and filters."""
    query = select(PaymentType).where(PaymentType.deleted_at.is_(None))
    
    # Filter by pesantren
    query = query.where(PaymentType.pesantren_id == current_user.pesantren_id)
    
    # Apply filters
    if type:
        query = query.where(PaymentType.type == type)
    if is_active is not None:
        query = query.where(PaymentType.is_active == is_active)
    
    # Count total
    count_query = select(func.count()).select_from(query.subquery())
    total_result = await session.execute(count_query)
    total = total_result.scalar()
    
    # Apply pagination
    query = query.offset(skip).limit(limit)
    
    result = await session.execute(query)
    payment_types = result.scalars().all()
    
    # Convert to response format
    data = []
    for pt in payment_types:
        data.append({
            "id": str(pt.id),
            "name": pt.name,
            "type": pt.type,
            "amount": float(pt.amount),
            "frequency": pt.frequency,
            "description": pt.description,
            "is_active": pt.is_active,
            "created_at": pt.created_at.isoformat(),
        })
    
    return PaginatedResponse(
        success=True,
        message="Payment types retrieved successfully",
        data=data,
        meta={
            "page": skip // limit + 1,
            "per_page": limit,
            "total": total,
            "total_pages": (total + limit - 1) // limit,
            "has_next": skip + limit < total,
            "has_prev": skip > 0,
        },
    )


@router.get("/payment-types/{payment_type_id}")
async def get_payment_type(
    payment_type_id: UUID,
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """Get payment type by ID."""
    result = await session.execute(
        select(PaymentType)
        .where(
            PaymentType.id == payment_type_id,
            PaymentType.deleted_at.is_(None),
            PaymentType.pesantren_id == current_user.pesantren_id,
        )
    )
    
    payment_type = result.scalar_one_or_none()
    if not payment_type:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Payment type not found",
        )
    
    return BaseResponse(
        success=True,
        message="Payment type retrieved successfully",
        data={
            "id": str(payment_type.id),
            "name": payment_type.name,
            "type": payment_type.type,
            "amount": float(payment_type.amount),
            "frequency": payment_type.frequency,
            "description": payment_type.description,
            "is_active": payment_type.is_active,
            "created_at": payment_type.created_at.isoformat(),
        },
    )


# === PAYMENT ENDPOINTS ===

@router.get("/payments")
async def list_payments(
    santri_id: Optional[UUID] = Query(None, description="Filter by santri"),
    payment_type_id: Optional[UUID] = Query(None, description="Filter by payment type"),
    status: Optional[str] = Query(None, description="Filter by status"),
    date_from: Optional[date] = Query(None, description="Filter from date"),
    date_to: Optional[date] = Query(None, description="Filter to date"),
    period_year: Optional[int] = Query(None, description="Filter by year"),
    period_month: Optional[int] = Query(None, description="Filter by month"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=100, description="Number of records to return"),
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """List payments with pagination and filters."""
    query = select(Payment).where(Payment.deleted_at.is_(None))
    
    # Filter by pesantren through santri
    query = query.join(Santri).where(Santri.pesantren_id == current_user.pesantren_id)
    
    # Apply filters
    if santri_id:
        query = query.where(Payment.santri_id == santri_id)
    if payment_type_id:
        query = query.where(Payment.payment_type_id == payment_type_id)
    if status:
        query = query.where(Payment.status == status)
    if date_from:
        query = query.where(Payment.payment_date >= date_from)
    if date_to:
        query = query.where(Payment.payment_date <= date_to)
    if period_year:
        query = query.where(Payment.period_year == period_year)
    if period_month:
        query = query.where(Payment.period_month == period_month)
    
    # Count total
    count_query = select(func.count()).select_from(query.subquery())
    total_result = await session.execute(count_query)
    total = total_result.scalar()
    
    # Apply pagination with joins
    query = query.options(
        joinedload(Payment.santri),
        joinedload(Payment.payment_type),
        joinedload(Payment.recorded_by_user),
    ).order_by(Payment.payment_date.desc()).offset(skip).limit(limit)
    
    result = await session.execute(query)
    payments = result.unique().scalars().all()
    
    # Convert to response format
    data = []
    for payment in payments:
        data.append({
            "id": str(payment.id),
            "santri": {
                "id": str(payment.santri.id),
                "nis": payment.santri.nis,
                "full_name": payment.santri.full_name,
            },
            "payment_type": {
                "id": str(payment.payment_type.id),
                "name": payment.payment_type.name,
                "type": payment.payment_type.type,
            },
            "amount": float(payment.amount),
            "payment_date": payment.payment_date.isoformat(),
            "due_date": payment.due_date.isoformat(),
            "period": payment.period_display,
            "status": payment.status,
            "payment_method": payment.payment_method,
            "reference_number": payment.reference_number,
            "notes": payment.notes,
            "is_overdue": payment.is_overdue,
            "created_at": payment.created_at.isoformat(),
        })
    
    return PaginatedResponse(
        success=True,
        message="Payments retrieved successfully",
        data=data,
        meta={
            "page": skip // limit + 1,
            "per_page": limit,
            "total": total,
            "total_pages": (total + limit - 1) // limit,
            "has_next": skip + limit < total,
            "has_prev": skip > 0,
        },
    )


@router.get("/payments/{payment_id}")
async def get_payment(
    payment_id: UUID,
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """Get payment by ID."""
    result = await session.execute(
        select(Payment)
        .where(Payment.id == payment_id, Payment.deleted_at.is_(None))
        .options(
            joinedload(Payment.santri),
            joinedload(Payment.payment_type),
            joinedload(Payment.recorded_by_user),
        )
    )
    
    payment = result.unique().scalar_one_or_none()
    if not payment:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Payment not found",
        )
    
    # Verify pesantren access
    if payment.santri.pesantren_id != current_user.pesantren_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied",
        )
    
    return BaseResponse(
        success=True,
        message="Payment retrieved successfully",
        data={
            "id": str(payment.id),
            "santri": {
                "id": str(payment.santri.id),
                "nis": payment.santri.nis,
                "full_name": payment.santri.full_name,
            },
            "payment_type": {
                "id": str(payment.payment_type.id),
                "name": payment.payment_type.name,
                "type": payment.payment_type.type,
                "frequency": payment.payment_type.frequency,
            },
            "amount": float(payment.amount),
            "payment_date": payment.payment_date.isoformat(),
            "due_date": payment.due_date.isoformat(),
            "period": {
                "month": payment.period_month,
                "year": payment.period_year,
                "display": payment.period_display,
            },
            "status": payment.status,
            "payment_method": payment.payment_method,
            "reference_number": payment.reference_number,
            "proof_image_url": payment.proof_image_url,
            "notes": payment.notes,
            "is_overdue": payment.is_overdue,
            "recorded_by": payment.recorded_by_user.full_name if payment.recorded_by_user else None,
            "created_at": payment.created_at.isoformat(),
        },
    )


# === FINANCIAL REPORTS ===

@router.get("/reports/summary")
async def get_financial_summary(
    date_from: Optional[date] = Query(None, description="Start date"),
    date_to: Optional[date] = Query(None, description="End date"),
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """Get financial summary/report."""
    # Base query
    query = select(Payment).where(Payment.deleted_at.is_(None))
    
    # Filter by pesantren through santri
    query = query.join(Santri).where(Santri.pesantren_id == current_user.pesantren_id)
    
    # Apply date filters
    if date_from:
        query = query.where(Payment.payment_date >= date_from)
    if date_to:
        query = query.where(Payment.payment_date <= date_to)
    
    # Get all payments for summary
    result = await session.execute(query)
    payments = result.scalars().all()
    
    # Calculate summary
    total_payments = len(payments)
    total_amount = sum(float(p.amount) for p in payments)
    
    # Group by status
    status_counts = {}
    status_amounts = {}
    for payment in payments:
        status = payment.status
        status_counts[status] = status_counts.get(status, 0) + 1
        status_amounts[status] = status_amounts.get(status, 0) + float(payment.amount)
    
    # Group by payment type
    type_amounts = {}
    for payment in payments:
        ptype = payment.payment_type.type
        type_amounts[ptype] = type_amounts.get(ptype, 0) + float(payment.amount)
    
    # Outstanding payments
    outstanding_amount = sum(
        float(p.amount) for p in payments 
        if p.status in ["pending", "partial"] and p.due_date < date.today()
    )
    
    return BaseResponse(
        success=True,
        message="Financial summary retrieved successfully",
        data={
            "period": {
                "from": date_from.isoformat() if date_from else None,
                "to": date_to.isoformat() if date_to else None,
            },
            "summary": {
                "total_payments": total_payments,
                "total_amount": total_amount,
                "outstanding_amount": outstanding_amount,
            },
            "by_status": {
                "counts": status_counts,
                "amounts": {k: float(v) for k, v in status_amounts.items()},
            },
            "by_type": {k: float(v) for k, v in type_amounts.items()},
        },
    )


@router.get("/reports/arrears")
async def get_arrears_report(
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """Get arrears/overdue payments report."""
    query = select(Payment).where(
        Payment.deleted_at.is_(None),
        Payment.status.in_(["pending", "partial"]),
        Payment.due_date < date.today(),
    )
    
    # Filter by pesantren through santri
    query = query.join(Santri).where(Santri.pesantren_id == current_user.pesantren_id)
    
    # Get overdue payments
    result = await session.execute(
        query.options(
            joinedload(Payment.santri),
            joinedload(Payment.payment_type),
        ).order_by(Payment.due_date.asc())
    )
    
    payments = result.unique().scalars().all()
    
    # Group by santri
    arrears_by_santri = {}
    for payment in payments:
        santri_id = str(payment.santri.id)
        if santri_id not in arrears_by_santri:
            arrears_by_santri[santri_id] = {
                "santri": {
                    "id": str(payment.santri.id),
                    "nis": payment.santri.nis,
                    "full_name": payment.santri.full_name,
                    "class": payment.santri.current_class.name if payment.santri.current_class else None,
                },
                "total_arrears": 0,
                "payments": [],
            }
        
        arrears_by_santri[santri_id]["total_arrears"] += float(payment.amount)
        arrears_by_santri[santri_id]["payments"].append({
            "id": str(payment.id),
            "payment_type": payment.payment_type.name,
            "amount": float(payment.amount),
            "due_date": payment.due_date.isoformat(),
            "days_overdue": (date.today() - payment.due_date).days,
            "period": payment.period_display,
        })
    
    # Calculate totals
    total_arrears = sum(float(p.amount) for p in payments)
    total_santri = len(arrears_by_santri)
    
    return BaseResponse(
        success=True,
        message="Arrears report retrieved successfully",
        data={
            "summary": {
                "total_santri_with_arrears": total_santri,
                "total_arrears": total_arrears,
                "total_payments_overdue": len(payments),
            },
            "arrears_by_santri": list(arrears_by_santri.values()),
        },
    )
