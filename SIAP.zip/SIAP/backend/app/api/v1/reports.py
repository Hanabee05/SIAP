"""
Report generation endpoints.
"""

from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, and_
from sqlalchemy.orm import joinedload

from app.utils.database import get_db
from app.core.security import get_current_active_user, has_permission
from app.core.security import Permissions
from app.models.user import User
from app.models.santri import Santri
from app.models.academic import Grade, Attendance, TeachingAssignment, Class
from app.models.finance import Payment
from app.schemas.response import BaseResponse


router = APIRouter()


@router.get("/santri/{santri_id}/summary")
async def get_santri_summary(
    santri_id: UUID,
    academic_year_id: Optional[UUID] = Query(None, description="Filter by academic year"),
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """Get comprehensive summary for a santri."""
    # Get santri
    result = await session.execute(
        select(Santri)
        .where(
            Santri.id == santri_id,
            Santri.deleted_at.is_(None),
        )
        .options(
            joinedload(Santri.current_class),
        )
    )
    
    santri = result.unique().scalar_one_or_none()
    if not santri:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Santri not found",
        )
    
    # Verify pesantren access
    if santri.pesantren_id != current_user.pesantren_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied",
        )
    
    # Build filters
    filters = []
    if academic_year_id:
        filters.append(TeachingAssignment.academic_year_id == academic_year_id)
    
    # Get grades
    grades_query = select(Grade).where(
        Grade.santri_id == santri_id,
        Grade.deleted_at.is_(None),
    )
    
    if filters:
        grades_query = grades_query.join(TeachingAssignment).where(*filters)
    
    grades_result = await session.execute(
        grades_query.options(
            joinedload(Grade.teaching_assignment).joinedload(TeachingAssignment.subject),
        )
    )
    grades = grades_result.unique().scalars().all()
    
    # Group grades by subject
    grades_by_subject = {}
    for grade in grades:
        subject_name = grade.teaching_assignment.subject.name if grade.teaching_assignment.subject else "Unknown"
        if subject_name not in grades_by_subject:
            grades_by_subject[subject_name] = []
        grades_by_subject[subject_name].append({
            "type": grade.grade_type,
            "score": grade.score,
            "max_score": grade.max_score,
            "percentage": grade.percentage,
            "date": grade.date.isoformat(),
            "description": grade.description,
        })
    
    # Calculate average per subject
    subject_averages = {}
    for subject, subject_grades in grades_by_subject.items():
        avg = sum(g["percentage"] for g in subject_grades) / len(subject_grades)
        subject_averages[subject] = round(avg, 2)
    
    # Get attendance
    attendance_query = select(Attendance).where(
        Attendance.santri_id == santri_id,
        Attendance.deleted_at.is_(None),
    )
    
    if filters:
        attendance_query = attendance_query.join(TeachingAssignment).where(*filters)
    
    attendance_result = await session.execute(attendance_query)
    attendance_records = attendance_result.scalars().all()
    
    # Calculate attendance stats
    total_sessions = len(attendance_records)
    present_count = len([a for a in attendance_records if a.status == "present"])
    absent_count = len([a for a in attendance_records if a.status == "absent"])
    sick_count = len([a for a in attendance_records if a.status == "sick"])
    permission_count = len([a for a in attendance_records if a.status == "permission"])
    late_count = len([a for a in attendance_records if a.status == "late"])
    
    attendance_percentage = (present_count / total_sessions * 100) if total_sessions > 0 else 0
    
    # Get payments
    payments_query = select(Payment).where(
        Payment.santri_id == santri_id,
        Payment.deleted_at.is_(None),
    )
    
    payments_result = await session.execute(
        payments_query.options(
            joinedload(Payment.payment_type),
        )
    )
    payments = payments_result.unique().scalars().all()
    
    # Calculate payment stats
    total_payments = len(payments)
    total_paid = sum(float(p.amount) for p in payments if p.status == "paid")
    total_pending = sum(float(p.amount) for p in payments if p.status == "pending")
    total_overdue = sum(float(p.amount) for p in payments if p.is_overdue)
    
    # Overall average
    overall_average = sum(subject_averages.values()) / len(subject_averages) if subject_averages else 0
    
    return BaseResponse(
        success=True,
        message="Santri summary retrieved successfully",
        data={
            "santri": {
                "id": str(santri.id),
                "nis": santri.nis,
                "full_name": santri.full_name,
                "class": santri.current_class.name if santri.current_class else None,
                "status": santri.status,
                "enrollment_date": santri.enrollment_date.isoformat(),
                "photo_url": santri.photo_url,
            },
            "academic": {
                "grades_by_subject": grades_by_subject,
                "subject_averages": subject_averages,
                "overall_average": round(overall_average, 2),
                "total_subjects": len(grades_by_subject),
            },
            "attendance": {
                "total_sessions": total_sessions,
                "present": present_count,
                "absent": absent_count,
                "sick": sick_count,
                "permission": permission_count,
                "late": late_count,
                "attendance_percentage": round(attendance_percentage, 2),
            },
            "finance": {
                "total_payments": total_payments,
                "total_paid": total_paid,
                "total_pending": total_pending,
                "total_overdue": total_overdue,
            },
        },
    )


@router.get("/santri/{santri_id}/rapor")
async def generate_santri_rapor(
    santri_id: UUID,
    academic_year_id: Optional[UUID] = Query(None, description="Academic year ID"),
    semester: Optional[str] = Query(None, description="Semester (odd/even)"),
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """Generate santri report card (rapor)."""
    # Get santri
    result = await session.execute(
        select(Santri)
        .where(
            Santri.id == santri_id,
            Santri.deleted_at.is_(None),
        )
        .options(
            joinedload(Santri.current_class),
            joinedload(Santri.pesantren),
        )
    )
    
    santri = result.unique().scalar_one_or_none()
    if not santri:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Santri not found",
        )
    
    # Verify pesantren access
    if santri.pesantren_id != current_user.pesantren_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied",
        )
    
    # Build filters
    filters = []
    if academic_year_id:
        filters.append(TeachingAssignment.academic_year_id == academic_year_id)
    
    # Get grades grouped by subject
    grades_query = select(Grade).where(
        Grade.santri_id == santri_id,
        Grade.deleted_at.is_(None),
    )
    
    if filters:
        grades_query = grades_query.join(TeachingAssignment).where(*filters)
    
    grades_result = await session.execute(
        grades_query.options(
            joinedload(Grade.teaching_assignment).joinedload(TeachingAssignment.subject),
        )
    )
    grades = grades_result.unique().scalars().all()
    
    # Group by subject and calculate averages
    subjects_data = {}
    for grade in grades:
        subject = grade.teaching_assignment.subject
        subject_name = subject.name if subject else "Unknown"
        
        if subject_name not in subjects_data:
            subjects_data[subject_name] = {
                "subject": subject_name,
                "category": subject.category if subject else "Unknown",
                "daily": [],
                "midterm": [],
                "final": [],
                "practice": [],
            }
        
        subjects_data[subject_name][grade.grade_type].append({
            "score": grade.score,
            "max_score": grade.max_score,
            "percentage": grade.percentage,
            "date": grade.date.isoformat(),
            "description": grade.description,
        })
    
    # Calculate final grades per subject
    final_grades = []
    for subject_name, data in subjects_data.items():
        daily_avg = sum(g["percentage"] for g in data["daily"]) / len(data["daily"]) if data["daily"] else 0
        midterm_avg = sum(g["percentage"] for g in data["midterm"]) / len(data["midterm"]) if data["midterm"] else 0
        final_avg = sum(g["percentage"] for g in data["final"]) / len(data["final"]) if data["final"] else 0
        practice_avg = sum(g["percentage"] for g in data["practice"]) / len(data["practice"]) if data["practice"] else 0
        
        # Calculate final score (weighted average)
        final_score = (
            daily_avg * 0.3 +  # 30% daily
            midterm_avg * 0.3 +  # 30% midterm
            final_avg * 0.4  # 40% final
        ) if final_avg > 0 else (daily_avg * 0.5 + midterm_avg * 0.5)
        
        final_grades.append({
            "subject": subject_name,
            "category": data["category"],
            "daily_average": round(daily_avg, 2),
            "midterm_average": round(midterm_avg, 2),
            "final_average": round(final_avg, 2),
            "practice_average": round(practice_avg, 2),
            "final_score": round(final_score, 2),
            "grade": calculate_letter_grade(final_score),
        })
    
    # Calculate overall average
    overall_average = sum(g["final_score"] for g in final_grades) / len(final_grades) if final_grades else 0
    
    # Get attendance summary
    attendance_query = select(Attendance).where(
        Attendance.santri_id == santri_id,
        Attendance.deleted_at.is_(None),
    )
    
    if filters:
        attendance_query = attendance_query.join(TeachingAssignment).where(*filters)
    
    attendance_result = await session.execute(attendance_query)
    attendance_records = attendance_result.scalars().all()
    
    total_days = len(attendance_records)
    present_days = len([a for a in attendance_records if a.status == "present"])
    attendance_percentage = (present_days / total_days * 100) if total_days > 0 else 0
    
    # Get pesantren info for the report
    pesantren = santri.pesantren
    
    return BaseResponse(
        success=True,
        message="Rapor generated successfully",
        data={
            "pesantren": {
                "name": pesantren.name,
                "address": pesantren.address,
                "phone": pesantren.phone,
                "logo_url": pesantren.logo_url,
            },
            "santri": {
                "id": str(santri.id),
                "nis": santri.nis,
                "full_name": santri.full_name,
                "birth_date": santri.birth_date.isoformat() if santri.birth_date else None,
                "birth_place": santri.birth_place,
                "class": santri.current_class.name if santri.current_class else None,
                "enrollment_date": santri.enrollment_date.isoformat(),
                "photo_url": santri.photo_url,
            },
            "academic_year": academic_year_id,  # TODO: Get academic year name
            "semester": semester,
            "grades": final_grades,
            "summary": {
                "total_subjects": len(final_grades),
                "overall_average": round(overall_average, 2),
                "overall_grade": calculate_letter_grade(overall_average),
            },
            "attendance": {
                "total_days": total_days,
                "present_days": present_days,
                "attendance_percentage": round(attendance_percentage, 2),
            },
        },
    )


def calculate_letter_grade(score: float) -> str:
    """Convert numeric score to letter grade."""
    if score >= 90:
        return "A"
    elif score >= 80:
        return "B"
    elif score >= 70:
        return "C"
    elif score >= 60:
        return "D"
    else:
        return "E"
