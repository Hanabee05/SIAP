"""
Staff (non-teaching) endpoints.
"""

from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, or_
from sqlalchemy.orm import joinedload

from app.utils.database import get_db
from app.core.security import get_current_active_user, has_permission
from app.core.security import Permissions
from app.models.user import User
from app.models.staff import Staff
from app.schemas.response import BaseResponse, PaginatedResponse


router = APIRouter()


@router.get("/")
async def list_staff(
    department: Optional[str] = Query(None, description="Filter by department"),
    employment_status: Optional[str] = Query(None, description="Filter by employment status"),
    is_active: Optional[bool] = Query(None, description="Filter by active status"),
    search: Optional[str] = Query(None, description="Search by name or position"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=100, description="Number of records to return"),
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """List staff with pagination and filters."""
    query = select(Staff).where(Staff.deleted_at.is_(None))
    
    # Filter by pesantren
    query = query.where(Staff.pesantren_id == current_user.pesantren_id)
    
    # Apply filters
    if department:
        query = query.where(Staff.department == department)
    if employment_status:
        query = query.where(Staff.employment_status == employment_status)
    if is_active is not None:
        query = query.where(Staff.is_active == is_active)
    if search:
        query = query.where(
            or_(
                Staff.full_name.ilike(f"%{search}%"),
                Staff.position.ilike(f"%{search}%"),
            )
        )
    
    # Count total
    count_query = select(func.count()).select_from(query.subquery())
    total_result = await session.execute(count_query)
    total = total_result.scalar()
    
    # Apply pagination
    query = query.order_by(Staff.full_name.asc()).offset(skip).limit(limit)
    
    result = await session.execute(query)
    staff_list = result.scalars().all()
    
    # Convert to response format
    data = []
    for staff in staff_list:
        data.append({
            "id": str(staff.id),
            "full_name": staff.full_name,
            "position": staff.position,
            "department": staff.department,
            "employment_status": staff.employment_status,
            "hire_date": staff.hire_date.isoformat() if staff.hire_date else None,
            "is_active": staff.is_active,
            "contact": {
                "phone": staff.phone,
                "email": staff.email,
                "address": staff.address,
            },
            "bio": staff.bio,
            "photo_url": staff.photo_url,
            "created_at": staff.created_at.isoformat(),
            "updated_at": staff.updated_at.isoformat(),
        })
    
    return PaginatedResponse(
        success=True,
        message="Staff retrieved successfully",
        data=data,
        meta={
            "page": skip // limit + 1,
            "per_page": limit,
            "total": total,
            "total_pages": (total + limit - 1) // limit,
            "has_next": skip + limit < total,
            "has_prev": skip > 0,
        },
    )


@router.get("/{staff_id}")
async def get_staff(
    staff_id: UUID,
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """Get staff by ID."""
    result = await session.execute(
        select(Staff)
        .where(
            Staff.id == staff_id,
            Staff.deleted_at.is_(None),
            Staff.pesantren_id == current_user.pesantren_id,
        )
    )
    
    staff = result.scalar_one_or_none()
    if not staff:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Staff not found",
        )
    
    return BaseResponse(
        success=True,
        message="Staff retrieved successfully",
        data={
            "id": str(staff.id),
            "full_name": staff.full_name,
            "birth_date": staff.birth_date.isoformat() if staff.birth_date else None,
            "birth_place": staff.birth_place,
            "gender": staff.gender,
            "address": staff.address,
            "phone": staff.phone,
            "email": staff.email,
            "position": staff.position,
            "department": staff.department,
            "employment_status": staff.employment_status,
            "hire_date": staff.hire_date.isoformat() if staff.hire_date else None,
            "is_active": staff.is_active,
            "bio": staff.bio,
            "photo_url": staff.photo_url,
            "notes": staff.notes,
            "created_at": staff.created_at.isoformat(),
            "updated_at": staff.updated_at.isoformat(),
        },
    )


@router.get("/departments/list")
async def list_departments(
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """List unique departments."""
    result = await session.execute(
        select(Staff.department)
        .where(
            Staff.pesantren_id == current_user.pesantren_id,
            Staff.deleted_at.is_(None),
        )
        .distinct()
        .order_by(Staff.department)
    )
    
    departments = [row[0] for row in result.all() if row[0]]
    
    return BaseResponse(
        success=True,
        message="Departments retrieved successfully",
        data=departments,
    )
