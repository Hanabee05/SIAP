"""
Utility endpoints.
"""

from datetime import date
from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, or_
from sqlalchemy.orm import joinedload

from app.utils.database import get_db
from app.core.security import get_current_active_user, has_permission
from app.core.security import Permissions
from app.models.user import User
from app.models.academic import AcademicYear
from app.models.audit import AuditLog
from app.schemas.response import BaseResponse, PaginatedResponse


router = APIRouter()


@router.get("/academic-years")
async def list_academic_years(
    is_active: Optional[bool] = Query(None, description="Filter by active status"),
    is_current: Optional[bool] = Query(None, description="Filter by current status"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=100, description="Number of records to return"),
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """List academic years with pagination and filters."""
    query = select(AcademicYear).where(AcademicYear.deleted_at.is_(None))
    
    # Filter by pesantren
    query = query.where(AcademicYear.pesantren_id == current_user.pesantren_id)
    
    # Apply filters
    if is_active is not None:
        query = query.where(AcademicYear.is_active == is_active)
    if is_current is not None:
        query = query.where(AcademicYear.is_current == is_current)
    
    # Count total
    count_query = select(func.count()).select_from(query.subquery())
    total_result = await session.execute(count_query)
    total = total_result.scalar()
    
    # Apply pagination
    query = query.order_by(AcademicYear.start_date.desc()).offset(skip).limit(limit)
    
    result = await session.execute(query)
    academic_years = result.scalars().all()
    
    # Convert to response format
    data = []
    for ay in academic_years:
        data.append({
            "id": str(ay.id),
            "name": ay.name,
            "start_date": ay.start_date.isoformat(),
            "end_date": ay.end_date.isoformat(),
            "is_active": ay.is_active,
            "is_current": ay.is_current,
            "created_at": ay.created_at.isoformat(),
        })
    
    return PaginatedResponse(
        success=True,
        message="Academic years retrieved successfully",
        data=data,
        meta={
            "page": skip // limit + 1,
            "per_page": limit,
            "total": total,
            "total_pages": (total + limit - 1) // limit,
            "has_next": skip + limit < total,
            "has_prev": skip > 0,
        },
    )


@router.get("/academic-years/current")
async def get_current_academic_year(
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """Get current academic year."""
    result = await session.execute(
        select(AcademicYear)
        .where(
            AcademicYear.pesantren_id == current_user.pesantren_id,
            AcademicYear.is_current == True,
            AcademicYear.deleted_at.is_(None),
        )
    )
    
    academic_year = result.scalar_one_or_none()
    if not academic_year:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Current academic year not found",
        )
    
    return BaseResponse(
        success=True,
        message="Current academic year retrieved successfully",
        data={
            "id": str(academic_year.id),
            "name": academic_year.name,
            "start_date": academic_year.start_date.isoformat(),
            "end_date": academic_year.end_date.isoformat(),
            "is_active": academic_year.is_active,
            "is_current": academic_year.is_current,
        },
    )


@router.post("/class-promotion")
async def promote_students(
    from_class_id: UUID,
    to_class_id: UUID,
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """
    Promote students from one class to another.
    
    This is a utility endpoint for end-of-year class promotion.
    """
    # Check permission
    if not has_permission(current_user.role, Permissions.ADMIN_MANAGE_CLASSES):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions",
        )
    
    # Get classes
    from_class_result = await session.execute(
        select(Class).where(
            Class.id == from_class_id,
            Class.pesantren_id == current_user.pesantren_id,
        )
    )
    from_class = from_class_result.scalar_one_or_none()
    
    to_class_result = await session.execute(
        select(Class).where(
            Class.id == to_class_id,
            Class.pesantren_id == current_user.pesantren_id,
        )
    )
    to_class = to_class_result.scalar_one_or_none()
    
    if not from_class or not to_class:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="One or both classes not found",
        )
    
    # Update santri current_class_id
    await session.execute(
        select(Santri)
        .where(
            Santri.current_class_id == from_class_id,
            Santri.status == "active",
        )
        .execution_options(synchronize_session="fetch")
    )
    
    # TODO: Implement proper promotion logic
    # This would involve:
    # 1. Creating new SantriClass records for the new academic year
    # 2. Updating current_class_id for active santri
    # 3. Handling graduation for final year students
    
    return BaseResponse(
        success=True,
        message="Class promotion completed successfully",
        data={
            "from_class": from_class.name,
            "to_class": to_class.name,
            "promoted_count": 0,  # TODO: Return actual count
        },
    )


@router.get("/audit-logs")
async def list_audit_logs(
    action: Optional[str] = Query(None, description="Filter by action"),
    resource_type: Optional[str] = Query(None, description="Filter by resource type"),
    user_id: Optional[UUID] = Query(None, description="Filter by user"),
    date_from: Optional[date] = Query(None, description="Filter from date"),
    date_to: Optional[date] = Query(None, description="Filter to date"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=100, description="Number of records to return"),
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """List audit logs with pagination and filters."""
    # Check permission
    if not has_permission(current_user.role, Permissions.ADMIN_VIEW_REPORTS):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Insufficient permissions",
        )
    
    query = select(AuditLog).where(AuditLog.pesantren_id == current_user.pesantren_id)
    
    # Apply filters
    if action:
        query = query.where(AuditLog.action == action)
    if resource_type:
        query = query.where(AuditLog.resource_type == resource_type)
    if user_id:
        query = query.where(AuditLog.user_id == user_id)
    if date_from:
        query = query.where(AuditLog.created_at >= date_from)
    if date_to:
        query = query.where(AuditLog.created_at <= date_to)
    
    # Count total
    count_query = select(func.count()).select_from(query.subquery())
    total_result = await session.execute(count_query)
    total = total_result.scalar()
    
    # Apply pagination with joins
    query = query.options(
        joinedload(AuditLog.user),
    ).order_by(AuditLog.created_at.desc()).offset(skip).limit(limit)
    
    result = await session.execute(query)
    logs = result.unique().scalars().all()
    
    # Convert to response format
    data = []
    for log in logs:
        data.append({
            "id": str(log.id),
            "user": {
                "id": str(log.user.id) if log.user else None,
                "email": log.user.email if log.user else "System",
                "role": log.user.role if log.user else None,
            },
            "action": log.action,
            "resource_type": log.resource_type,
            "resource_id": str(log.resource_id) if log.resource_id else None,
            "ip_address": str(log.ip_address) if log.ip_address else None,
            "request_method": log.request_method,
            "request_path": log.request_path,
            "created_at": log.created_at.isoformat(),
            "display_action": log.display_action,
            "display_resource": log.display_resource,
        })
    
    return PaginatedResponse(
        success=True,
        message="Audit logs retrieved successfully",
        data=data,
        meta={
            "page": skip // limit + 1,
            "per_page": limit,
            "total": total,
            "total_pages": (total + limit - 1) // limit,
            "has_next": skip + limit < total,
            "has_prev": skip > 0,
        },
    )


@router.get("/dashboard/stats")
async def get_dashboard_stats(
    current_user: User = Depends(get_current_active_user),
    session: AsyncSession = Depends(get_db),
):
    """Get dashboard statistics."""
    from sqlalchemy import select, func
    from app.models.santri import Santri
    from app.models.ustadz import Ustadz
    from app.models.finance import Payment
    from app.models.academic import Class
    from datetime import datetime, timedelta
    
    stats = {}
    
    # Santri stats
    santri_query = select(func.count(Santri.id)).where(
        Santri.pesantren_id == current_user.pesantren_id,
        Santri.deleted_at.is_(None),
    )
    
    # Total santri
    total_santri_result = await session.execute(santri_query)
    stats["total_santri"] = total_santri_result.scalar()
    
    # Active santri
    active_santri_result = await session.execute(
        santri_query.where(Santri.status == "active")
    )
    stats["active_santri"] = active_santri_result.scalar()
    
    # Ustadz stats
    ustadz_query = select(func.count(Ustadz.id)).where(
        Ustadz.pesantren_id == current_user.pesantren_id,
        Ustadz.deleted_at.is_(None),
        Ustadz.is_active == True,
    )
    ustadz_result = await session.execute(ustadz_query)
    stats["active_ustadz"] = ustadz_result.scalar()
    
    # Class stats
    class_query = select(func.count(Class.id)).where(
        Class.pesantren_id == current_user.pesantren_id,
        Class.deleted_at.is_(None),
        Class.is_active == True,
    )
    class_result = await session.execute(class_query)
    stats["active_classes"] = class_result.scalar()
    
    # Payment stats (current month)
    current_month = datetime.now().month
    current_year = datetime.now().year
    
    payment_query = select(func.sum(Payment.amount)).where(
        Payment.period_month == current_month,
        Payment.period_year == current_year,
        Payment.status == "paid",
    ).join(Santri).where(Santri.pesantren_id == current_user.pesantren_id)
    
    payment_result = await session.execute(payment_query)
    monthly_revenue = payment_result.scalar() or 0
    stats["monthly_revenue"] = float(monthly_revenue)
    
    # Outstanding payments
    outstanding_query = select(func.sum(Payment.amount)).where(
        Payment.due_date < datetime.now().date(),
        Payment.status.in_(["pending", "partial"]),
    ).join(Santri).where(Santri.pesantren_id == current_user.pesantren_id)
    
    outstanding_result = await session.execute(outstanding_query)
    outstanding_amount = outstanding_result.scalar() or 0
    stats["outstanding_amount"] = float(outstanding_amount)
    
    return BaseResponse(
        success=True,
        message="Dashboard statistics retrieved successfully",
        data=stats,
    )


@router.get("/system/info")
async def get_system_info():
    """Get system information."""
    from app.config import settings
    
    return BaseResponse(
        success=True,
        message="System information retrieved successfully",
        data={
            "app_name": settings.APP_NAME,
            "app_version": settings.APP_VERSION,
            "environment": settings.ENVIRONMENT,
            "debug": settings.DEBUG,
            "features": {
                "registration": settings.ENABLE_REGISTRATION,
                "password_reset": settings.ENABLE_PASSWORD_RESET,
                "audit_log": settings.ENABLE_AUDIT_LOG,
                "soft_delete": settings.ENABLE_SOFT_DELETE,
            },
        },
    )
