"""
Security utilities for authentication and authorization.
"""

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional, Union
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.config import settings
from app.models.user import User


# Password hashing context
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def create_access_token(
    subject: Union[str, Any],
    expires_delta: Optional[timedelta] = None,
    additional_claims: Optional[Dict[str, Any]] = None,
) -> str:
    """
    Create JWT access token.
    
    Args:
        subject: User identifier (usually user_id)
        expires_delta: Token expiry time delta
        additional_claims: Additional claims to include in token
    
    Returns:
        JWT token string
    """
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(
            minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES
        )
    
    to_encode = {
        "exp": expire,
        "sub": str(subject),
        "type": "access",
    }
    
    if additional_claims:
        to_encode.update(additional_claims)
    
    encoded_jwt = jwt.encode(
        to_encode,
        settings.SECRET_KEY,
        algorithm=settings.ALGORITHM,
    )
    
    return encoded_jwt


def create_refresh_token(
    subject: Union[str, Any],
    expires_delta: Optional[timedelta] = None,
) -> str:
    """
    Create JWT refresh token.
    
    Args:
        subject: User identifier (usually user_id)
        expires_delta: Token expiry time delta
    
    Returns:
        JWT refresh token string
    """
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(
            days=settings.REFRESH_TOKEN_EXPIRE_DAYS
        )
    
    to_encode = {
        "exp": expire,
        "sub": str(subject),
        "type": "refresh",
    }
    
    encoded_jwt = jwt.encode(
        to_encode,
        settings.SECRET_KEY,
        algorithm=settings.ALGORITHM,
    )
    
    return encoded_jwt


def verify_token(token: str) -> Optional[Dict[str, Any]]:
    """
    Verify JWT token and return payload.
    
    Args:
        token: JWT token string
    
    Returns:
        Token payload if valid, None if invalid
    """
    try:
        payload = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITHM],
        )
        return payload
    except JWTError:
        return None


def verify_refresh_token(token: str) -> Optional[str]:
    """
    Verify refresh token and return user_id.
    
    Args:
        token: JWT refresh token
    
    Returns:
        User ID if token is valid, None otherwise
    """
    payload = verify_token(token)
    if payload and payload.get("type") == "refresh":
        return payload.get("sub")
    return None


def hash_password(password: str) -> str:
    """
    Hash password using bcrypt.
    
    Args:
        password: Plain text password
    
    Returns:
        Hashed password
    """
    return pwd_context.hash(password)


def verify_password(password: str, hashed_password: str) -> bool:
    """
    Verify password against hash.
    
    Args:
        password: Plain text password
        hashed_password: Hashed password
    
    Returns:
        True if password matches, False otherwise
    """
    return pwd_context.verify(password, hashed_password)


async def authenticate_user(
    session: AsyncSession,
    email: str,
    password: str,
) -> Optional[User]:
    """
    Authenticate user by email and password.
    
    Args:
        session: Database session
        email: User email
        password: User password
    
    Returns:
        User object if authenticated, None otherwise
    """
    result = await session.execute(
        select(User).where(User.email == email, User.is_active == True)
    )
    user = result.scalar_one_or_none()
    
    if not user:
        return None
    
    if not verify_password(password, user.password_hash):
        return None
    
    return user


async def get_user_by_id(session: AsyncSession, user_id: str) -> Optional[User]:
    """
    Get user by ID.
    
    Args:
        session: Database session
        user_id: User UUID
    
    Returns:
        User object if found, None otherwise
    """
    result = await session.execute(
        select(User).where(User.id == user_id, User.is_active == True)
    )
    return result.scalar_one_or_none()


def generate_password_reset_token(user_id: str) -> str:
    """
    Generate password reset token.
    
    Args:
        user_id: User ID
    
    Returns:
        JWT token for password reset
    """
    expire = datetime.now(timezone.utc) + timedelta(hours=1)  # 1 hour expiry
    
    to_encode = {
        "exp": expire,
        "sub": str(user_id),
        "type": "password_reset",
    }
    
    return jwt.encode(
        to_encode,
        settings.SECRET_KEY,
        algorithm=settings.ALGORITHM,
    )


def verify_password_reset_token(token: str) -> Optional[str]:
    """
    Verify password reset token.
    
    Args:
        token: JWT password reset token
    
    Returns:
        User ID if token is valid, None otherwise
    """
    payload = verify_token(token)
    if payload and payload.get("type") == "password_reset":
        return payload.get("sub")
    return None


# Permission constants
class Permissions:
    """Permission constants for role-based access control."""
    
    # Super Admin - has all permissions
    SUPER_ADMIN = "super_admin"
    
    # Admin Pesantren permissions
    ADMIN_DASHBOARD = "admin:dashboard"
    ADMIN_MANAGE_SANTRI = "admin:manage_santri"
    ADMIN_MANAGE_USTADZ = "admin:manage_ustadz"
    ADMIN_MANAGE_CLASSES = "admin:manage_classes"
    ADMIN_MANAGE_FINANCE = "admin:manage_finance"
    ADMIN_VIEW_REPORTS = "admin:view_reports"
    ADMIN_MANAGE_ALUMNI = "admin:manage_alumni"
    ADMIN_MANAGE_STAFF = "admin:manage_staff"
    
    # Ustadz permissions
    USTADZ_DASHBOARD = "ustadz:dashboard"
    USTADZ_VIEW_SANTRI = "ustadz:view_santri"
    USTADZ_MANAGE_ATTENDANCE = "ustadz:manage_attendance"
    USTADZ_MANAGE_GRADES = "ustadz:manage_grades"
    USTADZ_VIEW_SCHEDULE = "ustadz:view_schedule"
    
    # Santri permissions
    SANTRI_DASHBOARD = "santri:dashboard"
    SANTRI_VIEW_PROFILE = "santri:view_profile"
    SANTRI_VIEW_GRADES = "santri:view_grades"
    SANTRI_VIEW_ATTENDANCE = "santri:view_attendance"
    SANTRI_VIEW_PAYMENTS = "santri:view_payments"


# Role-based permission mapping
ROLE_PERMISSIONS = {
    "super_admin": [
        Permissions.SUPER_ADMIN,
        # Include all other permissions
        Permissions.ADMIN_DASHBOARD,
        Permissions.ADMIN_MANAGE_SANTRI,
        Permissions.ADMIN_MANAGE_USTADZ,
        Permissions.ADMIN_MANAGE_CLASSES,
        Permissions.ADMIN_MANAGE_FINANCE,
        Permissions.ADMIN_VIEW_REPORTS,
        Permissions.ADMIN_MANAGE_ALUMNI,
        Permissions.ADMIN_MANAGE_STAFF,
        Permissions.USTADZ_DASHBOARD,
        Permissions.USTADZ_VIEW_SANTRI,
        Permissions.USTADZ_MANAGE_ATTENDANCE,
        Permissions.USTADZ_MANAGE_GRADES,
        Permissions.USTADZ_VIEW_SCHEDULE,
        Permissions.SANTRI_DASHBOARD,
        Permissions.SANTRI_VIEW_PROFILE,
        Permissions.SANTRI_VIEW_GRADES,
        Permissions.SANTRI_VIEW_ATTENDANCE,
        Permissions.SANTRI_VIEW_PAYMENTS,
    ],
    "admin_pesantren": [
        Permissions.ADMIN_DASHBOARD,
        Permissions.ADMIN_MANAGE_SANTRI,
        Permissions.ADMIN_MANAGE_USTADZ,
        Permissions.ADMIN_MANAGE_CLASSES,
        Permissions.ADMIN_MANAGE_FINANCE,
        Permissions.ADMIN_VIEW_REPORTS,
        Permissions.ADMIN_MANAGE_ALUMNI,
        Permissions.ADMIN_MANAGE_STAFF,
        Permissions.USTADZ_VIEW_SANTRI,
        Permissions.USTADZ_VIEW_SCHEDULE,
    ],
    "ustadz": [
        Permissions.USTADZ_DASHBOARD,
        Permissions.USTADZ_VIEW_SANTRI,
        Permissions.USTADZ_MANAGE_ATTENDANCE,
        Permissions.USTADZ_MANAGE_GRADES,
        Permissions.USTADZ_VIEW_SCHEDULE,
    ],
    "santri": [
        Permissions.SANTRI_DASHBOARD,
        Permissions.SANTRI_VIEW_PROFILE,
        Permissions.SANTRI_VIEW_GRADES,
        Permissions.SANTRI_VIEW_ATTENDANCE,
        Permissions.SANTRI_VIEW_PAYMENTS,
    ],
}


def has_permission(user_role: str, permission: str) -> bool:
    """
    Check if user role has specific permission.
    
    Args:
        user_role: User role (super_admin, admin_pesantren, ustadz, santri)
        permission: Permission string
    
    Returns:
        True if role has permission, False otherwise
    """
    if user_role not in ROLE_PERMISSIONS:
        return False
    
    # Super admin has all permissions
    if Permissions.SUPER_ADMIN in ROLE_PERMISSIONS[user_role]:
        return True
    
    return permission in ROLE_PERMISSIONS[user_role]


def get_role_permissions(user_role: str) -> List[str]:
    """
    Get all permissions for a role.
    
    Args:
        user_role: User role
    
    Returns:
        List of permission strings
    """
    return ROLE_PERMISSIONS.get(user_role, [])
