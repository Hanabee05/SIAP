"""
FastAPI dependencies for common functionality.
"""

from typing import Optional
from fastapi import Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession

from app.utils.database import get_db
from app.core.security import (
    get_current_active_user as get_current_user,
    has_permission,
)
from app.models.user import User


# Re-export commonly used dependencies
get_db_session = get_db
get_current_active_user = get_current_user


class PermissionChecker:
    """Dependency for checking user permissions."""
    
    def __init__(self, required_permissions: list[str]):
        self.required_permissions = required_permissions
    
    def __call__(self, current_user: User = Depends(get_current_active_user)) -> User:
        """Check if user has required permissions."""
        if not any(has_permission(current_user.role, perm) for perm in self.required_permissions):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Insufficient permissions",
            )
        return current_user


def require_permissions(*permissions: str) -> PermissionChecker:
    """Create a permission checker dependency."""
    return PermissionChecker(list(permissions))


# Role-specific permission checkers
require_admin = require_permissions("admin:dashboard")
require_super_admin = require_permissions("super_admin")
require_ustadz = require_permissions("ustadz:dashboard")
require_santri = require_permissions("santri:dashboard")


# Module-specific permission checkers
require_academic_manage = require_permissions("admin:manage_classes", "ustadz:manage_attendance")
require_finance_manage = require_permissions("admin:manage_finance")
require_reports_view = require_permissions("admin:view_reports", "ustadz:view_reports")
require_alumni_manage = require_permissions("admin:manage_alumni")
require_staff_manage = require_permissions("admin:manage_staff")


class Paginator:
    """Pagination dependency."""
    
    def __init__(
        self,
        default_limit: int = 20,
        max_limit: int = 100,
    ):
        self.default_limit = default_limit
        self.max_limit = max_limit
    
    def __call__(
        self,
        page: int = Depends(lambda: 1),
        per_page: int = Depends(lambda: 20),
    ) -> dict:
        """Calculate pagination parameters."""
        page = max(1, page)
        per_page = min(max(1, per_page), self.max_limit)
        
        offset = (page - 1) * per_page
        
        return {
            "page": page,
            "per_page": per_page,
            "offset": offset,
        }


# Default paginator
paginate = Paginator()
