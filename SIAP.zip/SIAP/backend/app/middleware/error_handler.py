"""
Error handling middleware.
"""

import json
import traceback
from datetime import datetime
from typing import Any, Dict

from fastapi import Request, Response
from fastapi.responses import JSONResponse
from fastapi.exceptions import RequestValidationError
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.exceptions import HTTPException as StarletteHTTPException

from app.config import settings
from app.schemas.response import ErrorResponse


class ErrorHandlerMiddleware(BaseHTTPMiddleware):
    """Global error handling middleware."""
    
    async def dispatch(self, request: Request, call_next):
        """Process request and handle errors."""
        try:
            response = await call_next(request)
            return response
        except Exception as exc:
            return await self.handle_exception(exc, request)
    
    async def handle_exception(self, exc: Exception, request: Request) -> JSONResponse:
        """Handle different types of exceptions."""
        # Log the error
        error_details = {
            "timestamp": datetime.utcnow().isoformat(),
            "method": request.method,
            "url": str(request.url),
            "error": str(exc),
            "traceback": traceback.format_exc(),
        }
        
        # In production, you might want to send this to a logging service
        if settings.DEBUG:
            print(json.dumps(error_details, indent=2))
        
        # Handle different exception types
        if isinstance(exc, StarletteHTTPException):
            return await self.handle_http_exception(exc, request)
        elif isinstance(exc, RequestValidationError):
            return await self.handle_validation_error(exc, request)
        else:
            return await self.handle_internal_error(exc, request)
    
    async def handle_http_exception(
        self,
        exc: StarletteHTTPException,
        request: Request,
    ) -> JSONResponse:
        """Handle HTTP exceptions."""
        error_response = ErrorResponse(
            success=False,
            message=exc.detail or "HTTP Error",
            error_code=f"HTTP_{exc.status_code}",
        )
        
        return JSONResponse(
            status_code=exc.status_code,
            content=error_response.model_dump(),
        )
    
    async def handle_validation_error(
        self,
        exc: RequestValidationError,
        request: Request,
    ) -> JSONResponse:
        """Handle request validation errors."""
        # Extract validation errors
        errors = {}
        for error in exc.errors():
            field = ".".join(str(loc) for loc in error["loc"][1:])  # Skip 'body' prefix
            if field not in errors:
                errors[field] = []
            errors[field].append(error["msg"])
        
        error_response = ErrorResponse(
            success=False,
            message="Validation error",
            errors=errors,
            error_code="VALIDATION_ERROR",
        )
        
        return JSONResponse(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            content=error_response.model_dump(),
        )
    
    async def handle_internal_error(
        self,
        exc: Exception,
        request: Request,
    ) -> JSONResponse:
        """Handle internal server errors."""
        # Don't expose internal errors in production
        if settings.DEBUG:
            message = str(exc)
            error_code = "INTERNAL_ERROR"
        else:
            message = "An internal server error occurred"
            error_code = "INTERNAL_SERVER_ERROR"
        
        error_response = ErrorResponse(
            success=False,
            message=message,
            error_code=error_code,
        )
        
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content=error_response.model_dump(),
        )


# Create middleware instance
error_handler_middleware = ErrorHandlerMiddleware()
