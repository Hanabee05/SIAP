"""
Database models for SIAP.
"""

from app.models.base import BaseModel, SoftDeleteMixin
from app.models.user import User
from app.models.pesantren import Pesantren
from app.models.santri import Santri
from app.models.ustadz import Ustadz
from app.models.academic import (
    AcademicYear,
    Class,
    Subject,
    SantriClass,
    TeachingAssignment,
    Attendance,
    Grade,
)
from app.models.finance import PaymentType, Payment
from app.models.alumni import Alumni
from app.models.staff import Staff
from app.models.audit import AuditLog

# Export all models
__all__ = [
    "BaseModel",
    "SoftDeleteMixin",
    "User",
    "Pesantren",
    "Santri",
    "Ustadz",
    "AcademicYear",
    "Class",
    "Subject",
    "SantriClass",
    "TeachingAssignment",
    "Attendance",
    "Grade",
    "PaymentType",
    "Payment",
    "Alumni",
    "Staff",
    "AuditLog",
]
