"""
Academic models for SIAP.
"""

from sqlalchemy import Column, Date, Enum, ForeignKey, Integer, String, Text, Boolean, Time
from sqlalchemy.orm import relationship, Mapped

from app.models.base import BaseModel, SoftDeleteMixin


class AcademicYear(BaseModel):
    """Academic year model."""
    
    __tablename__ = "academic_years"
    
    pesantren_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("pesantren.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    name: Mapped[str] = Column(
        String(100),
        nullable=False,
    )  # e.g., "2024/2025"
    
    start_date: Mapped[str] = Column(
        Date,
        nullable=False,
    )
    
    end_date: Mapped[str] = Column(
        Date,
        nullable=False,
    )
    
    is_active: Mapped[bool] = Column(
        Boolean,
        default=True,
        nullable=False,
    )
    
    is_current: Mapped[bool] = Column(
        Boolean,
        default=False,
        nullable=False,
    )
    
    # Relationships
    pesantren = relationship("Pesantren", back_populates="academic_years")
    classes = relationship("Class", back_populates="academic_year")
    santri_classes = relationship("SantriClass", back_populates="academic_year")
    teaching_assignments = relationship("TeachingAssignment", back_populates="academic_year")
    
    def __repr__(self) -> str:
        return f"<AcademicYear(id={self.id}, name={self.name})>"


class Class(BaseModel, SoftDeleteMixin):
    """Class/Kelas model."""
    
    __tablename__ = "classes"
    
    pesantren_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("pesantren.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    academic_year_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("academic_years.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    name: Mapped[str] = Column(
        String(100),
        nullable=False,
    )  # e.g., "1A", "2B"
    
    level: Mapped[str] = Column(
        String(50),
        nullable=False,
    )  # e.g., "SMP", "SMA", "Tahfidz"
    
    class_teacher_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("ustadz.id", ondelete="SET NULL"),
        nullable=True,
    )
    
    capacity: Mapped[int] = Column(
        Integer,
        default=30,
        nullable=False,
    )
    
    description: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    room_number: Mapped[str] = Column(
        String(20),
        nullable=True,
    )
    
    is_active: Mapped[bool] = Column(
        Boolean,
        default=True,
        nullable=False,
    )
    
    # Relationships
    pesantren = relationship("Pesantren", back_populates="classes")
    academic_year = relationship("AcademicYear", back_populates="classes")
    class_teacher = relationship("Ustadz", back_populates="classes_as_teacher")
    santri_classes = relationship("SantriClass", back_populates="class_")
    teaching_assignments = relationship("TeachingAssignment", back_populates="class_")
    
    def __repr__(self) -> str:
        return f"<Class(id={self.id}, name={self.name})>"
    
    @property
    def student_count(self) -> int:
        """Get number of students in this class."""
        return len([sc for sc in self.santri_classes if sc.is_active])


class Subject(BaseModel, SoftDeleteMixin):
    """Subject/Mata Pelajaran model."""
    
    __tablename__ = "subjects"
    
    pesantren_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("pesantren.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    code: Mapped[str] = Column(
        String(50),
        nullable=False,
    )
    
    name: Mapped[str] = Column(
        String(255),
        nullable=False,
    )
    
    category: Mapped[str] = Column(
        Enum(
            "quran", "hadith", "fiqh", "arabic", "general", "tahfidz",
            name="subject_category"
        ),
        nullable=False,
    )
    
    credit_hours: Mapped[int] = Column(
        Integer,
        default=2,
        nullable=False,
    )
    
    description: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    is_active: Mapped[bool] = Column(
        Boolean,
        default=True,
        nullable=False,
    )
    
    # Relationships
    pesantren = relationship("Pesantren", back_populates="subjects")
    teaching_assignments = relationship("TeachingAssignment", back_populates="subject")
    
    def __repr__(self) -> str:
        return f"<Subject(id={self.id}, name={self.name})>"


class SantriClass(BaseModel, SoftDeleteMixin):
    """Santri-Class enrollment (Many-to-Many)."""
    
    __tablename__ = "santri_class"
    
    santri_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("santri.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    class_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("classes.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    academic_year_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("academic_years.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    enrollment_date: Mapped[str] = Column(
        Date,
        nullable=False,
    )
    
    is_active: Mapped[bool] = Column(
        Boolean,
        default=True,
        nullable=False,
    )
    
    notes: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    # Relationships
    santri = relationship("Santri", back_populates="santri_classes")
    class_ = relationship("Class", back_populates="santri_classes")
    academic_year = relationship("AcademicYear", back_populates="santri_classes")
    
    def __repr__(self) -> str:
        return f"<SantriClass(santri_id={self.santri_id}, class_id={self.class_id})>"


class TeachingAssignment(BaseModel, SoftDeleteMixin):
    """Teaching assignment (Jadwal Mengajar)."""
    
    __tablename__ = "teaching_assignments"
    
    ustadz_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("ustadz.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    class_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("classes.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    subject_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("subjects.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    academic_year_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("academic_years.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    # Schedule
    schedule_day: Mapped[str] = Column(
        Enum(
            "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu", "Minggu",
            name="day_of_week"
        ),
        nullable=False,
    )
    
    schedule_time_start: Mapped[str] = Column(
        Time,
        nullable=False,
    )
    
    schedule_time_end: Mapped[str] = Column(
        Time,
        nullable=False,
    )
    
    room: Mapped[str] = Column(
        String(50),
        nullable=True,
    )
    
    is_active: Mapped[bool] = Column(
        Boolean,
        default=True,
        nullable=False,
    )
    
    # Relationships
    ustadz = relationship("Ustadz", back_populates="teaching_assignments")
    class_ = relationship("Class", back_populates="teaching_assignments")
    subject = relationship("Subject", back_populates="teaching_assignments")
    academic_year = relationship("AcademicYear", back_populates="teaching_assignments")
    attendances = relationship("Attendance", back_populates="teaching_assignment")
    grades = relationship("Grade", back_populates="teaching_assignment")
    
    def __repr__(self) -> str:
        return f"<TeachingAssignment(id={self.id}, ustadz_id={self.ustadz_id})>"
    
    @property
    def schedule_display(self) -> str:
        """Get schedule display string."""
        return f"{self.schedule_day}, {self.schedule_time_start} - {self.schedule_time_end}"


class Attendance(BaseModel, SoftDeleteMixin):
    """Attendance/Absensi model."""
    
    __tablename__ = "attendance"
    
    teaching_assignment_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("teaching_assignments.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    santri_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("santri.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    date: Mapped[str] = Column(
        Date,
        nullable=False,
    )
    
    status: Mapped[str] = Column(
        Enum(
            "present", "absent", "sick", "permission", "late",
            name="attendance_status"
        ),
        default="present",
        nullable=False,
    )
    
    notes: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    # Who recorded this attendance
    recorded_by: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
    )
    
    # Relationships
    teaching_assignment = relationship("TeachingAssignment", back_populates="attendances")
    santri = relationship("Santri", back_populates="attendances")
    recorded_by_user = relationship("User")
    
    def __repr__(self) -> str:
        return f"<Attendance(id={self.id}, santri_id={self.santri_id}, date={self.date})>"


class Grade(BaseModel, SoftDeleteMixin):
    """Grade/Nilai model."""
    
    __tablename__ = "grades"
    
    santri_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("santri.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    teaching_assignment_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("teaching_assignments.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    grade_type: Mapped[str] = Column(
        Enum(
            "daily", "midterm", "final", "practice",
            name="grade_type"
        ),
        nullable=False,
    )
    
    score: Mapped[float] = Column(
        String(10),  # Using string to support various grade formats
        nullable=False,
    )
    
    max_score: Mapped[float] = Column(
        String(10),
        default="100",
        nullable=False,
    )
    
    date: Mapped[str] = Column(
        Date,
        nullable=False,
    )
    
    description: Mapped[str] = Column(
        Text,
        nullable=True,
    )  # e.g., "Ulangan Harian 1"
    
    notes: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    # Who recorded this grade
    recorded_by: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
    )
    
    # Relationships
    santri = relationship("Santri", back_populates="grades")
    teaching_assignment = relationship("TeachingAssignment", back_populates="grades")
    recorded_by_user = relationship("User")
    
    def __repr__(self) -> str:
        return f"<Grade(id={self.id}, santri_id={self.santri_id}, score={self.score})>"
    
    @property
    def score_numeric(self) -> float:
        """Get score as float."""
        try:
            return float(self.score)
        except (ValueError, TypeError):
            return 0.0
    
    @property
    def max_score_numeric(self) -> float:
        """Get max score as float."""
        try:
            return float(self.max_score)
        except (ValueError, TypeError):
            return 100.0
    
    @property
    def percentage(self) -> float:
        """Get score as percentage."""
        if self.max_score_numeric == 0:
            return 0.0
        return (self.score_numeric / self.max_score_numeric) * 100
