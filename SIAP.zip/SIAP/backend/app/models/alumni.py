"""
Alumni model.
"""

from sqlalchemy import Column, Enum, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship, Mapped

from app.models.base import BaseModel, SoftDeleteMixin


class Alumni(BaseModel, SoftDeleteMixin):
    """Alumni model."""
    
    __tablename__ = "alumni"
    
    santri_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("santri.id", ondelete="CASCADE"),
        unique=True,
        nullable=False,
    )
    
    graduation_year: Mapped[int] = Column(
        Integer,
        nullable=False,
    )
    
    last_class: Mapped[str] = Column(
        String(100),
        nullable=True,
    )
    
    # Current status
    current_status: Mapped[str] = Column(
        Enum(
            "studying", "working", "entrepreneur", "other", "unemployed",
            name="alumni_status"
        ),
        nullable=False,
    )
    
    # If studying
    institution_name: Mapped[str] = Column(
        String(255),
        nullable=True,
    )
    
    major: Mapped[str] = Column(
        String(255),
        nullable=True,
    )
    
    degree: Mapped[str] = Column(
        String(100),
        nullable=True,
    )  # S1, S2, S3
    
    # If working
    job_title: Mapped[str] = Column(
        String(255),
        nullable=True,
    )
    
    company_name: Mapped[str] = Column(
        String(255),
        nullable=True,
    )
    
    company_address: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    # If entrepreneur
    business_name: Mapped[str] = Column(
        String(255),
        nullable=True,
    )
    
    business_type: Mapped[str] = Column(
        String(255),
        nullable=True,
    )
    
    # Contact info
    phone: Mapped[str] = Column(
        String(20),
        nullable=True,
    )
    
    email: Mapped[str] = Column(
        String(100),
        nullable=True,
    )
    
    address: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    # Achievement
    achievements: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    # Relationships
    santri = relationship("Santri", back_populates="alumni")
    
    def __repr__(self) -> str:
        return f"<Alumni(id={self.id}, santri_id={self.santri_id}, year={self.graduation_year})>"
    
    @property
    def full_name(self) -> str:
        """Get full name from santri."""
        return self.santri.full_name if self.santri else "-"
    
    @property
    def nis(self) -> str:
        """Get NIS from santri."""
        return self.santri.nis if self.santri else "-"
