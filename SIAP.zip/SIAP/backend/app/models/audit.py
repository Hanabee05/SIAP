"""
Audit log model for activity tracking.
"""

from sqlalchemy import Column, Enum, ForeignKey, String, Text, JSON
from sqlalchemy.dialects.postgresql import INET
from sqlalchemy.orm import relationship, Mapped

from app.models.base import BaseModel


class AuditLog(BaseModel):
    """Audit log for tracking user activities."""
    
    __tablename__ = "audit_logs"
    
    user_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
    )
    
    pesantren_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("pesantren.id", ondelete="CASCADE"),
        nullable=True,
    )
    
    # Action details
    action: Mapped[str] = Column(
        String(100),
        nullable=False,
    )  # CREATE, UPDATE, DELETE, VIEW, LOGIN, LOGOUT, etc
    
    resource_type: Mapped[str] = Column(
        String(50),
        nullable=False,
    )  # santri, payment, grade, etc
    
    resource_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        nullable=True,
    )  # ID of the resource
    
    # Changes (for UPDATE operations)
    old_values: Mapped[dict] = Column(
        JSON,
        nullable=True,
    )
    
    new_values: Mapped[dict] = Column(
        JSON,
        nullable=True,
    )
    
    # Context
    ip_address: Mapped[str] = Column(
        INET,
        nullable=True,
    )
    
    user_agent: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    request_method: Mapped[str] = Column(
        String(10),
        nullable=True,
    )  # GET, POST, PUT, DELETE
    
    request_path: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    # Relationships
    user = relationship("User", back_populates="audit_logs")
    pesantren = relationship("Pesantren", back_populates="audit_logs")
    
    def __repr__(self) -> str:
        return f"<AuditLog(id={self.id}, action={self.action}, resource={self.resource_type})>"
    
    @property
    def display_action(self) -> str:
        """Get display-friendly action name."""
        action_map = {
            "CREATE": "Membuat",
            "UPDATE": "Mengubah",
            "DELETE": "Menghapus",
            "VIEW": "Melihat",
            "LOGIN": "Login",
            "LOGOUT": "Logout",
        }
        return action_map.get(self.action, self.action)
    
    @property
    def display_resource(self) -> str:
        """Get display-friendly resource name."""
        resource_map = {
            "santri": "Santri",
            "payment": "Pembayaran",
            "grade": "Nilai",
            "attendance": "Absensi",
            "user": "Pengguna",
            "class": "Kelas",
            "subject": "Mata Pelajaran",
            "ustadz": "Ustadz",
            "staff": "Staf",
            "alumni": "Alumni",
        }
        return resource_map.get(self.resource_type, self.resource_type)
