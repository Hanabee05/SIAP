"""
Finance models for SIAP.
"""

from sqlalchemy import Column, Date, Enum, ForeignKey, Integer, String, Text, Boolean, Numeric
from sqlalchemy.orm import relationship, Mapped

from app.models.base import BaseModel, SoftDeleteMixin


class PaymentType(BaseModel, SoftDeleteMixin):
    """Payment type/Jenis Pembayaran model."""
    
    __tablename__ = "payment_types"
    
    pesantren_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("pesantren.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    name: Mapped[str] = Column(
        String(255),
        nullable=False,
    )
    
    type: Mapped[str] = Column(
        Enum(
            "spp", "dormitory", "development", "other",
            name="payment_type_category"
        ),
        nullable=False,
        index=True,
    )
    
    amount: Mapped[float] = Column(
        Numeric(12, 2),
        nullable=False,
    )
    
    frequency: Mapped[str] = Column(
        Enum(
            "monthly", "yearly", "one_time", "semester",
            name="payment_frequency"
        ),
        nullable=False,
    )
    
    description: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    is_active: Mapped[bool] = Column(
        Boolean,
        default=True,
        nullable=False,
        index=True,
    )
    
    # Relationships
    pesantren = relationship("Pesantren", back_populates="payment_types")
    payments = relationship("Payment", back_populates="payment_type")
    
    def __repr__(self) -> str:
        return f"<PaymentType(id={self.id}, name={self.name}, type={self.type})>"


class Payment(BaseModel, SoftDeleteMixin):
    """Payment/Pembayaran model."""
    
    __tablename__ = "payments"
    
    santri_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("santri.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    payment_type_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("payment_types.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    # Payment details
    amount: Mapped[float] = Column(
        Numeric(12, 2),
        nullable=False,
    )
    
    payment_date: Mapped[str] = Column(
        Date,
        nullable=False,
    )
    
    due_date: Mapped[str] = Column(
        Date,
        nullable=False,
    )
    
    # For periodic payments (SPP)
    period_month: Mapped[int] = Column(
        Integer,
        nullable=True,
    )  # 1-12
    
    period_year: Mapped[int] = Column(
        Integer,
        nullable=True,
    )  # Year
    
    # Status
    status: Mapped[str] = Column(
        Enum(
            "pending", "paid", "overdue", "cancelled", "partial",
            name="payment_status"
        ),
        default="pending",
        nullable=False,
        index=True,
    )
    
    payment_method: Mapped[str] = Column(
        String(50),
        nullable=True,
    )  # cash, transfer, etc
    
    # Reference
    reference_number: Mapped[str] = Column(
        String(100),
        nullable=True,
    )  # Transfer reference number
    
    proof_image_url: Mapped[str] = Column(
        Text,
        nullable=True,
    )  # Proof of payment image
    
    # Notes
    notes: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    # Who recorded this payment
    recorded_by: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
    )
    
    # Relationships
    santri = relationship("Santri", back_populates="payments")
    payment_type = relationship("PaymentType", back_populates="payments")
    recorded_by_user = relationship("User")
    
    def __repr__(self) -> str:
        return f"<Payment(id={self.id}, santri_id={self.santri_id}, amount={self.amount})>"
    
    @property
    def is_overdue(self) -> bool:
        """Check if payment is overdue."""
        from datetime import date
        return self.status == "pending" and self.due_date < date.today()
    
    @property
    def period_display(self) -> str:
        """Get period display string."""
        if self.period_month and self.period_year:
            months = [
                "", "Januari", "Februari", "Maret", "April", "Mei", "Juni",
                "Juli", "Agustus", "September", "Oktober", "November", "Desember"
            ]
            return f"{months[self.period_month]} {self.period_year}"
        return "-"
