"""
Pesantren (Institution) model.
"""

from sqlalchemy import Column, Date, String, Text, Boolean
from sqlalchemy.orm import relationship, Mapped

from app.models.base import BaseModel, SoftDeleteMixin


class Pesantren(BaseModel, SoftDeleteMixin):
    """Pesantren/Institution model."""
    
    __tablename__ = "pesantren"
    
    # Basic info
    name: Mapped[str] = Column(
        String(255),
        nullable=False,
    )
    
    slug: Mapped[str] = Column(
        String(100),
        unique=True,
        nullable=False,
    )
    
    description: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    # Contact info
    address: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    phone: Mapped[str] = Column(
        String(20),
        nullable=True,
    )
    
    email: Mapped[str] = Column(
        String(100),
        nullable=True,
    )
    
    website: Mapped[str] = Column(
        String(255),
        nullable=True,
    )
    
    # Branding
    logo_url: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    photo_url: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    # Foundation info
    foundation_date: Mapped[str] = Column(
        Date,
        nullable=True,
    )
    
    foundation_name: Mapped[str] = Column(
        String(255),
        nullable=True,
    )
    
    # Accreditation
    accreditation_level: Mapped[str] = Column(
        String(50),
        nullable=True,
    )
    
    # Tax ID
    npwp: Mapped[str] = Column(
        String(50),
        nullable=True,
    )
    
    # Status
    is_active: Mapped[bool] = Column(
        Boolean,
        default=True,
        nullable=False,
    )
    
    # Relationships
    users = relationship("User", back_populates="pesantren")
    santri = relationship("Santri", back_populates="pesantren")
    ustadz = relationship("Ustadz", back_populates="pesantren")
    classes = relationship("Class", back_populates="pesantren")
    subjects = relationship("Subject", back_populates="pesantren")
    payment_types = relationship("PaymentType", back_populates="pesantren")
    academic_years = relationship("AcademicYear", back_populates="pesantren")
    staff = relationship("Staff", back_populates="pesantren")
    audit_logs = relationship("AuditLog", back_populates="pesantren")
    
    def __repr__(self) -> str:
        return f"<Pesantren(id={self.id}, name={self.name})>"
