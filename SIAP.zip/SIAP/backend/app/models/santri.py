"""
Santri (Student) model.
"""

from sqlalchemy import Column, Date, Enum, ForeignKey, String, Text, Boolean
from sqlalchemy.orm import relationship, Mapped

from app.models.base import BaseModel, SoftDeleteMixin


class Santri(BaseModel, SoftDeleteMixin):
    """Santri (Student) model."""
    
    __tablename__ = "santri"
    
    # User account (optional)
    user_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        unique=True,
        nullable=True,
    )
    
    # Foreign key to pesantren
    pesantren_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("pesantren.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    # Student ID (Nomor Induk Santri)
    nis: Mapped[str] = Column(
        String(50),
        unique=True,
        nullable=False,
        index=True,
    )
    
    # Personal info
    full_name: Mapped[str] = Column(
        String(255),
        nullable=False,
    )
    
    birth_date: Mapped[str] = Column(
        Date,
        nullable=True,
    )
    
    birth_place: Mapped[str] = Column(
        String(100),
        nullable=True,
    )
    
    gender: Mapped[str] = Column(
        Enum("L", "P", name="gender_type"),
        nullable=True,
    )
    
    address: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    phone: Mapped[str] = Column(
        String(20),
        nullable=True,
    )
    
    email: Mapped[str] = Column(
        String(100),
        nullable=True,
    )
    
    # Guardian info
    guardian_name: Mapped[str] = Column(
        String(255),
        nullable=True,
    )
    
    guardian_phone: Mapped[str] = Column(
        String(20),
        nullable=True,
    )
    
    guardian_relation: Mapped[str] = Column(
        String(50),
        nullable=True,
    )
    
    guardian_address: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    # Academic info
    enrollment_date: Mapped[str] = Column(
        Date,
        nullable=False,
    )
    
    graduation_date: Mapped[str] = Column(
        Date,
        nullable=True,
    )
    
    status: Mapped[str] = Column(
        Enum("active", "graduated", "dropped", "pending", name="santri_status"),
        default="active",
        nullable=False,
        index=True,
    )
    
    current_class_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("classes.id", ondelete="SET NULL"),
        nullable=True,
    )
    
    # Previous education
    previous_school: Mapped[str] = Column(
        String(255),
        nullable=True,
    )
    
    # Special needs
    special_needs: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    notes: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    # Photo
    photo_url: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    # Relationships
    user = relationship("User", back_populates="santri")
    pesantren = relationship("Pesantren", back_populates="santri")
    current_class = relationship("Class")
    santri_classes = relationship("SantriClass", back_populates="santri")
    attendances = relationship("Attendance", back_populates="santri")
    grades = relationship("Grade", back_populates="santri")
    payments = relationship("Payment", back_populates="santri")
    alumni = relationship("Alumni", back_populates="santri", uselist=False)
    
    def __repr__(self) -> str:
        return f"<Santri(id={self.id}, nis={self.nis}, name={self.full_name})>"
    
    @property
    def is_active(self) -> bool:
        """Check if santri is currently active."""
        return self.status == "active"
    
    @property
    def is_graduated(self) -> bool:
        """Check if santri has graduated."""
        return self.status == "graduated"
