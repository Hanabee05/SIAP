"""
Staff (Non-teaching) model.
"""

from sqlalchemy import Column, Date, Enum, ForeignKey, String, Text, Boolean
from sqlalchemy.orm import relationship, Mapped

from app.models.base import BaseModel, SoftDeleteMixin


class Staff(BaseModel, SoftDeleteMixin):
    """Staff (Non-teaching) model."""
    
    __tablename__ = "staff"
    
    pesantren_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("pesantren.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    full_name: Mapped[str] = Column(
        String(255),
        nullable=False,
    )
    
    # Personal info
    birth_date: Mapped[str] = Column(
        Date,
        nullable=True,
    )
    
    birth_place: Mapped[str] = Column(
        String(100),
        nullable=True,
    )
    
    gender: Mapped[str] = Column(
        Enum("L", "P", name="gender_type"),
        nullable=True,
    )
    
    address: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    phone: Mapped[str] = Column(
        String(20),
        nullable=True,
    )
    
    email: Mapped[str] = Column(
        String(100),
        nullable=True,
    )
    
    # Employment
    position: Mapped[str] = Column(
        String(255),
        nullable=False,
    )
    
    department: Mapped[str] = Column(
        String(100),
        nullable=True,
    )  # Administration, Finance, Counseling, etc
    
    employment_status: Mapped[str] = Column(
        Enum(
            "permanent", "contract", "internship", "freelance",
            name="employment_status"
        ),
        default="permanent",
        nullable=False,
    )
    
    hire_date: Mapped[str] = Column(
        Date,
        nullable=True,
    )
    
    is_active: Mapped[bool] = Column(
        Boolean,
        default=True,
        nullable=False,
        index=True,
    )
    
    # Additional info
    bio: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    photo_url: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    notes: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    # Relationships
    pesantren = relationship("Pesantren", back_populates="staff")
    
    def __repr__(self) -> str:
        return f"<Staff(id={self.id}, name={self.full_name}, position={self.position})>"
