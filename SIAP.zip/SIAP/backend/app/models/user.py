"""
User model for authentication and authorization.
"""

from datetime import datetime
from typing import Optional

from sqlalchemy import Boolean, Column, DateTime, Enum, ForeignKey, String, Text
from sqlalchemy.orm import relationship, Mapped

from app.models.base import BaseModel, SoftDeleteMixin
from app.core.security import ROLE_PERMISSIONS


class User(BaseModel, SoftDeleteMixin):
    """User model for authentication."""
    
    __tablename__ = "users"
    
    # Foreign key to pesantren
    pesantren_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("pesantren.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    # Authentication
    email: Mapped[str] = Column(
        String(100),
        unique=True,
        nullable=False,
        index=True,
    )
    
    password_hash: Mapped[str] = Column(
        String(255),
        nullable=False,
    )
    
    # Role
    role: Mapped[str] = Column(
        Enum("super_admin", "admin_pesantren", "ustadz", "santri", name="user_role"),
        nullable=False,
        index=True,
    )
    
    # Status
    is_active: Mapped[bool] = Column(
        Boolean,
        default=True,
        nullable=False,
    )
    
    is_verified: Mapped[bool] = Column(
        Boolean,
        default=False,
        nullable=False,
    )
    
    # Timestamps
    last_login: Mapped[Optional[datetime]] = Column(
        DateTime(timezone=True),
        nullable=True,
    )
    
    last_login_ip: Mapped[Optional[str]] = Column(
        String(45),
        nullable=True,
    )
    
    # Relationships
    pesantren = relationship("Pesantren", back_populates="users")
    santri = relationship("Santri", back_populates="user", uselist=False)
    ustadz = relationship("Ustadz", back_populates="user", uselist=False)
    audit_logs = relationship("AuditLog", back_populates="user")
    
    def __repr__(self) -> str:
        return f"<User(id={self.id}, email={self.email}, role={self.role})>"
    
    @property
    def permissions(self) -> list:
        """Get permissions for this user's role."""
        return ROLE_PERMISSIONS.get(self.role, [])
    
    def has_permission(self, permission: str) -> bool:
        """Check if user has specific permission."""
        from app.core.security import has_permission
        return has_permission(self.role, permission)
    
    def has_any_permission(self, permissions: list) -> bool:
        """Check if user has any of the given permissions."""
        return any(self.has_permission(p) for p in permissions)
    
    def has_all_permissions(self, permissions: list) -> bool:
        """Check if user has all of the given permissions."""
        return all(self.has_permission(p) for p in permissions)
    
    @property
    def display_name(self) -> str:
        """Get display name for the user."""
        if self.santri:
            return self.santri.full_name
        elif self.ustadz:
            return self.ustadz.full_name
        return self.email
    
    @property
    def profile(self):
        """Get user profile based on role."""
        if self.role == "santri" and self.santri:
            return self.santri
        elif self.role == "ustadz" and self.ustadz:
            return self.ustadz
        return None
