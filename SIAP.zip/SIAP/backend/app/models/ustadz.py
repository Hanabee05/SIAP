"""
Ustadz (Teacher) model.
"""

from sqlalchemy import Column, Date, Enum, ForeignKey, String, Text, Boolean
from sqlalchemy.orm import relationship, Mapped

from app.models.base import BaseModel, SoftDeleteMixin


class Ustadz(BaseModel, SoftDeleteMixin):
    """Ustadz (Teacher) model."""
    
    __tablename__ = "ustadz"
    
    # User account (optional)
    user_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        unique=True,
        nullable=True,
    )
    
    # Foreign key to pesantren
    pesantren_id: Mapped[str] = Column(
        UUID(as_uuid=True),
        ForeignKey("pesantren.id", ondelete="CASCADE"),
        nullable=False,
    )
    
    # Employee ID (Nomor Induk Pegawai)
    nip: Mapped[str] = Column(
        String(50),
        unique=True,
        nullable=True,
    )
    
    # Personal info
    full_name: Mapped[str] = Column(
        String(255),
        nullable=False,
    )
    
    birth_date: Mapped[str] = Column(
        Date,
        nullable=True,
    )
    
    birth_place: Mapped[str] = Column(
        String(100),
        nullable=True,
    )
    
    gender: Mapped[str] = Column(
        Enum("L", "P", name="gender_type"),
        nullable=True,
    )
    
    address: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    phone: Mapped[str] = Column(
        String(20),
        nullable=True,
    )
    
    email: Mapped[str] = Column(
        String(100),
        nullable=True,
    )
    
    # Professional info
    specialization: Mapped[str] = Column(
        String(255),
        nullable=True,
    )
    
    education: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    experience: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    certification: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    # Employment
    employment_status: Mapped[str] = Column(
        Enum("permanent", "contract", "internship", "freelance", name="employment_status"),
        default="permanent",
        nullable=False,
    )
    
    hire_date: Mapped[str] = Column(
        Date,
        nullable=True,
    )
    
    is_active: Mapped[bool] = Column(
        Boolean,
        default=True,
        nullable=False,
        index=True,
    )
    
    # Additional info
    photo_url: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    notes: Mapped[str] = Column(
        Text,
        nullable=True,
    )
    
    # Relationships
    user = relationship("User", back_populates="ustadz")
    pesantren = relationship("Pesantren", back_populates="ustadz")
    teaching_assignments = relationship("TeachingAssignment", back_populates="ustadz")
    classes_as_teacher = relationship("Class", back_populates="class_teacher")
    
    def __repr__(self) -> str:
        return f"<Ustadz(id={self.id}, name={self.full_name})>"
