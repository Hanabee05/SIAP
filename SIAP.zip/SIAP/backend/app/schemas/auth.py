"""
Authentication schemas.
"""

from typing import Optional
from pydantic import BaseModel, EmailStr, Field


class LoginRequest(BaseModel):
    """Login request schema."""
    
    email: EmailStr = Field(description="User email")
    password: str = Field(min_length=6, description="User password")


class TokenResponse(BaseModel):
    """Token response schema."""
    
    access_token: str = Field(description="JWT access token")
    refresh_token: str = Field(description="JWT refresh token")
    token_type: str = Field(default="bearer", description="Token type")
    expires_in: int = Field(description="Token expiry in seconds")


class LoginResponse(BaseModel):
    """Login response schema."""
    
    token: TokenResponse = Field(description="Token information")
    user: dict = Field(description="User information")


class RefreshTokenRequest(BaseModel):
    """Refresh token request schema."""
    
    refresh_token: str = Field(description="JWT refresh token")


class ChangePasswordRequest(BaseModel):
    """Change password request schema."""
    
    current_password: str = Field(min_length=6, description="Current password")
    new_password: str = Field(min_length=6, description="New password")
    confirm_password: str = Field(min_length=6, description="Confirm new password")
    
    def validate_passwords_match(self) -> bool:
        """Validate that new password and confirm password match."""
        return self.new_password == self.confirm_password


class PasswordResetRequest(BaseModel):
    """Password reset request schema."""
    
    email: EmailStr = Field(description="User email")


class PasswordResetConfirmRequest(BaseModel):
    """Password reset confirmation request schema."""
    
    token: str = Field(description="Password reset token")
    new_password: str = Field(min_length=6, description="New password")
    confirm_password: str = Field(min_length=6, description="Confirm new password")
    
    def validate_passwords_match(self) -> bool:
        """Validate that passwords match."""
        return self.new_password == self.confirm_password


class TokenPayload(BaseModel):
    """Token payload schema."""
    
    sub: str = Field(description="Subject (user ID)")
    exp: int = Field(description="Expiry timestamp")
    iat: int = Field(description="Issued at timestamp")
    type: str = Field(description="Token type (access/refresh)")
    role: Optional[str] = Field(default=None, description="User role")
    pesantren_id: Optional[str] = Field(default=None, description="Pesantren ID")
