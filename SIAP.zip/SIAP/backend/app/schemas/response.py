"""
Standard response schemas for API consistency.
"""

from typing import Any, Dict, Generic, List, Optional, TypeVar, Union
from pydantic import BaseModel, Field


T = TypeVar("T")


class BaseResponse(BaseModel):
    """Base response schema."""
    
    success: bool = Field(default=True, description="Request success status")
    message: str = Field(default="Success", description="Response message")
    data: Optional[Any] = Field(default=None, description="Response data")
    
    class Config:
        json_encoders = {
            # Custom JSON encoders if needed
        }


class PaginatedMeta(BaseModel):
    """Pagination metadata."""
    
    page: int = Field(description="Current page number")
    per_page: int = Field(description="Items per page")
    total: int = Field(description="Total items")
    total_pages: int = Field(description="Total pages")
    has_next: bool = Field(description="Has next page")
    has_prev: bool = Field(description="Has previous page")


class PaginatedResponse(BaseResponse, Generic[T]):
    """Paginated response schema."""
    
    data: List[T] = Field(default_factory=list, description="List of items")
    meta: PaginatedMeta = Field(description="Pagination metadata")


class ErrorResponse(BaseResponse):
    """Error response schema."""
    
    success: bool = Field(default=False, description="Request success status")
    message: str = Field(default="Error", description="Error message")
    errors: Optional[Dict[str, List[str]]] = Field(
        default=None, description="Field-specific errors"
    )
    error_code: Optional[str] = Field(default=None, description="Error code")


class ValidationErrorDetail(BaseModel):
    """Validation error detail."""
    
    field: str = Field(description="Field name")
    message: str = Field(description="Error message")
    value: Optional[Any] = Field(default=None, description="Field value")


class ValidationErrorResponse(ErrorResponse):
    """Validation error response."""
    
    errors: Dict[str, List[str]] = Field(
        default_factory=dict, description="Field validation errors"
    )


# Common response schemas
class MessageResponse(BaseResponse):
    """Simple message response."""
    
    data: Optional[str] = Field(default=None, description="Optional data")


class IDResponse(BaseResponse):
    """Response with ID."""
    
    data: Dict[str, str] = Field(description="Response containing ID")


class CountResponse(BaseResponse):
    """Response with count."""
    
    data: int = Field(description="Count value")
