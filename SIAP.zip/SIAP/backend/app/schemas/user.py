"""
User schemas.
"""

from datetime import datetime
from typing import Optional
from pydantic import BaseModel, EmailStr, Field


class UserBase(BaseModel):
    """Base user schema."""
    
    email: EmailStr = Field(description="User email")
    role: str = Field(
        pattern="^(super_admin|admin_pesantren|ustadz|santri)$",
        description="User role"
    )
    is_active: bool = Field(default=True, description="Is user active")
    is_verified: bool = Field(default=False, description="Is email verified")
    
    class Config:
        from_attributes = True


class UserCreate(UserBase):
    """User creation schema."""
    
    password: str = Field(min_length=6, description="User password")
    pesantren_id: str = Field(description="Pesantren ID")


class UserUpdate(BaseModel):
    """User update schema."""
    
    email: Optional[EmailStr] = Field(default=None, description="User email")
    role: Optional[str] = Field(
        default=None,
        pattern="^(super_admin|admin_pesantren|ustadz|santri)$",
        description="User role"
    )
    is_active: Optional[bool] = Field(default=None, description="Is user active")
    is_verified: Optional[bool] = Field(default=None, description="Is email verified")
    
    class Config:
        from_attributes = True


class UserResponse(UserBase):
    """User response schema."""
    
    id: str = Field(description="User ID")
    pesantren_id: str = Field(description="Pesantren ID")
    last_login: Optional[datetime] = Field(default=None, description="Last login time")
    last_login_ip: Optional[str] = Field(default=None, description="Last login IP")
    created_at: datetime = Field(description="Creation time")
    updated_at: datetime = Field(description="Last update time")
    
    # Profile info (populated based on role)
    profile: Optional[dict] = Field(default=None, description="User profile info")
    
    class Config:
        from_attributes = True


class UserListResponse(BaseModel):
    """User list response schema."""
    
    users: list[UserResponse] = Field(default_factory=list, description="List of users")
    total: int = Field(description="Total users")


class UserProfileResponse(BaseModel):
    """User profile response schema."""
    
    id: str = Field(description="User ID")
    email: EmailStr = Field(description="User email")
    role: str = Field(description="User role")
    pesantren_id: str = Field(description="Pesantren ID")
    is_active: bool = Field(description="Is user active")
    is_verified: bool = Field(description="Is email verified")
    last_login: Optional[datetime] = Field(default=None, description="Last login time")
    created_at: datetime = Field(description="Creation time")
    
    # Role-specific profile
    profile: dict = Field(description="Role-specific profile data")
    permissions: list[str] = Field(description="User permissions")
    
    class Config:
        from_attributes = True
