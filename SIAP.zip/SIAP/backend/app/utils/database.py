"""
Database utilities and session management.
"""

from contextlib import asynccontextmanager
from typing import AsyncGenerator, Optional

from sqlalchemy import MetaData
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from sqlalchemy.orm import DeclarativeBase
from sqlalchemy.sql import expression
from sqlalchemy import Column, DateTime, func

from app.config import settings


class Base(DeclarativeBase):
    """Base class for all database models."""
    
    # Soft delete column (will be added to all models)
    deleted_at = Column(DateTime(timezone=True), nullable=True, default=None)
    
    # Timestamp columns (will be overridden in models if needed)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


# Database engine
engine = create_async_engine(
    settings.DATABASE_URL,
    echo=settings.DEBUG,
    pool_size=settings.DATABASE_POOL_SIZE,
    max_overflow=settings.DATABASE_MAX_OVERFLOW,
    pool_timeout=settings.DATABASE_POOL_TIMEOUT,
    pool_pre_ping=True,  # Verify connections before use
)

# Session factory
AsyncSessionLocal = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False,
    autoflush=False,
)


@asynccontextmanager
async def get_db_session() -> AsyncGenerator[AsyncSession, None]:
    """
    Get database session with automatic cleanup.
    
    Usage:
        async with get_db_session() as session:
            result = await session.execute(query)
    """
    async with AsyncSessionLocal() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    """
    Dependency for FastAPI to get database session.
    
    Usage:
        @app.get("/items/")
        async def read_items(session: AsyncSession = Depends(get_db)):
            ...
    """
    async with get_db_session() as session:
        yield session


async def init_db():
    """Initialize database by creating all tables."""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


async def close_db():
    """Close database connections."""
    await engine.dispose()


# Soft delete query mixin
class SoftDeleteMixin:
    """Mixin to add soft delete functionality to models."""
    
    @classmethod
    def query_active(cls):
        """Query builder that excludes soft-deleted records."""
        return cls.query.filter(cls.deleted_at.is_(None))
    
    def soft_delete(self):
        """Soft delete this record."""
        self.deleted_at = func.now()
    
    def restore(self):
        """Restore this soft-deleted record."""
        self.deleted_at = None


# Audit logging helper
async def log_audit(
    session: AsyncSession,
    action: str,
    resource_type: str,
    resource_id: Optional[str] = None,
    old_values: Optional[dict] = None,
    new_values: Optional[dict] = None,
    user_id: Optional[str] = None,
    pesantren_id: Optional[str] = None,
):
    """
    Log audit trail for actions.
    
    Args:
        session: Database session
        action: Action performed (CREATE, UPDATE, DELETE, VIEW)
        resource_type: Type of resource (santri, payment, etc)
        resource_id: ID of the resource
        old_values: Previous values (for UPDATE/DELETE)
        new_values: New values (for CREATE/UPDATE)
        user_id: ID of user performing the action
        pesantren_id: ID of the pesantren
    """
    from app.models.audit import AuditLog
    
    audit_log = AuditLog(
        user_id=user_id,
        pesantren_id=pesantren_id,
        action=action,
        resource_type=resource_type,
        resource_id=resource_id,
        old_values=old_values,
        new_values=new_values,
    )
    
    session.add(audit_log)
    await session.flush()
