-- SIAP - Sistem Induk Administrasi Pesantren
-- Database Schema (PostgreSQL 15+)
-- Generated: January 2024

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enable PostGIS untuk lokasi (optional)
-- CREATE EXTENSION IF NOT EXISTS postgis;

-- ============================================================================
-- ENUM TYPES
-- ============================================================================

CREATE TYPE user_role AS ENUM ('super_admin', 'admin_pesantren', 'ustadz', 'santri');
CREATE TYPE gender_type AS ENUM ('L', 'P');
CREATE TYPE santri_status AS ENUM ('active', 'graduated', 'dropped', 'pending');
CREATE TYPE attendance_status AS ENUM ('present', 'absent', 'sick', 'permission', 'late');
CREATE TYPE grade_type AS ENUM ('daily', 'midterm', 'final', 'practice');
CREATE TYPE payment_type_category AS ENUM ('spp', 'dormitory', 'development', 'other');
CREATE_TYPE payment_frequency AS ENUM ('monthly', 'yearly', 'one_time', 'semester');
CREATE TYPE payment_status AS ENUM ('pending', 'paid', 'overdue', 'cancelled', 'partial');
CREATE TYPE alumni_status AS ENUM ('studying', 'working', 'entrepreneur', 'other', 'unemployed');
CREATE TYPE employment_status AS ENUM ('permanent', 'contract', 'internship', 'freelance');
CREATE TYPE subject_category AS ENUM ('quran', 'hadith', 'fiqh', 'arabic', 'general', 'tahfidz');
CREATE TYPE day_of_week AS ENUM ('Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu');

-- ============================================================================
-- CORE TABLES
-- ============================================================================

-- Pesantren/Institution table
CREATE TABLE pesantren (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    address TEXT,
    phone VARCHAR(20),
    email VARCHAR(100),
    website VARCHAR(255),
    logo_url TEXT,
    photo_url TEXT,
    foundation_date DATE,
    foundation_name VARCHAR(255),
    accreditation_level VARCHAR(50),
    npwp VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE DEFAULT NULL
);

-- Users table (authentication)
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pesantren_id UUID NOT NULL REFERENCES pesantren(id) ON DELETE CASCADE,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role user_role NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_verified BOOLEAN DEFAULT FALSE,
    last_login TIMESTAMP WITH TIME ZONE,
    last_login_ip INET,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    -- Index
    INDEX idx_users_pesantren_id (pesantren_id),
    INDEX idx_users_email (email),
    INDEX idx_users_role (role)
);

-- ============================================================================
-- ACADEMIC TABLES
-- ============================================================================

-- Academic year
CREATE TABLE academic_years (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pesantren_id UUID NOT NULL REFERENCES pesantren(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL, -- e.g., "2024/2025"
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    is_current BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE (pesantren_id, name),
    INDEX idx_academic_years_pesantren (pesantren_id)
);

-- Class/Kelas
CREATE TABLE classes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pesantren_id UUID NOT NULL REFERENCES pesantren(id) ON DELETE CASCADE,
    academic_year_id UUID NOT NULL REFERENCES academic_years(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL, -- e.g., "1A", "2B"
    level VARCHAR(50) NOT NULL, -- e.g., "SMP", "SMA", "Tahfidz"
    class_teacher_id UUID, -- References ustadz(id)
    capacity INTEGER DEFAULT 30,
    description TEXT,
    room_number VARCHAR(20),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    
    INDEX idx_classes_pesantren (pesantren_id),
    INDEX idx_classes_academic_year (academic_year_id),
    INDEX idx_classes_teacher (class_teacher_id)
);

-- Santri table (student profile)
CREATE TABLE santri (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID UNIQUE REFERENCES users(id) ON DELETE SET NULL,
    pesantren_id UUID NOT NULL REFERENCES pesantren(id) ON DELETE CASCADE,
    nis VARCHAR(50) UNIQUE NOT NULL, -- Nomor Induk Santri
    full_name VARCHAR(255) NOT NULL,
    birth_date DATE,
    birth_place VARCHAR(100),
    gender gender_type,
    address TEXT,
    phone VARCHAR(20),
    email VARCHAR(100),
    
    -- Guardian/Wali
    guardian_name VARCHAR(255),
    guardian_phone VARCHAR(20),
    guardian_relation VARCHAR(50),
    guardian_address TEXT,
    
    -- Academic info
    enrollment_date DATE NOT NULL,
    graduation_date DATE,
    status santri_status DEFAULT 'active',
    current_class_id UUID REFERENCES classes(id) ON DELETE SET NULL,
    
    -- Additional info
    previous_school VARCHAR(255),
    special_needs TEXT,
    notes TEXT,
    
    -- Photo
    photo_url TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    
    INDEX idx_santri_pesantren (pesantren_id),
    INDEX idx_santri_nis (nis),
    INDEX idx_santri_current_class (current_class_id),
    INDEX idx_santri_status (status)
);

-- Ustadz/Teacher table
CREATE TABLE ustadz (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID UNIQUE REFERENCES users(id) ON DELETE SET NULL,
    pesantren_id UUID NOT NULL REFERENCES pesantren(id) ON DELETE CASCADE,
    nip VARCHAR(50) UNIQUE, -- Nomor Induk Pegawai
    full_name VARCHAR(255) NOT NULL,
    birth_date DATE,
    birth_place VARCHAR(100),
    gender gender_type,
    address TEXT,
    phone VARCHAR(20),
    email VARCHAR(100),
    
    -- Professional info
    specialization VARCHAR(255), -- Bidang keahlian
    education TEXT, -- Riwayat pendidikan
    experience TEXT, -- Pengalaman mengajar
    certification TEXT, -- Sertifikasi
    
    -- Employment
    employment_status employment_status DEFAULT 'permanent',
    hire_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    
    -- Additional info
    photo_url TEXT,
    notes TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    
    INDEX idx_ustadz_pesantren (pesantren_id),
    INDEX idx_ustadz_nip (nip),
    INDEX idx_ustadz_active (is_active)
);

-- Update classes table to add foreign key to ustadz
ALTER TABLE classes 
ADD CONSTRAINT fk_classes_teacher 
FOREIGN KEY (class_teacher_id) REFERENCES ustadz(id) ON DELETE SET NULL;

-- Subject/Mata Pelajaran
CREATE TABLE subjects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pesantren_id UUID NOT NULL REFERENCES pesantren(id) ON DELETE CASCADE,
    code VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    category subject_category NOT NULL,
    credit_hours INTEGER DEFAULT 2,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    
    UNIQUE (pesantren_id, code),
    INDEX idx_subjects_pesantren (pesantren_id),
    INDEX idx_subjects_category (category)
);

-- Santri-Class enrollment (Many-to-Many)
CREATE TABLE santri_class (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    santri_id UUID NOT NULL REFERENCES santri(id) ON DELETE CASCADE,
    class_id UUID NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
    academic_year_id UUID NOT NULL REFERENCES academic_years(id) ON DELETE CASCADE,
    enrollment_date DATE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    
    UNIQUE (santri_id, class_id, academic_year_id),
    INDEX idx_santri_class_santri (santri_id),
    INDEX idx_santri_class_class (class_id),
    INDEX idx_santri_class_academic_year (academic_year_id)
);

-- Teaching Assignment (Jadwal Mengajar)
CREATE TABLE teaching_assignments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ustadz_id UUID NOT NULL REFERENCES ustadz(id) ON DELETE CASCADE,
    class_id UUID NOT NULL REFERENCES classes(id) ON DELETE CASCADE,
    subject_id UUID NOT NULL REFERENCES subjects(id) ON DELETE CASCADE,
    academic_year_id UUID NOT NULL REFERENCES academic_years(id) ON DELETE CASCADE,
    
    -- Schedule
    schedule_day day_of_week NOT NULL,
    schedule_time_start TIME NOT NULL,
    schedule_time_end TIME NOT NULL,
    room VARCHAR(50),
    
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    
    INDEX idx_teaching_ustadz (ustadz_id),
    INDEX idx_teaching_class (class_id),
    INDEX idx_teaching_subject (subject_id),
    INDEX idx_teaching_academic_year (academic_year_id)
);

-- Attendance/Absensi
CREATE TABLE attendance (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    teaching_assignment_id UUID NOT NULL REFERENCES teaching_assignments(id) ON DELETE CASCADE,
    santri_id UUID NOT NULL REFERENCES santri(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    status attendance_status NOT NULL DEFAULT 'present',
    notes TEXT,
    
    -- Who recorded this attendance
    recorded_by UUID NOT NULL REFERENCES users(id) ON DELETE SET NULL,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    
    UNIQUE (teaching_assignment_id, santri_id, date),
    INDEX idx_attendance_teaching (teaching_assignment_id),
    INDEX idx_attendance_santri (santri_id),
    INDEX idx_attendance_date (date),
    INDEX idx_attendance_status (status)
);

-- Grades/Nilai
CREATE TABLE grades (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    santri_id UUID NOT NULL REFERENCES santri(id) ON DELETE CASCADE,
    teaching_assignment_id UUID NOT NULL REFERENCES teaching_assignments(id) ON DELETE CASCADE,
    grade_type grade_type NOT NULL,
    
    -- Score
    score DECIMAL(5,2) NOT NULL,
    max_score DECIMAL(5,2) DEFAULT 100,
    
    -- Additional info
    date DATE NOT NULL,
    description TEXT, -- e.g., "Ulangan Harian 1"
    notes TEXT,
    
    -- Who recorded this grade
    recorded_by UUID NOT NULL REFERENCES users(id) ON DELETE SET NULL,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    
    INDEX idx_grades_santri (santri_id),
    INDEX idx_grades_teaching (teaching_assignment_id),
    INDEX idx_grades_type (grade_type),
    INDEX idx_grades_date (date)
);

-- ============================================================================
-- FINANCE TABLES
-- ============================================================================

-- Payment Type/Jenis Pembayaran
CREATE TABLE payment_types (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pesantren_id UUID NOT NULL REFERENCES pesantren(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    type payment_type_category NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    frequency payment_frequency NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    
    INDEX idx_payment_types_pesantren (pesantren_id),
    INDEX idx_payment_types_type (type),
    INDEX idx_payment_types_active (is_active)
);

-- Payments/Pembayaran
CREATE TABLE payments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    santri_id UUID NOT NULL REFERENCES santri(id) ON DELETE CASCADE,
    payment_type_id UUID NOT NULL REFERENCES payment_types(id) ON DELETE CASCADE,
    
    -- Payment details
    amount DECIMAL(12,2) NOT NULL,
    payment_date DATE NOT NULL,
    due_date DATE NOT NULL,
    period_month INTEGER, -- 1-12 untuk SPP bulanan
    period_year INTEGER, -- Tahun pembayaran
    
    -- Status
    status payment_status DEFAULT 'pending',
    payment_method VARCHAR(50), -- cash, transfer, etc
    
    -- Reference
    reference_number VARCHAR(100), -- Nomor referensi transfer
    proof_image_url TEXT, -- Bukti transfer
    
    -- Notes
    notes TEXT,
    
    -- Who recorded this payment
    recorded_by UUID NOT NULL REFERENCES users(id) ON DELETE SET NULL,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    
    INDEX idx_payments_santri (santri_id),
    INDEX idx_payments_type (payment_type_id),
    INDEX idx_payments_date (payment_date),
    INDEX idx_payments_status (status),
    INDEX idx_payments_period (period_year, period_month)
);

-- ============================================================================
-- ALUMNI & STAFF TABLES
-- ============================================================================

-- Alumni
CREATE TABLE alumni (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    santri_id UUID UNIQUE NOT NULL REFERENCES santri(id) ON DELETE CASCADE,
    graduation_year INTEGER NOT NULL,
    last_class VARCHAR(100),
    
    -- Current status
    current_status alumni_status NOT NULL,
    
    -- If studying
    institution_name VARCHAR(255),
    major VARCHAR(255),
    degree VARCHAR(100),
    
    -- If working
    job_title VARCHAR(255),
    company_name VARCHAR(255),
    company_address TEXT,
    
    -- If entrepreneur
    business_name VARCHAR(255),
    business_type VARCHAR(255),
    
    -- Contact info
    phone VARCHAR(20),
    email VARCHAR(100),
    address TEXT,
    
    -- Achievement
    achievements TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    
    INDEX idx_alumni_graduation_year (graduation_year),
    INDEX idx_alumni_current_status (current_status)
);

-- Staff (Non-teaching)
CREATE TABLE staff (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pesantren_id UUID NOT NULL REFERENCES pesantren(id) ON DELETE CASCADE,
    full_name VARCHAR(255) NOT NULL,
    
    -- Personal info
    birth_date DATE,
    birth_place VARCHAR(100),
    gender gender_type,
    address TEXT,
    phone VARCHAR(20),
    email VARCHAR(100),
    
    -- Employment
    position VARCHAR(255) NOT NULL,
    department VARCHAR(100),
    employment_status employment_status DEFAULT 'permanent',
    hire_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    
    -- Additional info
    bio TEXT,
    photo_url TEXT,
    notes TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    deleted_at TIMESTAMP WITH TIME ZONE DEFAULT NULL,
    
    INDEX idx_staff_pesantren (pesantren_id),
    INDEX idx_staff_department (department),
    INDEX idx_staff_active (is_active)
);

-- ============================================================================
-- AUDIT & LOGGING TABLES
-- ============================================================================

-- Audit Log
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    pesantren_id UUID REFERENCES pesantren(id) ON DELETE CASCADE,
    
    -- Action details
    action VARCHAR(100) NOT NULL, -- CREATE, UPDATE, DELETE, VIEW, etc
    resource_type VARCHAR(50) NOT NULL, -- santri, payment, etc
    resource_id UUID, -- ID dari resource yang dimodifikasi
    
    -- Changes
    old_values JSONB,
    new_values JSONB,
    
    -- Context
    ip_address INET,
    user_agent TEXT,
    request_method VARCHAR(10),
    request_path TEXT,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    INDEX idx_audit_user (user_id),
    INDEX idx_audit_pesantren (pesantren_id),
    INDEX idx_audit_resource (resource_type, resource_id),
    INDEX idx_audit_created (created_at)
);

-- System Settings
CREATE TABLE system_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    pesantren_id UUID REFERENCES pesantren(id) ON DELETE CASCADE,
    
    -- Settings sebagai key-value
    setting_key VARCHAR(100) NOT NULL,
    setting_value TEXT,
    
    -- Metadata
    description TEXT,
    is_public BOOLEAN DEFAULT FALSE,
    
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE (pesantren_id, setting_key),
    INDEX idx_settings_pesantren (pesantren_id)
);

-- ============================================================================
-- VIEWS & MATERIALIZED VIEWS
-- ============================================================================

-- View untuk dashboard summary
CREATE VIEW dashboard_summary AS
SELECT 
    p.id as pesantren_id,
    p.name as pesantren_name,
    
    -- Santri stats
    COUNT(DISTINCT s.id) FILTER (WHERE s.status = 'active') as active_santri,
    COUNT(DISTINCT s.id) FILTER (WHERE s.status = 'graduated') as graduated_santri,
    
    -- Ustadz stats
    COUNT(DISTINCT u.id) FILTER (WHERE u.is_active = TRUE) as active_ustadz,
    
    -- Class stats
    COUNT(DISTINCT c.id) FILTER (WHERE c.is_active = TRUE) as active_classes,
    
    -- Payment stats (current month)
    COUNT(DISTINCT pay.id) FILTER (
        WHERE pay.period_year = EXTRACT(YEAR FROM CURRENT_DATE)::INT
        AND pay.period_month = EXTRACT(MONTH FROM CURRENT_DATE)::INT
        AND pay.status = 'paid'
    ) as payments_this_month,
    
    SUM(pay.amount) FILTER (
        WHERE pay.period_year = EXTRACT(YEAR FROM CURRENT_DATE)::INT
        AND pay.period_month = EXTRACT(MONTH FROM CURRENT_DATE)::INT
        AND pay.status = 'paid'
    ) as revenue_this_month,
    
    -- Outstanding payments
    COUNT(DISTINCT pay2.id) FILTER (
        WHERE pay2.due_date < CURRENT_DATE
        AND pay2.status IN ('pending', 'partial')
    ) as overdue_payments
    
FROM pesantren p
LEFT JOIN santri s ON p.id = s.pesantren_id AND s.deleted_at IS NULL
LEFT JOIN ustadz u ON p.id = u.pesantren_id AND u.deleted_at IS NULL
LEFT JOIN classes c ON p.id = c.pesantren_id AND c.deleted_at IS NULL
LEFT JOIN payments pay ON p.id = (SELECT pesantren_id FROM santri WHERE id = pay.santri_id)
LEFT JOIN payments pay2 ON p.id = (SELECT pesantren_id FROM santri WHERE id = pay2.santri_id)
WHERE p.deleted_at IS NULL
GROUP BY p.id, p.name;

-- View untuk santri dengan nilai rata-rata
CREATE VIEW santri_performance AS
SELECT 
    s.id as santri_id,
    s.full_name,
    s.nis,
    s.current_class_id,
    c.name as class_name,
    AVG(g.score) as average_score,
    COUNT(DISTINCT g.id) as total_grades,
    COUNT(DISTINCT a.id) FILTER (WHERE a.status = 'present') as present_count,
    COUNT(DISTINCT a.id) FILTER (WHERE a.status = 'absent') as absent_count,
    COUNT(DISTINCT a.id) as total_attendance
FROM santri s
LEFT JOIN grades g ON s.id = g.santri_id AND g.deleted_at IS NULL
LEFT JOIN classes c ON s.current_class_id = c.id
LEFT JOIN attendance a ON s.id = a.santri_id AND a.deleted_at IS NULL
WHERE s.deleted_at IS NULL
GROUP BY s.id, s.full_name, s.nis, s.current_class_id, c.name;

-- ============================================================================
-- TRIGGERS
-- ============================================================================

-- Update updated_at column
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Apply trigger to all tables with updated_at
CREATE TRIGGER update_pesantren_updated_at BEFORE UPDATE ON pesantren
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_santri_updated_at BEFORE UPDATE ON santri
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_ustadz_updated_at BEFORE UPDATE ON ustadz
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_classes_updated_at BEFORE UPDATE ON classes
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_academic_years_updated_at BEFORE UPDATE ON academic_years
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_subjects_updated_at BEFORE UPDATE ON subjects
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_teaching_assignments_updated_at BEFORE UPDATE ON teaching_assignments
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_attendance_updated_at BEFORE UPDATE ON attendance
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_grades_updated_at BEFORE UPDATE ON grades
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_payment_types_updated_at BEFORE UPDATE ON payment_types
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_payments_updated_at BEFORE UPDATE ON payments
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_alumni_updated_at BEFORE UPDATE ON alumni
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_staff_updated_at BEFORE UPDATE ON staff
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Audit logging trigger
CREATE OR REPLACE FUNCTION audit_trigger_function()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'DELETE' THEN
        INSERT INTO audit_logs (user_id, pesantren_id, action, resource_type, resource_id, old_values, created_at)
        VALUES (current_setting('app.current_user_id')::UUID, 
                current_setting('app.current_pesantren_id')::UUID,
                'DELETE', TG_TABLE_NAME, OLD.id, row_to_json(OLD), CURRENT_TIMESTAMP);
        RETURN OLD;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO audit_logs (user_id, pesantren_id, action, resource_type, resource_id, old_values, new_values, created_at)
        VALUES (current_setting('app.current_user_id')::UUID, 
                current_setting('app.current_pesantren_id')::UUID,
                'UPDATE', TG_TABLE_NAME, NEW.id, row_to_json(OLD), row_to_json(NEW), CURRENT_TIMESTAMP);
        RETURN NEW;
    ELSIF TG_OP = 'INSERT' THEN
        INSERT INTO audit_logs (user_id, pesantren_id, action, resource_type, resource_id, new_values, created_at)
        VALUES (current_setting('app.current_user_id')::UUID, 
                current_setting('app.current_pesantren_id')::UUID,
                'CREATE', TG_TABLE_NAME, NEW.id, row_to_json(NEW), CURRENT_TIMESTAMP);
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Apply audit trigger to important tables
CREATE TRIGGER audit_santri AFTER INSERT OR UPDATE OR DELETE ON santri
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

CREATE TRIGGER audit_payments AFTER INSERT OR UPDATE OR DELETE ON payments
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

CREATE TRIGGER audit_grades AFTER INSERT OR UPDATE OR DELETE ON grades
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

CREATE TRIGGER audit_attendance AFTER INSERT OR UPDATE OR DELETE ON attendance
    FOR EACH ROW EXECUTE FUNCTION audit_trigger_function();

-- ============================================================================
-- INITIAL DATA
-- ============================================================================

-- Insert default pesantren
INSERT INTO pesantren (id, name, slug, description, address, phone, email, is_active) 
VALUES (
    uuid_generate_v4(),
    'Pondok Pesantren SIAP Demo',
    'pesantren-demo',
    'Pesantren demo untuk sistem SIAP',
    'Jl. Demo No. 123, Kota Demo',
    '02112345678',
    'info@pesantrendemo.com',
    TRUE
);

-- Note: Super admin user akan dibuat melalui seeder/migration terpisah
-- karena membutuhkan password hashing.

-- ============================================================================
-- PERFORMANCE INDEXES
-- ============================================================================

-- Composite indexes untuk queries yang sering digunakan
CREATE INDEX idx_payments_santri_period ON payments(santri_id, period_year, period_month);
CREATE INDEX idx_attendance_santri_date ON attendance(santri_id, date);
CREATE INDEX idx_grades_santri_teaching ON grades(santri_id, teaching_assignment_id);
CREATE INDEX idx_santri_class_composite ON santri_class(santri_id, class_id, academic_year_id);

-- ============================================================================
-- ROW LEVEL SECURITY (RLS) - Optional untuk multi-tenant
-- ============================================================================

-- Enable RLS pada tabel yang memiliki pesantren_id
ALTER TABLE santri ENABLE ROW LEVEL SECURITY;
ALTER TABLE ustadz ENABLE ROW LEVEL SECURITY;
ALTER TABLE classes ENABLE ROW LEVEL SECURITY;
ALTER TABLE subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE staff ENABLE ROW LEVEL SECURITY;

-- Policies akan dibuat di application level untuk flexibility

-- ============================================================================
-- COMMENTS
-- ============================================================================

COMMENT ON TABLE pesantren IS 'Master data pesantren/institusi';
COMMENT ON TABLE users IS 'User authentication dan role management';
COMMENT ON TABLE santri IS 'Data santri (murid)';
COMMENT ON TABLE ustadz IS 'Data ustadz/guru';
COMMENT ON TABLE classes IS 'Data kelas';
COMMENT ON TABLE subjects IS 'Mata pelajaran';
COMMENT ON TABLE attendance IS 'Absensi harian';
COMMENT ON TABLE grades IS 'Nilai santri';
COMMENT ON TABLE payments IS 'Pembayaran santri';
COMMENT ON TABLE alumni IS 'Data alumni';
COMMENT ON TABLE staff IS 'Staf non-pengajar';
COMMENT ON TABLE audit_logs IS 'Log aktivitas sistem';

-- ============================================================================
-- END OF SCHEMA
-- ============================================================================
